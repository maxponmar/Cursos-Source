﻿using System;

namespace MiPrimeraNeurona
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();

            double peso1, peso2;
            double umbral;

            int iteracion = 0;
            /*
              AND E1 E2
              1   1  1
              0   1  0
              0   0  0
              0   0  0
             
            */

            Random r = new Random();

            bool sw = false;
            while (!sw)
            {
                sw = true;
                iteracion++;

                peso1 = Convert.ToDouble(r.NextDouble() - r.NextDouble());
                peso2 = Convert.ToDouble(r.NextDouble() - r.NextDouble());
                umbral = Convert.ToDouble(r.NextDouble() - r.NextDouble());

                Console.WriteLine("-------------------------------------");
                Console.WriteLine("Iteracion "+ iteracion);
                Console.WriteLine("Peso 1: " + peso1);
                Console.WriteLine("Peso 2: " + peso2);
                Console.WriteLine("Umbral: " + umbral);
                Console.WriteLine("E1:1 E2:1 : " + p.funcion(p.Neurona(1, 1, peso1, peso2, umbral)));
                Console.WriteLine("E1:1 E2:0 : " + p.funcion(p.Neurona(1, 0, peso1, peso2, umbral)));
                Console.WriteLine("E1:0 E2:1 : " + p.funcion(p.Neurona(0, 1, peso1, peso2, umbral)));
                Console.WriteLine("E1:0 E2:0 : " + p.funcion(p.Neurona(0, 0, peso1, peso2, umbral)));

                if (p.funcion(p.Neurona(1, 1, peso1, peso2, umbral)) != 1) 
                {                   
                    sw = false;
                }
                if (p.funcion(p.Neurona(1, 0, peso1, peso2, umbral)) != 0)
                {                    
                    sw = false;
                }
                if (p.funcion(p.Neurona(0, 1, peso1, peso2, umbral)) != 0)
                {                    
                    sw = false;
                }
                if (p.funcion(p.Neurona(0, 0, peso1, peso2, umbral)) != 0)
                {                    
                    sw = false;
                }
            }
        
            Console.ReadKey();
        }

        double Neurona(double entrada1, double entrada2, double peso1, double peso2, double umbral)
        {
            return umbral + entrada1 * peso1 + entrada2 * peso2;
        }

        double funcion(double d)
        {
            return d > 0 ? 1 : 0; // Condicional ternario
        }
    }
}
