﻿namespace LinearAlgebra
{
    public enum Axis
    {
        horizontal,
        vertical
    }
    public enum AxisZero
    {
        horizontal,
        vertical,
        none
    }
}
