﻿using System;

namespace MiPrimeraRedNeuronal
{
    class Program
    {
        static void Main(string[] args)
        {
            int iteracion = 0;

            // Tasa de aprendizaje debe de ser pequena por ejemplo 0.3
            // peso = pesoanterior + tasaAprendizaje * error * entrada

            Neurona p = new Neurona(2, 0.1);
            Random r = new Random();

            bool sw = false;
            while (!sw)
            {                
                sw = true;
                iteracion++;

                Console.WriteLine("-------------------------------------");
                Console.WriteLine("Iteracion " + iteracion);
                Console.WriteLine("Peso 1: " + p.Pesos[0]);
                Console.WriteLine("Peso 2: " + p.Pesos[1]);
                Console.WriteLine("Umbral: " + p.Umbral);
                Console.WriteLine("E1:1 E2:1 : " + p.Salida(new double[2] { 1, 1 }));
                Console.WriteLine("E1:1 E2:0 : " + p.Salida(new double[2] { 1, 0 }));
                Console.WriteLine("E1:0 E2:1 : " + p.Salida(new double[2] { 0, 1 }));
                Console.WriteLine("E1:0 E2:0 : " + p.Salida(new double[2] { 0, 0 }));

                if (p.Salida(new double[2] { 1, 1 }) != 1)
                {
                    p.Aprender(new double[2] { 1, 1 }, 1);
                    sw = false;
                }
                if (p.Salida(new double[2] { 1, 0 }) != 0)
                {
                    p.Aprender(new double[2] { 1, 0 }, 0);
                    sw = false;
                }
                if (p.Salida(new double[2] { 0, 1 }) != 0)
                {
                    p.Aprender(new double[2] { 0, 1 }, 0);
                    sw = false;
                }
                if (p.Salida(new double[2] { 0, 0 }) != 0)
                {
                    p.Aprender(new double[2] { 0, 0 }, 0);
                    sw = false;
                }
            }

            Console.ReadKey();
        
        }
    }

    public class Neurona
    {
        double[] pesosAnteriores;
        double umbralAnterior;
        // peso = pesoanterior + tasaAprendizaje * error * entrada
        public double[] Pesos;
        public double Umbral;
        public double TasaAprendizaje;

        public Neurona(int NEntradas, double tasaAprendizaje)
        {
            TasaAprendizaje = tasaAprendizaje;
            Pesos = new double[NEntradas];
            pesosAnteriores = new double[NEntradas];
            Aprender();
        }
        public void Aprender()
        {
            Random r = new Random();
            for (int i = 0; i < Pesos.Length; i++)
            {
                pesosAnteriores[i] = r.NextDouble() - r.NextDouble();
            }
            umbralAnterior = r.NextDouble() - r.NextDouble();

            Pesos = pesosAnteriores;
            Umbral = umbralAnterior;
        }

        public void Aprender(double[] entradas, double salidaEsperada)
        {
            double error = salidaEsperada - Salida(entradas);
            for (int i = 0; i < Pesos.Length; i++)
            {
                Pesos[i] = pesosAnteriores[i] + TasaAprendizaje * error * entradas[i];
            }
            Umbral = umbralAnterior + TasaAprendizaje * error;           
            pesosAnteriores = Pesos;
            umbralAnterior = Umbral;
        }
        public double Salida(double[] entradas)
        {
            return funcion(neurona(entradas));
        }

        double neurona(double[] entradas)
        {
            double sum = 0;
            for (int i = 0; i < Pesos.Length; i++)
            {
                sum += entradas[i] * Pesos[i];
            }
            sum += Umbral;
            return sum;
        }
        double funcion(double d)
        {
            return d > 0 ? 1 : 0;
        }
    }
}

