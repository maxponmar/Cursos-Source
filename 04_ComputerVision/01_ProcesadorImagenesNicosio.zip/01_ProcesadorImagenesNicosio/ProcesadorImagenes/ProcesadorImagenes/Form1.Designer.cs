﻿namespace ProcesadorImagenes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirImagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guardarImagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.basicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invertirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filtroColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aberracionCromaticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tonosDeGrisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorizarGradienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.brilloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contrasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gammaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flipHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ruidoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mosaicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transparenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.histogramasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hTonosGrisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ecualizarHistogramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.convolucionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suavizadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blurGaussianoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sharpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bordesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quickPhilipsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.falerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kirschToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prewittToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homogeneidadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diferenciaGaussianaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.johnsonContrasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.lowPassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highPassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirImagen2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.booleanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nANDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gANDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gNANDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gNORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gXORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gNOTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overlayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noCeroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ceroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mayorQueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menorQueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geometricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.basicoGeometriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.warpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.objectWarpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.basicosToolStripMenuItem,
            this.histogramasToolStripMenuItem,
            this.convolucionToolStripMenuItem,
            this.operacionesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1084, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abrirImagesToolStripMenuItem,
            this.abrirImagen2ToolStripMenuItem,
            this.guardarImagesToolStripMenuItem,
            this.toolStripSeparator1,
            this.salirToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.archivoToolStripMenuItem.Text = "Archivo";
            // 
            // abrirImagesToolStripMenuItem
            // 
            this.abrirImagesToolStripMenuItem.Name = "abrirImagesToolStripMenuItem";
            this.abrirImagesToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.abrirImagesToolStripMenuItem.Text = "Abrir Imagen";
            this.abrirImagesToolStripMenuItem.Click += new System.EventHandler(this.abrirImagesToolStripMenuItem_Click);
            // 
            // guardarImagesToolStripMenuItem
            // 
            this.guardarImagesToolStripMenuItem.Name = "guardarImagesToolStripMenuItem";
            this.guardarImagesToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.guardarImagesToolStripMenuItem.Text = "Guardar Imagen";
            this.guardarImagesToolStripMenuItem.Click += new System.EventHandler(this.guardarImagesToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(156, 6);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // basicosToolStripMenuItem
            // 
            this.basicosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.testToolStripMenuItem,
            this.invertirToolStripMenuItem,
            this.filtroColorToolStripMenuItem,
            this.aberracionCromaticaToolStripMenuItem,
            this.tonosDeGrisToolStripMenuItem,
            this.colorizarToolStripMenuItem,
            this.colorizarGradienteToolStripMenuItem,
            this.brilloToolStripMenuItem,
            this.contrasteToolStripMenuItem,
            this.gammaToolStripMenuItem,
            this.flipHToolStripMenuItem,
            this.ruidoToolStripMenuItem,
            this.mosaicoToolStripMenuItem,
            this.transparenteToolStripMenuItem});
            this.basicosToolStripMenuItem.Name = "basicosToolStripMenuItem";
            this.basicosToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.basicosToolStripMenuItem.Text = "Basicos";
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.testToolStripMenuItem.Text = "Test";
            this.testToolStripMenuItem.Click += new System.EventHandler(this.testToolStripMenuItem_Click);
            // 
            // invertirToolStripMenuItem
            // 
            this.invertirToolStripMenuItem.Name = "invertirToolStripMenuItem";
            this.invertirToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.invertirToolStripMenuItem.Text = "Invertir";
            this.invertirToolStripMenuItem.Click += new System.EventHandler(this.invertirToolStripMenuItem_Click);
            // 
            // filtroColorToolStripMenuItem
            // 
            this.filtroColorToolStripMenuItem.Name = "filtroColorToolStripMenuItem";
            this.filtroColorToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.filtroColorToolStripMenuItem.Text = "FiltroColor";
            this.filtroColorToolStripMenuItem.Click += new System.EventHandler(this.filtroColorToolStripMenuItem_Click);
            // 
            // aberracionCromaticaToolStripMenuItem
            // 
            this.aberracionCromaticaToolStripMenuItem.Name = "aberracionCromaticaToolStripMenuItem";
            this.aberracionCromaticaToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.aberracionCromaticaToolStripMenuItem.Text = "AberracionCromatica";
            this.aberracionCromaticaToolStripMenuItem.Click += new System.EventHandler(this.aberracionCromaticaToolStripMenuItem_Click);
            // 
            // tonosDeGrisToolStripMenuItem
            // 
            this.tonosDeGrisToolStripMenuItem.Name = "tonosDeGrisToolStripMenuItem";
            this.tonosDeGrisToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.tonosDeGrisToolStripMenuItem.Text = "TonosDeGris";
            this.tonosDeGrisToolStripMenuItem.Click += new System.EventHandler(this.tonosDeGrisToolStripMenuItem_Click);
            // 
            // colorizarToolStripMenuItem
            // 
            this.colorizarToolStripMenuItem.Name = "colorizarToolStripMenuItem";
            this.colorizarToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.colorizarToolStripMenuItem.Text = "Colorizar";
            this.colorizarToolStripMenuItem.Click += new System.EventHandler(this.colorizarToolStripMenuItem_Click);
            // 
            // colorizarGradienteToolStripMenuItem
            // 
            this.colorizarGradienteToolStripMenuItem.Name = "colorizarGradienteToolStripMenuItem";
            this.colorizarGradienteToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.colorizarGradienteToolStripMenuItem.Text = "ColorizarGradiente";
            this.colorizarGradienteToolStripMenuItem.Click += new System.EventHandler(this.colorizarGradienteToolStripMenuItem_Click);
            // 
            // brilloToolStripMenuItem
            // 
            this.brilloToolStripMenuItem.Name = "brilloToolStripMenuItem";
            this.brilloToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.brilloToolStripMenuItem.Text = "Brillo";
            this.brilloToolStripMenuItem.Click += new System.EventHandler(this.brilloToolStripMenuItem_Click);
            // 
            // contrasteToolStripMenuItem
            // 
            this.contrasteToolStripMenuItem.Name = "contrasteToolStripMenuItem";
            this.contrasteToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.contrasteToolStripMenuItem.Text = "Contraste";
            this.contrasteToolStripMenuItem.Click += new System.EventHandler(this.contrasteToolStripMenuItem_Click);
            // 
            // gammaToolStripMenuItem
            // 
            this.gammaToolStripMenuItem.Name = "gammaToolStripMenuItem";
            this.gammaToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.gammaToolStripMenuItem.Text = "Gamma";
            this.gammaToolStripMenuItem.Click += new System.EventHandler(this.gammaToolStripMenuItem_Click);
            // 
            // flipHToolStripMenuItem
            // 
            this.flipHToolStripMenuItem.Name = "flipHToolStripMenuItem";
            this.flipHToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.flipHToolStripMenuItem.Text = "FlipH";
            this.flipHToolStripMenuItem.Click += new System.EventHandler(this.flipHToolStripMenuItem_Click);
            // 
            // ruidoToolStripMenuItem
            // 
            this.ruidoToolStripMenuItem.Name = "ruidoToolStripMenuItem";
            this.ruidoToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.ruidoToolStripMenuItem.Text = "Ruido";
            this.ruidoToolStripMenuItem.Click += new System.EventHandler(this.ruidoToolStripMenuItem_Click);
            // 
            // mosaicoToolStripMenuItem
            // 
            this.mosaicoToolStripMenuItem.Name = "mosaicoToolStripMenuItem";
            this.mosaicoToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.mosaicoToolStripMenuItem.Text = "Mosaico";
            this.mosaicoToolStripMenuItem.Click += new System.EventHandler(this.mosaicoToolStripMenuItem_Click);
            // 
            // transparenteToolStripMenuItem
            // 
            this.transparenteToolStripMenuItem.Name = "transparenteToolStripMenuItem";
            this.transparenteToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.transparenteToolStripMenuItem.Text = "Transparente";
            this.transparenteToolStripMenuItem.Click += new System.EventHandler(this.transparenteToolStripMenuItem_Click);
            // 
            // histogramasToolStripMenuItem
            // 
            this.histogramasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hTonosGrisToolStripMenuItem,
            this.ecualizarHistogramaToolStripMenuItem});
            this.histogramasToolStripMenuItem.Name = "histogramasToolStripMenuItem";
            this.histogramasToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.histogramasToolStripMenuItem.Text = "Histogramas";
            // 
            // hTonosGrisToolStripMenuItem
            // 
            this.hTonosGrisToolStripMenuItem.Name = "hTonosGrisToolStripMenuItem";
            this.hTonosGrisToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.hTonosGrisToolStripMenuItem.Text = "HTonosGris";
            this.hTonosGrisToolStripMenuItem.Click += new System.EventHandler(this.hTonosGrisToolStripMenuItem_Click);
            // 
            // ecualizarHistogramaToolStripMenuItem
            // 
            this.ecualizarHistogramaToolStripMenuItem.Name = "ecualizarHistogramaToolStripMenuItem";
            this.ecualizarHistogramaToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.ecualizarHistogramaToolStripMenuItem.Text = "EcualizarHistograma";
            this.ecualizarHistogramaToolStripMenuItem.Click += new System.EventHandler(this.ecualizarHistogramaToolStripMenuItem_Click);
            // 
            // convolucionToolStripMenuItem
            // 
            this.convolucionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.suavizadoToolStripMenuItem,
            this.blurGaussianoToolStripMenuItem,
            this.sharpenToolStripMenuItem,
            this.bordesToolStripMenuItem,
            this.lowPassToolStripMenuItem,
            this.highPassToolStripMenuItem});
            this.convolucionToolStripMenuItem.Name = "convolucionToolStripMenuItem";
            this.convolucionToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.convolucionToolStripMenuItem.Text = "Convolucion";
            // 
            // suavizadoToolStripMenuItem
            // 
            this.suavizadoToolStripMenuItem.Name = "suavizadoToolStripMenuItem";
            this.suavizadoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.suavizadoToolStripMenuItem.Text = "Suavizado";
            this.suavizadoToolStripMenuItem.Click += new System.EventHandler(this.suavizadoToolStripMenuItem_Click);
            // 
            // blurGaussianoToolStripMenuItem
            // 
            this.blurGaussianoToolStripMenuItem.Name = "blurGaussianoToolStripMenuItem";
            this.blurGaussianoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.blurGaussianoToolStripMenuItem.Text = "BlurGaussiano";
            this.blurGaussianoToolStripMenuItem.Click += new System.EventHandler(this.blurGaussianoToolStripMenuItem_Click);
            // 
            // sharpenToolStripMenuItem
            // 
            this.sharpenToolStripMenuItem.Name = "sharpenToolStripMenuItem";
            this.sharpenToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sharpenToolStripMenuItem.Text = "Sharpen";
            this.sharpenToolStripMenuItem.Click += new System.EventHandler(this.sharpenToolStripMenuItem_Click);
            // 
            // bordesToolStripMenuItem
            // 
            this.bordesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quickPhilipsToolStripMenuItem,
            this.falerToolStripMenuItem,
            this.kirschToolStripMenuItem,
            this.prewittToolStripMenuItem,
            this.sobelToolStripMenuItem,
            this.homogeneidadToolStripMenuItem,
            this.diferenciaGaussianaToolStripMenuItem,
            this.johnsonContrasteToolStripMenuItem});
            this.bordesToolStripMenuItem.Name = "bordesToolStripMenuItem";
            this.bordesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.bordesToolStripMenuItem.Text = "Bordes";
            // 
            // quickPhilipsToolStripMenuItem
            // 
            this.quickPhilipsToolStripMenuItem.Name = "quickPhilipsToolStripMenuItem";
            this.quickPhilipsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.quickPhilipsToolStripMenuItem.Text = "QuickPhilips";
            this.quickPhilipsToolStripMenuItem.Click += new System.EventHandler(this.quickPhilipsToolStripMenuItem_Click);
            // 
            // falerToolStripMenuItem
            // 
            this.falerToolStripMenuItem.Name = "falerToolStripMenuItem";
            this.falerToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.falerToolStripMenuItem.Text = "Faler";
            this.falerToolStripMenuItem.Click += new System.EventHandler(this.falerToolStripMenuItem_Click);
            // 
            // kirschToolStripMenuItem
            // 
            this.kirschToolStripMenuItem.Name = "kirschToolStripMenuItem";
            this.kirschToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.kirschToolStripMenuItem.Text = "Kirsch";
            this.kirschToolStripMenuItem.Click += new System.EventHandler(this.kirschToolStripMenuItem_Click);
            // 
            // prewittToolStripMenuItem
            // 
            this.prewittToolStripMenuItem.Name = "prewittToolStripMenuItem";
            this.prewittToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.prewittToolStripMenuItem.Text = "Prewitt";
            this.prewittToolStripMenuItem.Click += new System.EventHandler(this.prewittToolStripMenuItem_Click);
            // 
            // sobelToolStripMenuItem
            // 
            this.sobelToolStripMenuItem.Name = "sobelToolStripMenuItem";
            this.sobelToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sobelToolStripMenuItem.Text = "Sobel";
            this.sobelToolStripMenuItem.Click += new System.EventHandler(this.sobelToolStripMenuItem_Click);
            // 
            // homogeneidadToolStripMenuItem
            // 
            this.homogeneidadToolStripMenuItem.Name = "homogeneidadToolStripMenuItem";
            this.homogeneidadToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.homogeneidadToolStripMenuItem.Text = "Homogeneidad";
            this.homogeneidadToolStripMenuItem.Click += new System.EventHandler(this.homogeneidadToolStripMenuItem_Click);
            // 
            // diferenciaGaussianaToolStripMenuItem
            // 
            this.diferenciaGaussianaToolStripMenuItem.Name = "diferenciaGaussianaToolStripMenuItem";
            this.diferenciaGaussianaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.diferenciaGaussianaToolStripMenuItem.Text = "DiferenciaGaussiana";
            this.diferenciaGaussianaToolStripMenuItem.Click += new System.EventHandler(this.diferenciaGaussianaToolStripMenuItem_Click);
            // 
            // johnsonContrasteToolStripMenuItem
            // 
            this.johnsonContrasteToolStripMenuItem.Name = "johnsonContrasteToolStripMenuItem";
            this.johnsonContrasteToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.johnsonContrasteToolStripMenuItem.Text = "JohnsonContraste";
            this.johnsonContrasteToolStripMenuItem.Click += new System.EventHandler(this.johnsonContrasteToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Imagenes JPG|*.jpg|Imagenes PNG|*.png|Imagenes BitMap|*.bmp|Imagenes JPEG|*.jpeg";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Imagenes JPG|*.jpg|Imagenes PNG|*.png|Imagenes BitMap|*.bmp|Imagenes JPEG|*.jpeg";
            // 
            // lowPassToolStripMenuItem
            // 
            this.lowPassToolStripMenuItem.Name = "lowPassToolStripMenuItem";
            this.lowPassToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.lowPassToolStripMenuItem.Text = "LowPass";
            this.lowPassToolStripMenuItem.Click += new System.EventHandler(this.lowPassToolStripMenuItem_Click_1);
            // 
            // highPassToolStripMenuItem
            // 
            this.highPassToolStripMenuItem.Name = "highPassToolStripMenuItem";
            this.highPassToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.highPassToolStripMenuItem.Text = "HighPass";
            this.highPassToolStripMenuItem.Click += new System.EventHandler(this.highPassToolStripMenuItem_Click);
            // 
            // operacionesToolStripMenuItem
            // 
            this.operacionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.restaToolStripMenuItem,
            this.adicionToolStripMenuItem,
            this.booleanToolStripMenuItem,
            this.overlayToolStripMenuItem,
            this.geometricasToolStripMenuItem,
            this.warpToolStripMenuItem,
            this.objectWarpToolStripMenuItem});
            this.operacionesToolStripMenuItem.Name = "operacionesToolStripMenuItem";
            this.operacionesToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.operacionesToolStripMenuItem.Text = "Operaciones";
            // 
            // abrirImagen2ToolStripMenuItem
            // 
            this.abrirImagen2ToolStripMenuItem.Name = "abrirImagen2ToolStripMenuItem";
            this.abrirImagen2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.abrirImagen2ToolStripMenuItem.Text = "Abrir Imagen2";
            this.abrirImagen2ToolStripMenuItem.Click += new System.EventHandler(this.abrirImagen2ToolStripMenuItem_Click);
            // 
            // restaToolStripMenuItem
            // 
            this.restaToolStripMenuItem.Name = "restaToolStripMenuItem";
            this.restaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.restaToolStripMenuItem.Text = "Resta";
            this.restaToolStripMenuItem.Click += new System.EventHandler(this.restaToolStripMenuItem_Click);
            // 
            // adicionToolStripMenuItem
            // 
            this.adicionToolStripMenuItem.Name = "adicionToolStripMenuItem";
            this.adicionToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.adicionToolStripMenuItem.Text = "Adicion";
            this.adicionToolStripMenuItem.Click += new System.EventHandler(this.adicionToolStripMenuItem_Click);
            // 
            // booleanToolStripMenuItem
            // 
            this.booleanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aNDToolStripMenuItem,
            this.oRToolStripMenuItem,
            this.nANDToolStripMenuItem,
            this.nORToolStripMenuItem,
            this.gANDToolStripMenuItem,
            this.gORToolStripMenuItem,
            this.gNANDToolStripMenuItem,
            this.gNORToolStripMenuItem,
            this.gXORToolStripMenuItem,
            this.gNOTToolStripMenuItem});
            this.booleanToolStripMenuItem.Name = "booleanToolStripMenuItem";
            this.booleanToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.booleanToolStripMenuItem.Text = "Boolean";
            // 
            // aNDToolStripMenuItem
            // 
            this.aNDToolStripMenuItem.Name = "aNDToolStripMenuItem";
            this.aNDToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.aNDToolStripMenuItem.Text = "AND";
            this.aNDToolStripMenuItem.Click += new System.EventHandler(this.aNDToolStripMenuItem_Click);
            // 
            // oRToolStripMenuItem
            // 
            this.oRToolStripMenuItem.Name = "oRToolStripMenuItem";
            this.oRToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.oRToolStripMenuItem.Text = "OR";
            this.oRToolStripMenuItem.Click += new System.EventHandler(this.oRToolStripMenuItem_Click);
            // 
            // nANDToolStripMenuItem
            // 
            this.nANDToolStripMenuItem.Name = "nANDToolStripMenuItem";
            this.nANDToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.nANDToolStripMenuItem.Text = "NAND";
            this.nANDToolStripMenuItem.Click += new System.EventHandler(this.nANDToolStripMenuItem_Click);
            // 
            // nORToolStripMenuItem
            // 
            this.nORToolStripMenuItem.Name = "nORToolStripMenuItem";
            this.nORToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.nORToolStripMenuItem.Text = "NOR";
            this.nORToolStripMenuItem.Click += new System.EventHandler(this.nORToolStripMenuItem_Click);
            // 
            // gANDToolStripMenuItem
            // 
            this.gANDToolStripMenuItem.Name = "gANDToolStripMenuItem";
            this.gANDToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gANDToolStripMenuItem.Text = "G AND";
            this.gANDToolStripMenuItem.Click += new System.EventHandler(this.gANDToolStripMenuItem_Click);
            // 
            // gORToolStripMenuItem
            // 
            this.gORToolStripMenuItem.Name = "gORToolStripMenuItem";
            this.gORToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gORToolStripMenuItem.Text = "G OR";
            this.gORToolStripMenuItem.Click += new System.EventHandler(this.gORToolStripMenuItem_Click);
            // 
            // gNANDToolStripMenuItem
            // 
            this.gNANDToolStripMenuItem.Name = "gNANDToolStripMenuItem";
            this.gNANDToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gNANDToolStripMenuItem.Text = "G NAND";
            this.gNANDToolStripMenuItem.Click += new System.EventHandler(this.gNANDToolStripMenuItem_Click);
            // 
            // gNORToolStripMenuItem
            // 
            this.gNORToolStripMenuItem.Name = "gNORToolStripMenuItem";
            this.gNORToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gNORToolStripMenuItem.Text = "G NOR";
            this.gNORToolStripMenuItem.Click += new System.EventHandler(this.gNORToolStripMenuItem_Click);
            // 
            // gXORToolStripMenuItem
            // 
            this.gXORToolStripMenuItem.Name = "gXORToolStripMenuItem";
            this.gXORToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gXORToolStripMenuItem.Text = "G XOR";
            this.gXORToolStripMenuItem.Click += new System.EventHandler(this.gXORToolStripMenuItem_Click);
            // 
            // gNOTToolStripMenuItem
            // 
            this.gNOTToolStripMenuItem.Name = "gNOTToolStripMenuItem";
            this.gNOTToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gNOTToolStripMenuItem.Text = "G NOT";
            this.gNOTToolStripMenuItem.Click += new System.EventHandler(this.gNOTToolStripMenuItem_Click);
            // 
            // overlayToolStripMenuItem
            // 
            this.overlayToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noCeroToolStripMenuItem,
            this.ceroToolStripMenuItem,
            this.mayorQueToolStripMenuItem,
            this.menorQueToolStripMenuItem});
            this.overlayToolStripMenuItem.Name = "overlayToolStripMenuItem";
            this.overlayToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.overlayToolStripMenuItem.Text = "Overlay";
            // 
            // noCeroToolStripMenuItem
            // 
            this.noCeroToolStripMenuItem.Name = "noCeroToolStripMenuItem";
            this.noCeroToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.noCeroToolStripMenuItem.Text = "No cero";
            this.noCeroToolStripMenuItem.Click += new System.EventHandler(this.noCeroToolStripMenuItem_Click);
            // 
            // ceroToolStripMenuItem
            // 
            this.ceroToolStripMenuItem.Name = "ceroToolStripMenuItem";
            this.ceroToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ceroToolStripMenuItem.Text = "Cero";
            this.ceroToolStripMenuItem.Click += new System.EventHandler(this.ceroToolStripMenuItem_Click);
            // 
            // mayorQueToolStripMenuItem
            // 
            this.mayorQueToolStripMenuItem.Name = "mayorQueToolStripMenuItem";
            this.mayorQueToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.mayorQueToolStripMenuItem.Text = "Mayor que";
            this.mayorQueToolStripMenuItem.Click += new System.EventHandler(this.mayorQueToolStripMenuItem_Click);
            // 
            // menorQueToolStripMenuItem
            // 
            this.menorQueToolStripMenuItem.Name = "menorQueToolStripMenuItem";
            this.menorQueToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.menorQueToolStripMenuItem.Text = "Menor que";
            this.menorQueToolStripMenuItem.Click += new System.EventHandler(this.menorQueToolStripMenuItem_Click);
            // 
            // geometricasToolStripMenuItem
            // 
            this.geometricasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.basicoGeometriaToolStripMenuItem});
            this.geometricasToolStripMenuItem.Name = "geometricasToolStripMenuItem";
            this.geometricasToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.geometricasToolStripMenuItem.Text = "Geometricas";
            // 
            // basicoGeometriaToolStripMenuItem
            // 
            this.basicoGeometriaToolStripMenuItem.Name = "basicoGeometriaToolStripMenuItem";
            this.basicoGeometriaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.basicoGeometriaToolStripMenuItem.Text = "Basico Geometria";
            this.basicoGeometriaToolStripMenuItem.Click += new System.EventHandler(this.basicoGeometriaToolStripMenuItem_Click);
            // 
            // warpToolStripMenuItem
            // 
            this.warpToolStripMenuItem.Name = "warpToolStripMenuItem";
            this.warpToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.warpToolStripMenuItem.Text = "Warp";
            this.warpToolStripMenuItem.Click += new System.EventHandler(this.warpToolStripMenuItem_Click);
            // 
            // objectWarpToolStripMenuItem
            // 
            this.objectWarpToolStripMenuItem.Name = "objectWarpToolStripMenuItem";
            this.objectWarpToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.objectWarpToolStripMenuItem.Text = "Object Warp";
            this.objectWarpToolStripMenuItem.Click += new System.EventHandler(this.objectWarpToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 661);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirImagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guardarImagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invertirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem histogramasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem convolucionToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem filtroColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aberracionCromaticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gammaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tonosDeGrisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorizarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorizarGradienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem brilloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contrasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem flipHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ruidoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mosaicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transparenteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hTonosGrisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ecualizarHistogramaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suavizadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blurGaussianoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sharpenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bordesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quickPhilipsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem falerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kirschToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prewittToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homogeneidadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diferenciaGaussianaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem johnsonContrasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lowPassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highPassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirImagen2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adicionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem booleanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nANDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gANDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gNANDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gNORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gXORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gNOTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem overlayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noCeroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ceroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mayorQueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menorQueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geometricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basicoGeometriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem warpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem objectWarpToolStripMenuItem;
    }
}

