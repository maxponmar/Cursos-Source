﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProcesadorImagenes
{
    public partial class Form1 : Form
    {
        private Bitmap original;
        private Bitmap original2;

        private Bitmap resultante;
        private int[] histograma = new int[256];
        //private int[] cHist;
        private int[,] conv3x3 = new int[3, 3];
        private int factor;
        private int offset;

        // Variables para el double buffer y evitar el flicker

        private int anchoVentana, altoVentana;        

        public Form1()
        {
            InitializeComponent();

            // Creamos el bitmap resultante del cuadro
            resultante = new Bitmap(800, 600);

            // Colocamos los valores para el dibujo con scrolls
            anchoVentana = 800;
            altoVentana = 600;
        }

        private void Convolucion()
        {
            Color oColor;
            int sumaR = 0, sumaG = 0, sumaB = 0;

            for (int x = 1; x < original.Width - 1; x++) 
            {
                for (int y = 1; y < original.Height - 1; y++) 
                {
                    sumaR = 0; sumaG = 0; sumaB = 0;
                    for (int a = -1; a < 2; a++)
                    {
                        for (int b = -1; b < 2; b++)
                        {
                            oColor = original.GetPixel(x + a, y + b);
                            sumaR = sumaR + (oColor.R * conv3x3[a + 1, b + 1]);
                            sumaG = sumaG + (oColor.G * conv3x3[a + 1, b + 1]);
                            sumaB = sumaB + (oColor.B * conv3x3[a + 1, b + 1]);
                        }
                    }
                    sumaR = (sumaR / factor) + offset;
                    sumaG = (sumaG / factor) + offset;
                    sumaB = (sumaB / factor) + offset;

                    if (sumaR > 255)
                        sumaR = 255;
                    else if (sumaR < 0)
                        sumaR = 0;

                    if (sumaG > 255)
                        sumaG = 255;
                    else if (sumaG < 0)
                        sumaG = 0;

                    if (sumaB > 255)
                        sumaB = 255;
                    else if (sumaB < 0)
                        sumaB = 0;

                    resultante.SetPixel(x, y, Color.FromArgb(sumaR, sumaG, sumaB));
                }
            }
        }

        private void ConvGris(int[,] pMatriz, Bitmap pImagen, int pInferior, int pSuperior)
        {
            Color oColor;
            int suma = 0;

            for (int x = 1; x < pImagen.Width - 1; x++)
            {
                for (int y = 1; y < pImagen.Height - 1; y++)
                {
                    suma = 0;
                    for (int a = -1; a < 2; a++)
                    {
                        for (int b = -1; b < 2; b++)
                        {
                            oColor = pImagen.GetPixel(x + a, y + b);
                            suma = suma + (oColor.R * pMatriz[a + 1, b + 1]);
                        }
                    }

                    if (suma < pInferior)
                        suma = 0;
                    else if (suma > pSuperior)
                        suma = 255;

                    resultante.SetPixel(x, y, Color.FromArgb(suma, suma, suma));
                }
            }
        }

        public Color interpolacionBilineal(double x, double y)
        {
            Color resultado = Color.Black;
            Color Color1, Color2;
            double fraccionX = 0, fraccionY = 0, unoMenosX = 0, unoMenosY = 0;
            int techoX = 0, techoY = 0, pisoX = 0, pisoY = 0;
            int rp1 = 0, rp2 = 0, rp3 = 0;
            int gp1 = 0, gp2 = 0, gp3 = 0;
            int bp1 = 0, bp2 = 0, bp3 = 0;
            int relleno = 128;

            // Si esta fuera de rango regresamos el relleno
            if (x < 0 || x >= original.Width - 1 || y < 0 || y >= original.Height - 1)
            {
                return Color.FromArgb(relleno, relleno, relleno);
            }

            pisoX = (int)Math.Floor(x);
            pisoY = (int)Math.Floor(y);
            techoX = (int)Math.Ceiling(x);
            techoY = (int)Math.Ceiling(y);

            fraccionX = x - pisoX;
            fraccionY = y - pisoY;

            unoMenosX = 1.0 - fraccionX;
            unoMenosY = 1.0 - fraccionY;

            Color1 = original.GetPixel(pisoX, pisoY);
            Color2 = original.GetPixel(techoX, pisoY);

            rp1 = (int)(unoMenosX * Color1.R + fraccionX * Color2.R);
            gp1 = (int)(unoMenosX * Color1.G + fraccionX * Color2.G);
            bp1 = (int)(unoMenosX * Color1.B + fraccionX * Color2.B);

            Color1 = original.GetPixel(pisoX, techoY);
            Color2 = original.GetPixel(techoX, techoY);

            rp2 = (int)(unoMenosX * Color1.R + fraccionX * Color2.R);
            gp2 = (int)(unoMenosX * Color1.G + fraccionX * Color2.G);
            bp2 = (int)(unoMenosX * Color1.B + fraccionX * Color2.B);

            rp3 = (int)(unoMenosY * rp1 + fraccionY * rp2);
            gp3 = (int)(unoMenosY * gp1 + fraccionY * gp2);
            bp3 = (int)(unoMenosY * bp1 + fraccionY * bp2);

            resultado = Color.FromArgb(rp3, gp3, bp3);

            return resultado;
        }

        private void abrirImagesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                original = (Bitmap)(Bitmap.FromFile(openFileDialog1.FileName));
                anchoVentana = original.Width;
                altoVentana = original.Height;

                resultante = original;

                // Forza el evento paint
                this.Invalidate();
            }
        }

        private void guardarImagesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                resultante.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Png);
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Verificamos que se tenga un bitmap instanciado
            if (resultante != null)
            {
                // Obtenemos el objeto graphics
                Graphics g = e.Graphics;

                // Calculamos el scroll
                AutoScrollMinSize = new Size(anchoVentana, altoVentana);

                // Copiamos el bitmap a la ventana
                g.DrawImage(resultante,
                    new Rectangle(this.AutoScrollPosition.X,
                    this.AutoScrollPosition.Y + 30,
                    anchoVentana, altoVentana));

                // Liberamos el recurso
                g.Dispose();
            }
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //int x = 0;
            //int y = 0;

            resultante = new Bitmap(original.Width, original.Height);

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    resultante.SetPixel(x, y, Color.FromArgb(120, 200, 120));
                }
            }
            this.Invalidate();
        }

        private void invertirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Invertimos la imagen, saca su negativo

            resultante = new Bitmap(original.Width, original.Height);
            Color rColor = new Color();
            Color oColor = new Color();

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color del pixel
                    oColor = original.GetPixel(x, y);

                    // Procesamos y obtenemos el nuevo color
                    rColor = Color.FromArgb(255 - oColor.R,
                                            255 - oColor.G,
                                            255 - oColor.B);

                    // Colocamos el color en resultante
                    resultante.SetPixel(x, y, rColor);
                }
            }
            this.Invalidate();
        }

        private void filtroColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Filtro color, solo presenta los pixeles de un componente y elimina los otros dos
            resultante = new Bitmap(original.Width, original.Height);
            Color rColor = new Color();
            Color oColor = new Color();

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color del pixel
                    oColor = original.GetPixel(x, y);

                    // Procesamos y obtenemos el nuevo color
                    rColor = Color.FromArgb(oColor.R,
                                            0,
                                            0);

                    // Colocamos el color en resultante
                    resultante.SetPixel(x, y, rColor);
                }
            }
            this.Invalidate();
        }

        private void aberracionCromaticaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a = 8; // tamano de la aberracion
            int r = 0, g = 0, b = 0;

            resultante = new Bitmap(original.Width, original.Height);
            
            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el verde
                    g = original.GetPixel(x, y).G;

                    // Obtenemos el rojo
                    if (x + a < original.Width)
                        r = original.GetPixel(x + a, y).R;
                    else
                        r = 0;

                    // Obtenemos el azul
                    if (x - a >= 0)
                        b = original.GetPixel(x - a, y).B;
                    else
                        b = 0;

                    // Colocamos el pixel
                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            this.Invalidate();
        }

        private void gammaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Aplicamos gama a la imagen

            resultante = new Bitmap(original.Width, original.Height);
            Color rColor = new Color();
            Color oColor = new Color();

            float r = 0, g = 0, b = 0;            

            // Factor para gamma
            float rg = 1.1f, gg = 1.9f, bg = 0.5f;

            // Creamos las rampas o tablas de cada color
            int[] rGamma = new int[256];
            int[] gGamma = new int[256];
            int[] bGamma = new int[256];

            for (int n = 0; n < 256; ++n)
            {
                rGamma[n] = Math.Min(255, (int)((255.0 * Math.Pow(n / 255.0f, 1.0f / rg)) + 0.5f));
                gGamma[n] = Math.Min(255, (int)((255.0 * Math.Pow(n / 255.0f, 1.0f / gg)) + 0.5f));
                bGamma[n] = Math.Min(255, (int)((255.0 * Math.Pow(n / 255.0f, 1.0f / bg)) + 0.5f));
            }

            // Aplicamos el gamma a la imagen
            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color del pixel
                    oColor = original.GetPixel(x, y);

                    r = rGamma[oColor.R];
                    g = gGamma[oColor.G];
                    b = bGamma[oColor.B];
                    
                    rColor = Color.FromArgb((int)r,
                                            (int)g,
                                            (int)b);

                    // Colocamos el color en resultante
                    resultante.SetPixel(x, y, rColor);
                }
            }
            this.Invalidate();
        }

        private void tonosDeGrisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Convertimos la imagen a tonos de gris

            resultante = new Bitmap(original.Width, original.Height);
            Color rColor = new Color();
            Color oColor = new Color();

            float g = 0;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color del pixel
                    oColor = original.GetPixel(x, y);

                    // Procesamos y obtenemos el nuevo color
                    // 0.2126 0.7152 0.0722   // Colorimetrica, basada en percepcion humana
                    // 0.299 0.587 0.114      // Luma, basado en brillo
                    // 0.267 0.678 0.0593

                    g = oColor.R * 0.2126f + oColor.G * 0.7152f + oColor.B * 0.0722f;

                    rColor = Color.FromArgb((int)g,
                                            (int)g,
                                            (int)g);

                    // Colocamos el color en resultante
                    resultante.SetPixel(x, y, rColor);
                }
            }
            this.Invalidate();
        }

        private void colorizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Queremos coloizar con (120,200,120)
            double rc = 120 / 255.0;
            double gc = 200 / 255.0;
            double bc = 120 / 255.0;

            Color miColor = new Color();
            int r = 0, g = 0, b = 0;

            // Creamos la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    miColor = resultante.GetPixel(x, y);

                    r = (int)(miColor.R * rc);
                    g = (int)(miColor.G * gc);
                    b = (int)(miColor.B * bc);

                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            this.Invalidate();
        }

        private void colorizarGradienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float r1 = 120, g1 = 230, b1 = 120;
            float r2 = 230, g2 = 100, b2 = 230;

            int r = 0, g = 0, b = 0;

            float dr = (r2 - r1) / original.Width;
            float dg = (g2 - g1) / original.Width;
            float db = (b2 - b1) / original.Width;

            Color oColor;

            // Obtenemos los tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color                    
                    oColor = resultante.GetPixel(x, y);

                    // Calculamos el color
                    r = (int)((r1 / 255.0f) * oColor.R);
                    g = (int)((g1 / 255.0f) * oColor.G);
                    b = (int)((b1 / 255.0f) * oColor.B);

                    if (r > 255) r = 255;
                    else if (r < 0) r = 0;

                    if (g > 255) g = 255;
                    else if (g < 0) g = 0;

                    if (b > 255) b = 255;
                    else if (b < 0) b = 0;

                    // Colocamos el color
                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }

                // Avanzamos color
                r1 = (r1 + dr);
                g1 = (g1 + dg);
                b1 = (b1 + db);
            }
            this.Invalidate();
        }

        private void brilloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Modificamos el brillo de la imagen
            int brillo = 64; // El valor va de -255 a 255
            float pBrillo = 1.2f; // El valor va de 0 a 2

            resultante = new Bitmap(original.Width, original.Height);
            //Color rColor = new Color();
            Color oColor = new Color();

            int r = 0, g = 0, b = 0;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color del pixel
                    oColor = original.GetPixel(x, y);

                    // Procesamos y obtenemos el nuevo color

                    // Metodo 1
                    //r = oColor.R + brillo;
                    //g = oColor.G + brillo;
                    //b = oColor.B + brillo;

                    // Metodo 2
                    r = (int)(oColor.R * pBrillo);
                    g = (int)(oColor.G * pBrillo);
                    b = (int)(oColor.B * pBrillo);

                    if (r > 255) r = 255;
                    else if (r < 0) r = 0;

                    if (g > 255) g = 255;
                    else if (g < 0) g = 0;

                    if (b > 255) b = 255;
                    else if (b < 0) b = 0;

                    // Colocamos el color
                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            this.Invalidate();
        }

        private void contrasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Modificamos el contraste de la imagen
            
            int contraste = -50; // El valor va de -100 a 100

            float c = (100.0f + contraste) / 100.0f;
            c *= c;

            resultante = new Bitmap(original.Width, original.Height);
            Color rColor = new Color();
            Color oColor = new Color();

            float r = 0, g = 0, b = 0;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color del pixel
                    oColor = original.GetPixel(x, y);

                    // Procesamos y obtenemos el nuevo color
                    r = ((((oColor.R / 255.0f) - 0.5f) * c) + 0.5f) * 255;
                    if (r > 255) r = 255;
                    else if (r < 0) r = 0;

                    g = ((((oColor.G / 255.0f) - 0.5f) * c) + 0.5f) * 255;
                    if (g > 255) g = 255;
                    else if (g < 0) g = 0;

                    b = ((((oColor.B / 255.0f) - 0.5f) * c) + 0.5f) * 255;
                    if (b > 255) b = 255;
                    else if (b < 0) b = 0;

                    rColor = Color.FromArgb((int)r, (int)g, (int)b);

                    // Colocamos el color en resultante
                    resultante.SetPixel(x, y, rColor);
                }
            }
            this.Invalidate();
        }

        private void flipHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Hacemos el flip horizontal
            resultante = new Bitmap(original.Width, original.Height);
            Color rColor = new Color();
            Color oColor = new Color();

            float g = 0;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color del pixel
                    oColor = original.GetPixel(x, y);
                    rColor = Color.FromArgb(oColor.R, oColor.G, oColor.B);

                    // Colocamos el color en resultante
                    resultante.SetPixel(original.Width - x - 1, y, rColor);
                }
            }
            this.Invalidate();
        }

        private void ruidoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int porcentaje = 65;

            // 0 a 200
            int rangoMin = 85;
            int rangoMax = 115;
            float pBrillo = 0;

            Random rnd = new Random();

            int r = 0, g = 0, b = 0;

            resultante = new Bitmap(original.Width, original.Height);
            Color rColor = new Color();
            Color oColor = new Color();

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Verificamos si el pixel tiene ruido o no
                    if (rnd.Next(1,100) <= porcentaje)
                    {
                        // Metodo 1
                        //rColor = Color.FromArgb(rnd.Next(rangoMin, rangoMax),
                        //                        rnd.Next(rangoMin, rangoMax),
                        //                        rnd.Next(rangoMin, rangoMax));

                        // Metodo 2
                        pBrillo = rnd.Next(rangoMin, rangoMax) / 100.0f;
                        oColor = original.GetPixel(x, y);

                        r = (int)(oColor.R * pBrillo);
                        g = (int)(oColor.G * pBrillo);
                        b = (int)(oColor.B * pBrillo);

                        if (r > 255) r = 255;
                        else if (r < 0) r = 0;

                        if (g > 255) g = 255;
                        else if (g < 0) g = 0;

                        if (b > 255) b = 255;
                        else if (b < 0) b = 0;

                        rColor = Color.FromArgb(r, g, b);
                    }
                    else
                    {
                        rColor = original.GetPixel(x, y);
                    }
                    resultante.SetPixel(x, y, rColor);
                }
            }
            this.Invalidate();
        }

        private void mosaicoToolStripMenuItem_Click(object sender, EventArgs e)
        {

            // La imagen debe de poderse dividir exactamente entre este valor
            int mosaico = 5;

            Color rColor;
            Color oColor;

            int r = 0, g = 0, b = 0, rs = 0, gs = 0, bs = 0;

            resultante = new Bitmap(original.Width, original.Height);

            for (int x = 0; x < original.Width - mosaico; x+= mosaico)
            {
                for (int y = 0; y < original.Height - mosaico; y+= mosaico)
                {
                    rs = 0; gs = 0; bs = 0;
                    // Obtenemos el promedio
                    for (int xm = x; xm < (x + mosaico); xm++) 
                    {
                        for (int ym = y; ym < (y + mosaico); ym++) 
                        {
                            oColor = original.GetPixel(xm, ym);
                            rs += oColor.R;
                            gs += oColor.G;
                            bs = oColor.B;
                        }                       
                    }

                    r = rs / (mosaico * mosaico);
                    g = gs / (mosaico * mosaico);
                    b = bs / (mosaico * mosaico);

                    rColor = Color.FromArgb(r, g, b);

                    // Dibujamos el mosaico
                    for (int xm = x; xm < (x + mosaico); xm++)
                    {
                        for (int ym = y; ym < (y + mosaico); ym++)
                        {
                            resultante.SetPixel(xm, ym, rColor);
                        }
                    }
                }
            }
            this.Invalidate();

        }

        private void transparenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap segundo = new Bitmap(256, 256);
            Color sColor;

            resultante = (Bitmap)original.Clone();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                segundo = (Bitmap)Bitmap.FromFile(openFileDialog1.FileName);
            }

            for (int x = 0; x < segundo.Width; x++)
            {
                for (int y = 0; y < segundo.Height; y++)
                {
                    // Obtenemos color
                    sColor = segundo.GetPixel(x, y);

                    // Verificamos si no es el color de transparencia
                    if (!(sColor.R == 0 && sColor.G == 0 && sColor.B == 255))
                    {
                        resultante.SetPixel(x, y, sColor);
                    }
                }
            }
            this.Invalidate();
        }

        private void hTonosGrisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Obtenemos primero la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            Color rColor = new Color();

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Obtenemos el color del pixel
                    rColor = resultante.GetPixel(x, y);
                    histograma[rColor.R]++;
                }                
            }
            //cHist = (int[])histograma.Clone();
            HistogramaForm hForm = new HistogramaForm(histograma);
            hForm.Show();

            // Suavizado del histograma
            int[] hs = new int[256];
            hs[0] = (histograma[0] + histograma[1]) / 2;
            hs[255] = (histograma[255] + histograma[254]) / 2;
            for (int n = 1; n < 254; n++)
            {
                hs[n] = (histograma[n - 1] + histograma[n] + histograma[n + 1]) / 3;
            }
            HistogramaForm hsForm = new HistogramaForm(hs);
            hsForm.Show();
        }

        private void ecualizarHistogramaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Console.WriteLine("Ecualizar");
            int cOriginal = 0, suma = 0;
            int[] sumah = new int[256];

            int tono = 0;
            Color miColor;

            double constante = 0;

            for (int x = 0; x < 256; x++)
            {
                suma = suma + histograma[x];                
                sumah[x] = suma;
            }
            double wh = original.Width * original.Height;
            constante = suma / wh;
            //Console.WriteLine("Suma - " + suma);
            //Console.WriteLine("w*h - " + wh);
            //Console.WriteLine("Constante - " + constante);

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    cOriginal = original.GetPixel(x, y).R;
                    double dtono = sumah[cOriginal] * constante;
                    tono = Convert.ToInt32(dtono);
                    if (tono > 255) tono = 255;

                    //Console.WriteLine("tono - "+tono);
                    miColor = Color.FromArgb(tono, tono, tono);
                    resultante.SetPixel(x, y, miColor);
                }
            }

            this.Invalidate();
        }

        private void suavizadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            conv3x3 = new int[,] { { 1, 1, 1 },
                                   { 1, 1, 1 },
                                   { 1, 1, 1 } };
            factor = 9;
            offset = 0;
            Convolucion();
            this.Invalidate();
        }

        private void blurGaussianoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            conv3x3 = new int[,] { { 1, 2, 1 },
                                   { 2, 4, 2 },
                                   { 1, 2, 1 } };
            factor = 16;
            // Si aumentamos offses aumenta brillo o al reves
            offset = 30;
            Convolucion();
            this.Invalidate();
        }

        private void sharpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            conv3x3 = new int[,] { { 0, -2, 0 },
                                   { -2, 11, -2 },
                                   { 0, -2, 0 } };
            factor = 5;
            offset = 96;
            Convolucion();
            this.Invalidate();
        }

        private void quickPhilipsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            conv3x3 = new int[,] { { -1, 0, 1 },
                                   {  0, 4, 0 },
                                   { -1, 0, -1 } };
            // Ponemos la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            Bitmap intermedio = (Bitmap)resultante.Clone();

            ConvGris(conv3x3, intermedio, 32, 64);

            this.Invalidate();
        }

        private void falerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //BORDES VERTICALES
            int[,] faler1 = new int[,] { {  -1, 0, 1 },
                                   {  -1, 0, 1 },
                                   {  -1, 0, 1 } };

            //BORDES HORIZONTALES
            int[,] faler2 = new int[,] { {  1, 1, 1 },
                                   {  0, 0, 0 },
                                   {  -1, -1, -1 } };

            //SE VE MEJOR
            int[,] faler3 = new int[,] { {  -1, -1, -1 },
                                   {  -1, 8, -1 },
                                   {  -1, -1, -1 } };

            int[,] faler4 = new int[,] { {  0, 1, 0 },
                                   {  -1, 0, 1 },
                                   {  0, -1, 0 } };


            // Ponemos la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            Bitmap intermedio = (Bitmap)resultante.Clone();

            ConvGris(faler3, intermedio, 32, 64);

            this.Invalidate();
        }

        private void kirschToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int[,] kirsch1 = new int[,] { {  5,5,5 },
                                   {  -3,0,-3 },
                                   {  -3,-3,-3 } };


            int[,] kirsch2 = new int[,] { {  -3,5,5 },
                                   {  -3,0,5 },
                                   {  -3,-3,-3 } };


            int[,] kirsch3 = new int[,] { {  -3,-3,5 },
                                   {  -3,0,5 },
                                   {  -3,-3,5 } };

            int[,] kirsch4 = new int[,] { {  -3,-3,-3 },
                                   {  -3,0,5 },
                                   {  -3,5,5 } };

            int[,] kirsch5 = new int[,] { {  -3,-3,-3 },
                                   {  -3,0,-3 },
                                   {  5,5,5 } };

            int[,] kirsch6 = new int[,] { {  -3,-3,-3 },
                                   {  5,0,-3 },
                                   {  5,5,-3 } };

            int[,] kirsch7 = new int[,] { {  5,-3,-3 },
                                   {  5,0,-3 },
                                   {  5,-3,-3 } };

            int[,] kirsch8 = new int[,] { {  5,5,-3 },
                                   {  5,0,-3 },
                                   {  -3,-3,-3 } };


            // Ponemos la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            Bitmap intermedio = (Bitmap)resultante.Clone();

            ConvGris(kirsch8, intermedio, 128, 129);

            this.Invalidate();
        }

        private void prewittToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int[,] prewit1 = new int[,] { {  1,1,1 },
                                        {  1,-2,1 },
                                        {  -1,-1,-1 } };

            int[,] prewit2 = new int[,] { {  1,1,1 },
                                        {  1,-2,-1 },
                                        {  1,-1,-1 } };

            int[,] prewit3 = new int[,] { {  1,1,-1 },
                                        {  1,-2,-1 },
                                        {  1,1,-1 } };

            int[,] prewit4 = new int[,] { {  1,-1,-1 },
                                        {  1,-2,-1 },
                                        {  1,1,1 } };

            int[,] prewit5 = new int[,] { {  -1,-1,-1 },
                                        {  1,-2,1 },
                                        {  1,1,1 } };

            int[,] prewit6 = new int[,] { {  -1,-1,1 },
                                        {  -1,-2,1 },
                                        {  1,1,1 } };

            int[,] prewit7 = new int[,] { {  -1,1,1 },
                                        {  -1,-2,1 },
                                        {  -1,1,1 } };

            int[,] prewit8 = new int[,] { {  1,1,1 },
                                        {  -1,-2,1 },
                                        {  -1,-1,1 } };

            // Ponemos la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            Bitmap intermedio = (Bitmap)resultante.Clone();

            ConvGris(prewit7, intermedio, 0, 255);

            this.Invalidate();

        }

        private void sobelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int[,] sobel1 = new int[,] { {  1,2,1 },
                                        {  0,0,0 },
                                        {  -1,-2,-1 } };

            int[,] sobel2 = new int[,] { {  2,1,0 },
                                        {  1,0,-1},
                                        {  0,-1,-2 } };

            int[,] prewit3 = new int[,] { {  1,0,-1 },
                                        {  2,0,-2 },
                                        {  1,0,-1 } };

            int[,] sobel4 = new int[,] { {  0,-1,-2 },
                                        {  1,0,-1 },
                                        {  2,1,0 } };

            int[,] sobel5 = new int[,] { {  -1,-2,-1 },
                                        {  0,0,0 },
                                        {  1,2,1 } };

            int[,] sobel6 = new int[,] { {  -2,-1,0 },
                                        {  -1,0,1 },
                                        {  0,1,2 } };

            int[,] sobel7 = new int[,] { {  -1,0,1 },
                                        {  -2,0,2 },
                                        {  -1,0,1 } };

            int[,] sobel8 = new int[,] { {  0,1,2 },
                                        {  -1,0,1 },
                                        {  -2,-1,0 } };

            // Ponemos la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            Bitmap intermedio = (Bitmap)resultante.Clone();

            ConvGris(sobel5, intermedio, 0, 255);

            this.Invalidate();
        }

        private void homogeneidadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            int absDif = 0, maxDif = 0, diferencia = 0;

            for (int x = 1; x < original.Width - 1; x++)
            {
                for (int y = 1; y < original.Height - 1; y++)
                {
                    maxDif = 0;

                    // Encontramos la maxima diferencia con los vecinos
                    for (int a = -1; a < 2; a++)
                    {
                        for (int b = -1; b < 2; b++)
                        {
                            diferencia = original.GetPixel(x, y).R - original.GetPixel(x + a, y + b).R;
                            absDif = Math.Abs(diferencia);
                            
                            if (absDif > maxDif)
                                maxDif = absDif;
                        }
                    }

                    // Para mejorar el contraste         
                    if (maxDif > 16) // Experimentar valores
                        maxDif = 255;
                    else
                        maxDif = 0;

                    resultante.SetPixel(x, y, Color.FromArgb(maxDif, maxDif, maxDif));
                }
            }
            this.Invalidate();
        }

        private void diferenciaGaussianaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Creamos las matrices Gaussianas
            int[,] g7 =
            {
                {0,0,-1,-1,-1,0,0 },
                {0,-2,-3,-3,-3,-2,0 },
                {-1,-3,5,5,5,-3,-1 },
                {-1,-3,5,16,5,-3,-1 },
                {-1,-3,5,5,5,-3,-1 },
                {0,-2,-3,-3,-3,-2,0 },
                {0,0,-1,-1,-1,0,0 }
            };

            int[,] g9 =
            {
                {0,0,0,-1,-1,-1,0,0,0 },
                {0,-2,-3,-3,-3,-3,-3,-2,0 },
                {0,-3,-2,-1,-1,-1,-2,-3,0 },
                {-1,-3,-1,9,9,9,-1,-3,-1 },
                {-1,-3,-1,9,19,9,-1,-3,-1 },
                 {-1,-3,-1,9,9,9,-1,-3,-1 },
                  {0,-3,-2,-1,-1,-1,-2,-3,0 },
                  {0,-2,-3,-3,-3,-3,-3,-2,0 },
                  {0,0,0,-1,-1,-1,0,0,0 },
            };

            // Seleccionamos el tamano de la matriz
            int tamano = 9;

            resultante = new Bitmap(original.Width, original.Height);
            long suma = 0;
            int inferior = 0, superior = 0, inicioX = 0, finX = 0, inicioY = 0, finY = 0;

            if (tamano == 7)
            {
                inferior = -3; superior = 4;
                inicioX = 3; inicioY = 3;
                finX = original.Width - 3;
                finY = original.Height - 3;
            }
            if (tamano == 9)
            {
                inferior = -4; superior = 5;
                inicioX = 4; inicioY = 4;
                finX = original.Width - 4;
                finY = original.Height - 4;
            }

            for (int x = inicioX; x < finX; x++)
            {
                for (int y = inicioY; y < finY; y++)
                {
                    suma = 0;
                    for (int a = inferior; a < superior; a++)
                    {
                        for (int b = inferior; b < superior; b++)
                        {
                            if (tamano == 7)
                            {
                                suma = suma + original.GetPixel(x + a, y + b).R * g7[a + 3, b + 3];
                            }
                            if (tamano == 9)
                            {
                                suma = suma + original.GetPixel(x + a, y + b).R * g9[a + 4, b + 4];
                            }
                        }
                    }

                    if (suma < 0)
                        suma = 0;
                    if (suma > 255)
                        suma = 255;

                    resultante.SetPixel(x, y, Color.FromArgb((int)suma, (int)suma, (int)suma));
                }
            }
            this.Invalidate();
        }

        private void johnsonContrasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            int promedio = 0, sumaPromedio = 0, sumaMatriz = 0, tono = 0;
            int escalar = 25;

            // Quick
            int[,] matrizBordes =
            {

                {-1,0,-1 },
                {0,4,0 },
                {-1,0,-1 }
            };
            int[,] mPromedio =
            {
                {1,1,1 },
                {1,1,1 },
                {1,1,1 }
            };

            int limite = 2;

            for (int x = 1; x < original.Width - 1; x++) 
            {
                for (int y = 1; y < original.Height - 1; y++) 
                {
                    sumaMatriz = 0; sumaPromedio = 0;
                    for (int a = -1; a < 2; a++)
                    {
                        for (int b = -1; b < 2; b++)
                        {
                            sumaMatriz += original.GetPixel(x + a, y + b).R * matrizBordes[a + 1, b + 1] * escalar;
                            sumaPromedio += original.GetPixel(x + a, y + b).R * mPromedio[a + 1, b + 1];
                        }
                    }
                    promedio = sumaPromedio / 9;
                    if (promedio == 0)
                        promedio = 1;

                    tono = sumaMatriz / promedio;

                    if (tono > limite)
                        tono = 255;
                    if (tono < 0)
                        tono = 0;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void lowPassToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            int[,] lp6 =
            {
                {0,1,0 },
                {1,2,1 },
                {0,1,0 }
            };
            int[,] lp9 =
            {
                {1,1,1 },
                {1,1,1 },
                {1,1,1 }
            };
            int[,] lp10 =
            {
                {1,1,1 },
                {1,2,1 },
                {1,1,1 }
            };
            int[,] lp16 =
            {
                {1,2,1 },
                {2,4,2 },
                {1,2,1 }
            };
            int[,] lp32 =
            {
                {1,4,1 },
                {4,12,4 },
                {1,4,1 }
            };

            resultante = new Bitmap(original.Width, original.Height);
            int divisor = 6; // Divisor, usar la matriz apropiada a este valor
            int suma = 0;
            // Ponemos la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            for (int x = 1; x < original.Width - 1; x++)
            {
                for (int y = 1; y < original.Height - 1; y++)
                {
                    suma = 0;
                    for (int a = -1; a < 2; a++)
                    {
                        for (int b = -1; b < 2; b++)
                        {
                            // Colocar la matriz adecuada
                            suma += original.GetPixel(x + a, y + b).R * lp6[a + 1, b + 1];
                        }
                    }
                    suma = suma / divisor;
                    if (suma < 0)
                        suma = 0;
                    if (suma > 255)
                        suma = 255;

                    resultante.SetPixel(x, y, Color.FromArgb(suma, suma, suma));
                }
            }
            this.Invalidate();
        }

        private void highPassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int[,] hp1 =
            {
                {0,-1,0 },
                {-1,5,-1 },
                {0,-1,0 }
            };
            int[,] hp2 =
            {
                {-1,-1,-1 },
                {-1,9,-1 },
                {-1,-1,-1 }
            };
            int[,] hp3 =
            {
                {1,-2,1 },
                {-2,5,-2 },
                {1,-2,1 }
            };

            resultante = new Bitmap(original.Width, original.Height);
            int divisor = 6; // Divisor, usar la matriz apropiada a este valor
            int suma = 0;
            // Ponemos la imagen en tonos de gris
            tonosDeGrisToolStripMenuItem_Click(sender, e);

            for (int x = 1; x < original.Width - 1; x++)
            {
                for (int y = 1; y < original.Height - 1; y++)
                {
                    suma = 0;
                    for (int a = -1; a < 2; a++)
                    {
                        for (int b = -1; b < 2; b++)
                        {
                            // Colocar la matriz adecuada
                            suma += original.GetPixel(x + a, y + b).R * hp1[a + 1, b + 1];
                        }
                    }
                    suma = suma / divisor;
                    if (suma < 0)
                        suma = 0;
                    if (suma > 255)
                        suma = 255;

                    resultante.SetPixel(x, y, Color.FromArgb(suma, suma, suma));
                }
            }
            this.Invalidate();
        }

        private void abrirImagen2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                original2 = (Bitmap)(Bitmap.FromFile(openFileDialog1.FileName));
                anchoVentana = original.Width;
                altoVentana = original.Height;

                resultante = original;

                this.Invalidate();
            }
        }

        private void restaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Se restan los valores
            // Util para detectar cambios en la imagen (movimiento)

            resultante = new Bitmap(original.Width, original.Height);
            int r = 0, g = 0, b = 0;
            Color oColor1, oColor2;

            for (int x = 0; x < original.Width; x++) 
            {
                for (int y = 0; y < original.Height; y++) 
                {
                    // Obtenemos colores
                    oColor1 = original.GetPixel(x, y);
                    oColor2 = original2.GetPixel(x, y);

                    // Realizamos la resta
                    r = oColor1.R - oColor2.R;
                    g = oColor1.G - oColor2.G;
                    b = oColor1.B - oColor2.B;

                    if (r > 255)
                        r = 255;
                    else if (r < 0)
                        r = 0;

                    if (g > 255)
                        g = 255;
                    else if (g < 0)
                        g = 0;

                    if (b > 255)
                        b = 255;
                    else if (b < 0)
                        b = 0;

                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            this.Invalidate();
        }

        private void adicionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            int r = 0, g = 0, b = 0;
            Color oColor1, oColor2;

            // Porcentaje de contribucion
            double p1 = 0.5;
            double p2 = 1 - p1;

            for (int x = 0; x < original.Width; x++) 
            {
                for (int y = 0; y < original.Height; y++) 
                {
                    // Obtenemos colores
                    oColor1 = original.GetPixel(x, y);
                    oColor2 = original2.GetPixel(x, y);

                    // Realizamos la adicion
                    r = (int)(p1 * oColor1.R + p2 * oColor2.R);
                    g = (int)(p1 * oColor1.G + p2 * oColor2.G);
                    b = (int)(p1 * oColor1.B + p2 * oColor2.B);

                    if (r > 255)
                        r = 255;
                    else if (r < 0)
                        r = 0;

                    if (g > 255)
                        g = 255;
                    else if (g < 0)
                        g = 0;

                    if (b > 255)
                        b = 255;
                    else if (b < 0)
                        b = 0;

                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            this.Invalidate();
        }

        private void aNDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            int r = 0, g = 0, b = 0;
            Color oColor1, oColor2;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    oColor1 = original.GetPixel(x, y);
                    oColor2 = original2.GetPixel(x, y);

                    // Esquema bitwise
                    r = oColor1.R & oColor2.R;
                    g = oColor1.G & oColor2.G;
                    b = oColor1.B & oColor2.B;

                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            this.Invalidate();
        }

        private void nANDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            int r = 0, g = 0, b = 0;
            Color oColor1, oColor2;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    oColor1 = original.GetPixel(x, y);
                    oColor2 = original2.GetPixel(x, y);

                    // Esquema bitwise
                    r = oColor1.R & oColor2.R;
                    g = oColor1.G & oColor2.G;
                    b = oColor1.B & oColor2.B;

                    resultante.SetPixel(x, y, Color.FromArgb(255 - r, 255 - g, 255 - b));
                }
            }
            this.Invalidate();
        }

        private void oRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            int r = 0, g = 0, b = 0;
            Color oColor1, oColor2;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    oColor1 = original.GetPixel(x, y);
                    oColor2 = original2.GetPixel(x, y);

                    // Esquema bitwise
                    r = oColor1.R | oColor2.R;
                    g = oColor1.G | oColor2.G;
                    b = oColor1.B | oColor2.B;

                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            this.Invalidate();
        }

        private void nORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            int r = 0, g = 0, b = 0;
            Color oColor1, oColor2;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    oColor1 = original.GetPixel(x, y);
                    oColor2 = original2.GetPixel(x, y);

                    // Esquema bitwise
                    r = oColor1.R | oColor2.R;
                    g = oColor1.G | oColor2.G;
                    b = oColor1.B | oColor2.B;

                    resultante.SetPixel(x, y, Color.FromArgb(255 - r, 255 - g, 255 - b));
                }
            }
            this.Invalidate();
        }

        private void gANDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;            

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 != 0 && g2 != 0)
                        tono = g1;
                    else
                        tono = 0;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void gNANDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;
            int valor = 128;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 != 0 && g2 != 0)
                        tono = 0;
                    else
                        tono = valor;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void gORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 != 0 || g2 != 0)
                        tono = g1;
                    else
                        tono = g2;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void gNORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;
            int valor = 128;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 != 0 || g2 != 0)
                        tono = valor;
                    else
                        tono = 0;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void gXORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 != 0 && g2 == 0)
                        tono = g1;
                    if (g1 == 0 && g2 != 0)
                        tono = g2;
                    if (g1 == 0 && g2 == 0)
                        tono = 0;
                    if (g1 != 0 && g2 != 0)
                        tono = 0;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void gNOTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0;
            int tono = 0;
            int valor = 128;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;                    

                    if (g1 == valor)
                        tono = 0;
                    else
                        tono = g1;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void noCeroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Pone los pixeles que no son cero sobre la segunda imagen

            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;
            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 != 0)
                        tono = g1;
                    else
                        tono = g2;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void ceroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Coloca los pixeles cero sobre la segunda imagen

            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;
            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 == 0)
                        tono = g1;
                    else
                        tono = g2;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void mayorQueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;
            int valor = 128;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 >= valor)
                        tono = g1;
                    else
                        tono = g2;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void menorQueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Probar con borde y tonos de gris
            resultante = new Bitmap(original.Width, original.Height);
            int g1 = 0, g2 = 0;
            int tono = 0;
            int valor = 128;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    g1 = original.GetPixel(x, y).R;
                    g2 = original2.GetPixel(x, y).R;

                    if (g1 <= valor)
                        tono = g1;
                    else
                        tono = g2;

                    resultante.SetPixel(x, y, Color.FromArgb(tono, tono, tono));
                }
            }
            this.Invalidate();
        }

        private void basicoGeometriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            int r = 0, g = 0, b = 0;
            Color oColor;

            // Variables
            double anguloRot = 0; // Angulo de rotacion
            double estiramientoX = 0; //1.1 0.8
            double estiramientoY = 0;
            double despX = 0, despY = 0; // Desplazamiento en X y en Y
            double curvX = 0.001, curvY = 0; // Curvatura en X y en Y

            // Obtenemos el coseno y el seno del angulo
            double cosa = Math.Cos(anguloRot / 57.29577951);
            double sina = Math.Sin(anguloRot / 57.29577951);

            // Obtener el divisor y numerador de cada eje para el estiramiento
            double xdiv = 1, xnum = 0;
            double ydiv = 1, ynum = 0;

            // Cuidamos de no tener division entre cero
            if (estiramientoX < 0.00001)
            {
                xdiv = 1.0;
                xnum = 0.0;
            }
            else
            {
                xdiv = estiramientoX;
                xnum = 1.0;
            }

            if (estiramientoY < 0.00001)
            {
                ydiv = 1.0;
                ynum = 0.0;
            }
            else
            {
                ydiv = estiramientoY;
                ynum = 1.0;
            }

            // Variables para la posicion de donde obtenemos el color para el pixel
            double posX = 0, posY = 0;

            for (int x = 0; x < original.Width; x++)
            {
                for (int y = 0; y < original.Height; y++)
                {
                    // Calculamos la posicion del pixel de donde tomaremos la informacion
                    posX = (x * cosa) + (y * sina) + despX + (xnum * x / xdiv) + (curvX * x * y);
                    posY = (y * cosa) + (x * sina) + despY + (ynum * y / ydiv) + (curvY * x * y);
                    if (estiramientoX != 0)
                        posX -= (x * cosa + y * sina);
                    if (estiramientoY != 0)
                        posY -= (y * cosa - x * sina);

                    // Obtenemos el pixel de la posicion calculada via interpolacion
                    oColor = interpolacionBilineal(posX, posY);
                    r = oColor.R; g = oColor.G; b = oColor.B;

                    resultante.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            this.Invalidate();
        }

        private void warpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            // Punto donde hacemos el warp
            int xWarp = 100, yWarp = 120;
            // Punto medio de la iamgen
            int medioX = original.Width / 2;
            int medioY = original.Height / 2;

            // Cuarto superior izquierdo
            // Coordenadas de los puntos del poliedro
            int x1 = 0, x2 = medioX, x3 = xWarp, x4 = 0;
            int y1 = 0, y2 = 0, y3 = yWarp, y4 = medioY;

            // Offset para el cuadrante
            int offsetX = 0, offsetY = 0;

            // Para usar o no la interpolacion lineal
            bool bilineal = true;

            if (bilineal)
                warpBilineal(x1, y1, x2, y2, x3, y3, x4, y4, offsetX, offsetY);
            else
                warpNormal(x1, y1, x2, y2, x3, y3, x4, y4, offsetX, offsetY);

            // Cuadro superior derecho
            // Coordenadas de los puntos del poliedro
            x1 = medioX; x2 = original.Width - 1; x3 = original.Width - 1; x4 = xWarp;
            y1 = 0; y2 = 0; y3 = medioY; y4 = yWarp;

            // Offset para el cuadrante
            offsetX = medioX; offsetY = 0;

            if (bilineal)
                warpBilineal(x1, y1, x2, y2, x3, y3, x4, y4, offsetX, offsetY);
            else
                warpNormal(x1, y1, x2, y2, x3, y3, x4, y4, offsetX, offsetY);

            // Cuadro inferior derecho
            // Coordenadas de los puntos del poliedro
            x1 = xWarp; x2 = original.Width - 1; x3 = original.Width - 1; x4 = medioX;
            y1 = yWarp; y2 = medioY; y3 = original.Height - 1; y4 = original.Height - 1;

            // Offset para el cuadrante
            offsetX = medioX; offsetY = medioY;

            if (bilineal)
                warpBilineal(x1, y1, x2, y2, x3, y3, x4, y4, offsetX, offsetY);
            else
                warpNormal(x1, y1, x2, y2, x3, y3, x4, y4, offsetX, offsetY);

            // Cuadro inferior izquierdo
            // Coordenadas de los puntos del poliedro
            x1 = 0; x2 = xWarp; x3 = medioX; x4 = 0;
            y1 = medioY; y2 = yWarp; y3 = original.Height - 1; y4 = original.Height - 1;

            // Offset para el cuadrante
            offsetX = 0; offsetY = medioY;

            if (bilineal)
                warpBilineal(x1, y1, x2, y2, x3, y3, x4, y4, offsetX, offsetY);
            else
                warpNormal(x1, y1, x2, y2, x3, y3, x4, y4, offsetX, offsetY);

            this.Invalidate();
        }

        private void warpNormal(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int extraX, int extraY)
        {
            int alto = original.Height, ancho = original.Width;
            int relleno = 128;
            Color miColor;
            int medioX = ancho / 2, medioY = alto / 2;
            int denominador = medioX * medioY;
            // Colocamos los terminos para la transformacion espacial
            int xa = x2 - x1, xb = x4 - x1, xab = x1 - x2 + x3 - x4;
            int ya = y2 - y1, yb = y4 - y1, yab = y1 - y2 + y3 - y4;
            // Recorremos el cuadrante y hacemos la transformacion espacial
            // Coordenadas para encontrar el color en la imagen
            int xImagen = 0, yImagen = 0;
            for (int y = 0; y < medioY; y++)
            {
                for (int x = 0; x < medioX; x++)
                {
                    xImagen = x1 + (xa * x) / medioX + (xb * y) / medioY + (xab * y * x) / denominador;
                    yImagen = y1 + (ya * x) / medioX + (yb * y) / medioY + (yab * y * x) / denominador;
                    // Si estamos fuera de la imagen ponemos color de relleno
                    if (xImagen < 0 || xImagen >= ancho || yImagen < 0 || y >= alto)
                    {
                        resultante.SetPixel(x + extraX, y + extraY, Color.FromArgb(relleno, relleno, relleno));
                    }
                    else
                    {
                        // Encontramos el color segun las coordenadas
                        miColor = original.GetPixel(xImagen, yImagen);
                        // Ponemos el color
                        resultante.SetPixel(x + extraX, y + extraY, miColor);
                    }
                }
            }
        }

        private void warpBilineal(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int extraX, int extraY)
        {
            int alto = original.Height, ancho = original.Width;
            int relleno = 128;
            Color miColor;
            int medioX = ancho / 2, medioY = alto / 2;
            int denominador = medioX * medioY;
            // Colocamos los terminos para la transformacion espacial
            int xa = x2 - x1, xb = x4 - x1, xab = x1 - x2 + x3 - x4;
            int ya = y2 - y1, yb = y4 - y1, yab = y1 - y2 + y3 - y4;
            // Para usar las coordenadas como dobles
            double dy = 0, dx = 0;
            double xImagen = 0, yImagen = 0;
            for (int y = 0; y < medioY; y++)
            {
                for (int x = 0; x < medioX; x++)
                {
                    dy = y;
                    dx = x;
                    xImagen = x1 + (xa * dx) / medioX + (xb * dy) / medioY + (xab * dy * dx) / denominador;
                    yImagen = y1 + (ya * dx) / medioX + (yb * dy) / medioY + (yab * dy * dx) / denominador;

                    miColor = interpolacionBilineal(xImagen, yImagen);
                    resultante.SetPixel(x + extraX, y + extraY, miColor);
                }
            }
        }

        private void objectWarpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resultante = new Bitmap(original.Width, original.Height);
            // Colocamos los puntos
            int x1 = 100, y1 = 100;
            int x2 = 500, y2 = 200;
            int x3 = 400, y3 = 500;
            int x4 = 85,  y4 = 550;

            estiramientoBilineal(x1, y1, x2, y2, x3, y3, x4, y4);

            this.Invalidate();
        }

        private void estiramientoBilineal(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
        {
            int ancho = original.Width;
            int alto = original.Height;
            double denominador = ancho * alto;
            // Colocamos los terminos para la transformacion espacial
            double xa = x2 - x1, xb = x4 - x1, xab = x1 - x2 + x3 - x4;
            double ya = y2 - y1, yb = y4 - y1, yab = y1 - y2 + y3 - y4;

            double dx = 0, dy = 0, xImagen = 0, yImagen = 0;
            Color miColor;

            for (int y = 0; y < alto; y++)
            {
                for (int x = 0; x < ancho; x++)
                {
                    dy = y;
                    dx = x;
                    xImagen = x1 + (xa * dx) / ancho + (xb * dy) / alto + (xab * dy * dx) / denominador;
                    yImagen = y1 + (ya * dx) / ancho + (yb * dy) / alto + (yab * dy * dx) / denominador;

                    miColor = interpolacionBilineal(xImagen, yImagen);
                    resultante.SetPixel(x, y, miColor);
                }
            }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Cerramos la aplicacion
            this.Close();
        }

    }
}
