﻿using System;

namespace _21_OperadorTernario
{
    class Program
    {
        static void Main(string[] args)
        {
            // Operador terniario
            // condicion ? V : F
            int a = 15;
            int b = 3;
            int r = 0;
            // Selecciona el mayor
            r = (a > b) ? a : b;
            Console.WriteLine("El mayor es {0}", r);
            // Llevamos a cabo una asignacion
            r = (a < 6) ? a = 10 : a = -10;
            Console.WriteLine("a{0}, r{1}", a, r);
            // Hacemos incremento, probar tambien ++b
            r = (a < 5) ? a++ : b++;
            //r = (a < 5) ? ++a : b++;
            Console.WriteLine("a={0}, b={1}, r={2}", a, b, r);
            // Hacemos invocacion a un metodo
            r = (a < 0) ? mensaje() : 0;
            Console.WriteLine("r={0}", r);

            Console.ReadKey();
        }
        // Este es el metodo, debe regresar un valor para que este caiga en r
        public static int mensaje()
        {
            Console.WriteLine("Hola");
            return 50;
        }
    }
}
