﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _29_ReimplementacionIterfacezHerencia
{
    class CPrueba : ICalculable
    {
        private double n;
        public CPrueba(double pValor)
        {
            n = pValor;
        }
        // Implementacion de ICalculable
        public void calcular(double pNumero)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Estoy en CPrueba {0}", n * pNumero); ;
        }
    }
}
