﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _29_ReimplementacionIterfacezHerencia
{
    class CTest : CPrueba, ICalculable
    {
        double miNumero;

        public CTest(double pNumero) : base(pNumero)
        {
            miNumero = pNumero;
        }
        public new void calcular(double pValor)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Version de Test {0}", miNumero + pValor);
        }
    }
}
