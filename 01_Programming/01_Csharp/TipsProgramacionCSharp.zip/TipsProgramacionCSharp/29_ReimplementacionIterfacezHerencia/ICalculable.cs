﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _29_ReimplementacionIterfacezHerencia
{
    interface ICalculable
    {
        void calcular(double pNumero);
    }
}
