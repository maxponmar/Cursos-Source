﻿using System;

namespace _06_Constantes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Programa que muestra el uso de constantes
            // Variables
            const double impuesto = 0.16;
            double valor = 5000.0;
            double impuestoPagar = 0;
            double costoFinal = 0;

            string dato = "";
            double costoextra = 0;

            impuestoPagar = valor * impuesto;
            costoFinal = valor + impuestoPagar;
            Console.WriteLine("El total es {0}", costoFinal);

            // Ahora mostramos el uso de readonly
            Console.WriteLine("Dame el valor del costo extra");
            dato = Console.ReadLine();
            costoextra = Convert.ToDouble(dato);
            miEjemplo objeto = new miEjemplo(costoextra);
            costoFinal += objeto.Costoextra;
            Console.WriteLine("El gran total es {0}",costoFinal);
            Console.ReadKey();
        }
        class miEjemplo
        {
            private readonly double costoextra;
            // Solo puede ser dentro de un constructor
            public miEjemplo(double pExtra)
            {
                // Asignamos el readonly
                costoextra = pExtra;
            }
            public double Costoextra => costoextra;
        }
    }
}
