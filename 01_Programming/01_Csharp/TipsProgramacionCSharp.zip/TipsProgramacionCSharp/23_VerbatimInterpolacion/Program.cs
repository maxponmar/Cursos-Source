﻿using System;

namespace _23_VerbatimInterpolacion
{
    class Program
    {
        static void Main(string[] args)
        {
            // Trabajo con cadenas
            // Verbatim, coloca el contenido de la cadena de forma literal
            // ignora los codigos/secuencias de escape
            string a = "hola a \todos";
            Console.WriteLine(a);

            string b = @"hola a \todos";

            string c = @"Permite usar                      
                      multiples lineas
               a la vez";
            Console.WriteLine(c);
            Console.WriteLine("----------------");

            // Interpolacion
            // Pueden tener expresiones adentro de la cadena que seran evaluedas
            // y convertidas a cadenas
            // las expresiones van entre llaves { }
            int n = 5, m = 6;
            string d = "La interpolacion {n * m} da ese resultado";
            Console.WriteLine(d);
            d = $"La interpolacion {n * m} da ese resultado";
            Console.WriteLine(d);

            string e = $"El valor dado {DaValor()} por la funcion";
            Console.WriteLine(e);

            string f = $@"Mezclamos los dos
                              Evalua {DaValor() * n - m} 
            en varias lineas";
            Console.WriteLine(f);

            Console.ReadKey();
        }
        public static int DaValor()
        {
            return 15;
        }
    }
}
