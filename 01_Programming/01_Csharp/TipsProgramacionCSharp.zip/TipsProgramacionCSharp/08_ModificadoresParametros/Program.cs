﻿using System;

namespace _08_ModificadoresParametros
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables
            int a = 5;
            int b = 8;
            int r = 0;

            int cantidad = 8;
            int sumatoria = 0;
            int factorial = 0;

            double prome = 0;

            // Invocamos a metodo normal
            r = SumaNormal(a, b);
            Console.WriteLine("El resultado es {0}", r);
            // Intentamos intercambio normal
            Console.WriteLine("Antes del cambio: a={0}, b={1}", a, b);
            IntercambioNormal(a, b);
            Console.WriteLine("Despues del cambio: a={0}, b={1}", a, b);
            Console.WriteLine();
            // Intentamos intercambio por referencia
            Console.WriteLine("Antes del cambio: a={0}, b={1}", a, b);
            IntercambioReferencia(ref a, ref b);
            Console.WriteLine("Despues del cambio: a={0}, b={1}", a, b);
            // Hacemos la invocacion para calcular sumatoria y factorial
            Calculador(cantidad, out sumatoria, out factorial);
            Console.WriteLine("Sumatoria={0}, factorial={1}", sumatoria, factorial);
            Console.WriteLine();
            // Calcula varios promedios con numero diferente de parametros
            prome = Promedio(3.5, 6.7, 8.9);
            Console.WriteLine("El promedio es {0}", prome);
            prome = Promedio(8, 8.7, 8.8, 10, 9, 7);
            Console.WriteLine("El promedio es {0}", prome);
            prome = Promedio(7.8, 9);
            Console.WriteLine("El promedio es {0}", prome);
            Console.ReadKey();
        }
        // Metodo normal
        public static int SumaNormal(int x, int y)
        {
            return x + y;
        }
        public static void IntercambioNormal(int x, int y)
        {
            int temp = x;
            x = y;
            y = temp;
        }
        // Intercambio por referencia
        public static void IntercambioReferencia(ref int x, ref int y)
        {
            int temp = x;
            x = y;
            y = temp;
        }
        // Metodo que por medio de oit regresa valoress
        public static void Calculador(int n, out int s, out int f)
        {
            s = 0;
            f = 1;
            int m = 0;
            for (m = 1; m <= n; m++) 
            {
                s += m;
                f *= m;
            }
        }
        // Metodo que calcula el promedio de cualquier cantidad de parametros
        public static double Promedio(params double[] valores)
        {
            double suma = 0;
            double prom = 0;
            int n = 0;
            for (n = 0; n < valores.Length; n++)
            {
                suma += valores[n];
            }
            prom = suma / valores.Length;
            return prom;
        }
    }
}
