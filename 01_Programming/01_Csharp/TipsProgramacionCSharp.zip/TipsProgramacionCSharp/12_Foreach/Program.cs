﻿using System;
using System.Collections;
namespace _12_Foreach
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables
            ArrayList ciudades = new ArrayList();
            int[] valores = new int[4];
            // Llenamos la informacion
            ciudades.Add("New York");
            ciudades.Add("Londres");
            ciudades.Add("Paris");
            ciudades.Add("Pekin");
            ciudades.Add("Moscu");

            valores[0] = 5;
            valores[1] = 9;
            valores[2] = 7;
            valores[3] = 10;
            // Mostramos por iteracion
            foreach (string cd in ciudades)
            {
                Console.WriteLine("La ciudad es {0}", cd);
            }
            foreach (int numero in valores)
            {
                Console.WriteLine("El numero es {0}", valores);
            }
        }
    }
}
