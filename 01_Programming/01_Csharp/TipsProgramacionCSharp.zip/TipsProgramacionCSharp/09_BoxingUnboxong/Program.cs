﻿using System;
using System.Collections;
namespace _09_BoxingUnboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            // Programa que muestra el concepto de boxing y unboxing
            // Variable normal
            int valor = 5;
            // hacemos el boxing creando una referencia
            object boxDato = 7;
            // Esta linea marca error
            //valor = valor + boxDato;

            // hacemos el unboxing
            int unboxDato = (int)boxDato;
            valor = valor + unboxDato;
            Console.WriteLine(valor);
            Muestra(valor);
            Multiplica(valor);

            // Boxing que ocurre en las colecciones
            ArrayList miArray = new ArrayList();

            miArray.Add(5);
            miArray.Add(9);
            // Esta linea marca error
            //int resultado = miArray[0] + miArray[1];
            int resultado = (int)miArray[0] + (int)miArray[1];
            Console.WriteLine("El resultado es {0}", resultado);
            Console.ReadKey();
        }
        // Metodo que forza el boxing
        public static void Muestra(object o)
        {
            Console.WriteLine("Lo que recibi es {0}");
        }
        // Metodo que forza el boxing
        public static void Multiplica(object o)
        {
            // Para hacer la operacion debemos de llevar a cabo unboxing
            // Esto causa error
            //Console.WriteLine("Lo que recibi es {0}", o * 2);
            int temp = (int)o;
            Console.WriteLine("Lo que recibi es {0}", temp * 2);
        }
    }
}
