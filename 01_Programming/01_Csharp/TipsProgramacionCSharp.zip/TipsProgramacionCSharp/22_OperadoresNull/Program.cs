﻿using System;

namespace _22_OperadoresNull
{
    class Program
    {
        static void Main(string[] args)
        {
            // Operadores null
            // Operador coalescente (incorporacion)
            // Funciona con nuestras clases y tipos nulleables
            // Si el operando no es null, se asigna
            // si no se da el valor de default
            // r = op ?? default

            string a = null;
            string b = "hola";
            string r;

            r = a ?? "fue null";
            Console.WriteLine(r);

            r = b ?? "fue null";
            Console.WriteLine(r);

            Console.WriteLine("--------------");

            // Operador null condicional
            // Tambien se le llama Elvis ?.
            // Permite invocar metodos y acceder como lo hace el operador .
            // La ventaja que nos da es que si el operando es null, la expresion evalua a null
            // y no lanza un NullReferenceException

            // Este codigo genera excepcion
            //string rs = a.ToString();

            // Este no genera excepcion
            string rs = a?.ToString();
            Console.WriteLine(rs);

            // Para que funcione, la expresion debe de aceptar null

            //int cantidadN = a?.ToString().Length;
            int? cantidad = a?.ToString().Length;
            Console.WriteLine(cantidad);

            Console.ReadKey();
        }
    }
}
