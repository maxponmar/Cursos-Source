﻿using System;

namespace _01_UsoAvanzadoSwitch
{
    class Program
    {
        static void Main(string[] args)
        {
            // Este programa muestra como podemos usar switch con otros tipos
            // a parte de int
            // Variables que usaremos en el switch
            bool booleana = true;
            char caracter = 'a';
            string cadena = "Priviet";
            // Con bool
            switch (booleana)
            {
                case true:
                    Console.WriteLine("La variable tiene true");
                    break;
                case false:
                    Console.WriteLine("La variable tiene false");
                    break;                
            }
            // Con caracter
            switch (caracter)
            {
                // Case para varios casos al mismo tiempo
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                    Console.WriteLine("Es vocal");
                    break;
                default:
                    Console.WriteLine("Es consonante");
                    break;
            }
            // Con cadena
            switch (cadena)
            {
                case "Hola":
                    Console.WriteLine("Español");
                    break;
                case "Hello":
                    Console.WriteLine("Inglés");
                    break;
                case "Priviet":
                    Console.WriteLine("Ruso");
                    break;
            }
            Console.ReadKey();
        }
    }
}
