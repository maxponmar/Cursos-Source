﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07_Static
{
    class MiClase
    {
        private int valor = 50;
        private static int numero = 10;

        public void saluda()
        {
            Console.WriteLine("Solo saludo si hay instancia de la clase");
        }
        public static void mensaje()
        {
            Console.WriteLine("Puedo dar el mensaje aun sin instancia");
        }
        // El metodo estatico no puede usar un dato normal
        public static void imprimeValor()
        {
            //Console.WriteLine("El valor es {0}", valor);
        }
        public static void imprimeNumero()
        {
            Console.WriteLine("El numero es {0}", numero);
        }
    }
    class MiClase2
    {
        private int valor = 50;
        private static int numero = 10;
        public void ponValor(int pValor)
        {
            valor = pValor;
        }
        public void ponNumero(int pNumero)
        {
            numero = pNumero;
        }
        public void muestraDatos()
        {
            Console.WriteLine("Valor = {0}, numero = {1}", valor, numero);
        }
    }
    class MiClase3
    {
        public int valor;
        private static int numero;
        public MiClase3()
        {
            valor = 20;
            numero = 33;
            Console.WriteLine("Saludos desde el constructor");
        }
        public void ponValor(int pValor)
        {
            valor = pValor;
        }
        public void ponNumero(int pNumero)
        {
            numero = pNumero;
        }
        public void muestraDatos()
        {
            Console.WriteLine("Valor = {0}, numero = {1}", valor, numero);
        }
    }
    class MiClase4
    {
        public int valor = 20;
        private static int numero;
        // El constructor solo se ejecuta 1 sola vez durante la ejecucion del programa sin importar cuantas instancias se creen
        static MiClase4()
        {            
            numero = 33;
            Console.WriteLine("Saludos desde el constructor");
        }
        public void ponValor(int pValor)
        {
            valor = pValor;
        }
        public void ponNumero(int pNumero)
        {
            numero = pNumero;
        }
        public void muestraDatos()
        {
            Console.WriteLine("Valor = {0}, numero = {1}", valor, numero);
        }
    }
    static class MiClaseS
    {
        public static int valor = 20;
        private static int numero;
        // El constructor solo se ejecuta 1 sola vez durante la ejecucion del programa sin importar cuantas instancias se creen
        static MiClaseS()
        {
            numero = 33;
            Console.WriteLine("Saludos desde el constructor");
        }
        public static void ponValor(int pValor)
        {
            valor = pValor;
        }
        public static void ponNumero(int pNumero)
        {
            numero = pNumero;
        }
        public static void muestraDatos()
        {
            Console.WriteLine("Valor = {0}, numero = {1}", valor, numero);
        }
    }
}
