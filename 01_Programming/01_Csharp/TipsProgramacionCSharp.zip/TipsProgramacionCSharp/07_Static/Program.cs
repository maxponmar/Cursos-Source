﻿using System;

namespace _07_Static
{
    class Program
    {
        static void Main(string[] args)
        {
            // No puedo invocar un metodo sin instancia, marca error
            //MiClase.saluda();
            //De esta forma si funciona
            MiClase miObjeto = new MiClase();
            miObjeto.saluda();

            // Un metodo estatico si puede ser invocado sin instancia
            MiClase.mensaje();
            //MiClase.imprimeValor();
            MiClase.imprimeNumero();
            Console.ReadKey();

            // Creamos tres instancias
            MiClase2 obj1 = new MiClase2();
            MiClase2 obj2 = new MiClase2();
            MiClase2 obj3 = new MiClase2();

            Console.WriteLine("Imprimimos antes de cambios");
            obj1.muestraDatos();
            obj2.muestraDatos();
            obj3.muestraDatos();
            // Cambiamos datos e imprimimos
            obj1.ponValor(3);
            obj2.ponValor(57);
            obj3.ponValor(140);
            Console.WriteLine("Imprimimos con cambios a valor");
            obj1.muestraDatos();
            obj2.muestraDatos();
            obj3.muestraDatos();
            // Cambiamos el numero solo en un objeto
            obj2.ponNumero(300);
            Console.WriteLine("Imprimimos con cambio a numero (1 objeto)");
            obj1.muestraDatos();
            obj2.muestraDatos();
            obj3.muestraDatos();
            Console.ReadKey();

            // Creamos dos objetos
            Console.ReadKey();
            MiClase3 o1 = new MiClase3();
            MiClase3 o2 = new MiClase3();
            Console.WriteLine("Sin cambio");
            o1.muestraDatos();
            o2.muestraDatos();
            // Cambiamos
            o1.ponValor(400);
            o2.ponValor(555);
            Console.WriteLine("Con cambios");
            o1.muestraDatos();
            o2.muestraDatos();
            // Creamos otra instancia
            // Resetea el dato estatico
            MiClase3 o3 = new MiClase3();
            Console.WriteLine("Despues de la instanciia");
            o1.muestraDatos();
            o2.muestraDatos();
            o3.muestraDatos();
            Console.ReadKey();

            // Creamos objetos
            MiClase4 objeto1 = new MiClase4();
            MiClase4 objeto2 = new MiClase4();
            Console.WriteLine("Sin cambio");
            objeto1.muestraDatos();
            objeto2.muestraDatos();
            // Cambiamos
            objeto1.ponValor(400);
            objeto2.ponValor(400);
            Console.WriteLine("Con cambios");
            objeto1.muestraDatos();
            objeto2.muestraDatos();
            // Creamos instancia
            MiClase4 objeto4 = new MiClase4();
            Console.WriteLine("Despues de la instancia");
            objeto1.muestraDatos();
            objeto2.muestraDatos();
            objeto4.muestraDatos();
            Console.ReadKey();

            // No se puede instancias una clase static
            //MiClaseS objetoS = new MiClaseS();
            Console.WriteLine("Sin cambio");
            MiClaseS.muestraDatos();
            // Cambiamos
            MiClaseS.ponValor(400);
            MiClaseS.ponNumero(555);
            Console.WriteLine("Con cambios");
            MiClaseS.muestraDatos();
            Console.ReadKey();
        }
    }
}
