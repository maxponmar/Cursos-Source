﻿using System;

namespace _27_EnumeracionesFlags
{
    class Program
    {
        [Flags]
        //public enum Condimentos
        //{
        //    nada = 0, Tomate = 1, Lechuga = 2, Cebolla = 4, Queso = 8
        //}
        public enum Condimentos
        {
            nada = 0, Tomate = 1, Lechuga = 2, Cebolla = 4, Queso = 8,
            Basica = Tomate | Lechuga,
            Completa = Tomate | Lechuga | Cebolla| Queso
        }
        
        static void Main(string[] args)
        {
            // Colocamos un condimento
            Condimentos misCondimentos = Condimentos.Queso;
            DibujaHamburguesa(misCondimentos);

            // Adicionamos otro condimento
            misCondimentos = misCondimentos | Condimentos.Tomate;
            DibujaHamburguesa(misCondimentos);
            // Adicionamos otros
            misCondimentos = misCondimentos | Condimentos.Lechuga | Condimentos.Cebolla;
            DibujaHamburguesa(misCondimentos);

            // Quitamos un condimento
            misCondimentos -= Condimentos.Cebolla;
            DibujaHamburguesa(misCondimentos);

            // Limpiamos
            misCondimentos = Condimentos.nada;
            DibujaHamburguesa(misCondimentos);

            // Una basica
            misCondimentos = Condimentos.Basica;
            DibujaHamburguesa(misCondimentos);

            // Una completa
            misCondimentos = Condimentos.Completa;
            DibujaHamburguesa(misCondimentos);

            Console.ReadKey();
        }
        public static void DibujaHamburguesa(Condimentos pCond)
        {
            // Dibujamos tapa
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine(" (====) ");
            // Verificamos si se tiene tomate
            if ((pCond & Condimentos.Tomate) != 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" ==== ");
            }
            // Verificamos si tiene lechuga
            if ((pCond & Condimentos.Lechuga) != 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(" ^^^^ ");
            }
            // Verificamos si tiene cebolla
            if ((pCond & Condimentos.Cebolla) != 0)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(" #### ");
            }
            // Verificamos si tiene queso
            if ((pCond & Condimentos.Queso) != 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(" ---- ");
            }
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(" ==== ");
            // Dibujamos base
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine(" (====) ");

            Console.WriteLine("\r\n----------------------\r\n");
        }
    }
}
