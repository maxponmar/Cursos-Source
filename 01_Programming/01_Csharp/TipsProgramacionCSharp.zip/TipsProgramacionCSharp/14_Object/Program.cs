﻿using System;

namespace _14_Object
{
    class Program
    {
        static void Main(string[] args)
        {
            CPersona juan = new CPersona("Juan", 27);
            // Vemos el comportamiento ToString
            Console.WriteLine("--- ToString ---");
            Console.WriteLine(juan.ToString());
            // Vemos el comportamiento
            Console.WriteLine("--- GetType ---");
            Console.WriteLine(juan.GetType());
            Console.WriteLine(juan.GetType().BaseType);

            CPersona maria = new CPersona("Maria", 20);
            // Vemos el comportamiento de equals
            Console.WriteLine("--- Equals ---");
            if(juan.Equals(maria))
                Console.WriteLine("Son iguales");
            else
                Console.WriteLine("Son diferentes");

            CPersona juan2 = new CPersona("Juan", 27);
            if (juan.Equals(juan2))
                Console.WriteLine("Son iguales");
            else
                Console.WriteLine("Son diferentes");

            if (object.Equals(juan, juan2))
                Console.WriteLine("Son iguales");
            else
                Console.WriteLine("Son diferentes");

            object maria2 = maria;
            if (maria.Equals(maria2))
                Console.WriteLine("Son iguales");
            else
                Console.WriteLine("Son diferentes");

            // Vemos como trabaja ReferenceEquals
            if(object.ReferenceEquals(maria,maria2))
                Console.WriteLine("Son iguales");
            else
                Console.WriteLine("Son diferentes");
            if (object.ReferenceEquals(juan, juan2))
                Console.WriteLine("Son iguales");
            else
                Console.WriteLine("Son diferentes");
            // Vemos el comportamiento de GetHashCode
            Console.WriteLine("--- GetHashCode ---");
            Console.WriteLine(juan.GetHashCode());
            Console.ReadKey();
        }
    }
}
