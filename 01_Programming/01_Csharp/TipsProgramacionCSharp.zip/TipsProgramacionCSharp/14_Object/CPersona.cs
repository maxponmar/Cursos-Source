﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _14_Object
{
    class CPersona
    {
        private string nombre;
        private int edad;
        public CPersona(string pNombre, int pEdad)
        {
            nombre = pNombre;
            edad = pEdad;
        }
        public override string ToString()
        {
            return string.Format("Nombre: {0}, Edad: {1}", nombre, edad);
        }
        public override bool Equals(object obj)
        {
            if (obj != null && obj is CPersona) 
            {
                CPersona temp = (CPersona)obj;
                if (nombre == temp.nombre && edad == temp.edad)
                    return true;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return nombre.GetHashCode() + edad.GetHashCode();
        }
    }
}
