﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _24_InicializadoresObjetos
{
    class CPrueba
    {
        public int a, b;
        public string c;

        public CPrueba()
        {

        }
        public CPrueba(string pC)
        {
            c = pC;
        }
        public override string ToString()
        {
            return string.Format("{0}, {1}, {2}", a, b, c);
        }
    }
}
