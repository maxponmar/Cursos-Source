﻿using System;

namespace _24_InicializadoresObjetos
{
    class Program
    {
        static void Main(string[] args)
        {
            // Inicializadores de objeto
            // Permite colocar valores facilmente durante la construccion
            // Solo se usa con variables publicas
            // Pone en riesgo la encapsilamiento

            // Inicializamos
            CPrueba p1 = new CPrueba { a = 1, b = 2, c = "Hola a todos" };
            Console.WriteLine(p1);

            CPrueba p2 = new CPrueba("Saludos") { a = 5, b = 10 };
            Console.WriteLine(p2);

            Console.ReadKey();
        }
    }
}
