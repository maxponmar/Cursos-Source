﻿using System;

namespace _03_OptimizarIFconKmaps
{
    class Program
    {
        static void Main(string[] args)
        {
            // Optimizando if con K-maps
            // Programa que indica si una persona puede comprar un auto en las siguientes reglas
            // Es mayor de edad, tiene el dinero y tiene fiador
            // No es mayor de edad, tiene el dinero y no tiene fiador
            // Es mayor de edad, no tiene dinero pero tiene fiador
            // No es mayor de edad, tiene el dinero y no tiene fiador

            // Variables
            int edad = 20;
            int dinero = 50000;
            bool fiador = false;

            // Colocamos el if de forma tradicional
            Console.WriteLine("--- If tradicional ---");
            if ((edad >= 18 && dinero >= 35000 && fiador == true) ||
                (edad < 18 && dinero >= 35000 && fiador == true) ||
                (edad >= 18 && dinero < 35000 && fiador == true) ||
                (edad < 18 && dinero >= 35000 && fiador == false))
            {
                Console.WriteLine("Lo puede comprar");
            }
            else
            {
                Console.WriteLine("No lo puede comprar");
            }
            // Colocamos if optimizado
            Console.WriteLine("--- If optimizado ---");
            if ((edad < 18 && dinero >= 35000) || (edad >= 18 && fiador == true))
            {
                Console.WriteLine("Lo puede comprar");
            }
            else
            {
                Console.WriteLine("No lo puede comprar");
            }
            Console.ReadKey();
        }
    }
}
