﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _31_RestriccionesClasesGenericas
{
    class CA
    {
        // Colocar los atributos y metodos de la clase

        //public CA(int a, int b)
        //{

        //}
        public override string ToString()
        {
            return string.Format("Desde clase A CA");
        }
    }

    class CB : CA
    {
        // Colocar los atributos y metodos de la clase
        public override string ToString()
        {
            string r = base.ToString();
            return string.Format("Desde clase B CB-> ", r);
        }
    }
    interface IInterfaz
    {
        void metodo();
    }
    class CC : IInterfaz
    {
        public void metodo()
        {
            Console.WriteLine("Implementacion de la interfaz");
        }
        public override string ToString()
        {
            return string.Format("Desde clase C CC");
        }
    }
}
