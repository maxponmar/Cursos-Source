﻿using System;

namespace _31_RestriccionesClasesGenericas
{
    class Program
    {
        static void Main(string[] args)
        {
            // Restricciones genericas

            CA objetoA = new CA();
            CB objetoB = new CB();
            CC objetoC = new CC();

            CGenerica<CB> oGen = new CGenerica<CB>(objetoB);
            oGen.Repetir();

            Console.ReadKey();
        }
    }
}
