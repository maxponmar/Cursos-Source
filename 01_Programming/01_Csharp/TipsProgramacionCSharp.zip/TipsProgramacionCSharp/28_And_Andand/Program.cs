﻿using System;
using System.Diagnostics;
namespace _28_And_Andand
{
    class Program
    {
        static void Main(string[] args)
        {
            // Diferencia entre & y &&
            Stopwatch sw = new Stopwatch();

            int a = 0x08;//8
            int b = 0x18;//24
            // & es usada para hacer AND bit pot bit, es una operacion aritmetica booleana
            // 00001000 - 8
            // 00011000 - 24
            // 00001000 - 8 0x08
            int r = a & b;
            Console.WriteLine("0x{0}r", r);

            // Esto no se puede hacer, por que && es un operador logico
            //r = a && b;

            // & Tambien trabaja con bool y lo toma como de dimension 1 bit
            bool x = true;
            bool y = false;
            bool t = x & y;
            Console.WriteLine(t);

            // Recordar que las expresiones relacionales y logicas evaluan a true o false
            // debido a eso surge la confusion ya que a & b y a && b son operacionalmente equivalentes para
            // sin embargo && es short wired
            // el if() necesita solo un valor bool para saber si se ejecuo o no el codigo

            int m = 5, n = 3;
            sw.Start();
            for (int l = 0; l < 1000000; l++)
            {
                if ((m > 30) && (n < 10))
                    Console.WriteLine(":)");
            }
            sw.Stop();
            Console.WriteLine(sw.ElapsedTicks);

            sw.Start();
            for (int l = 0; l < 1000000; l++)
            {
                if ((m > 30) & (n < 10))
                    Console.WriteLine(":)");
            }
            sw.Stop();
            Console.WriteLine(sw.ElapsedTicks);

            Console.ReadKey();
        }
    }
}
