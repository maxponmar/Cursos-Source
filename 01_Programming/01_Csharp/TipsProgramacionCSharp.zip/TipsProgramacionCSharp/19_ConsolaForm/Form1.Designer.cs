﻿namespace _19_ConsolaForm
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDato = new System.Windows.Forms.TextBox();
            this.btnConsola = new System.Windows.Forms.Button();
            this.btnPide = new System.Windows.Forms.Button();
            this.lblMensaje = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtDato
            // 
            this.txtDato.Location = new System.Drawing.Point(12, 12);
            this.txtDato.Name = "txtDato";
            this.txtDato.Size = new System.Drawing.Size(144, 20);
            this.txtDato.TabIndex = 0;
            // 
            // btnConsola
            // 
            this.btnConsola.Location = new System.Drawing.Point(162, 12);
            this.btnConsola.Name = "btnConsola";
            this.btnConsola.Size = new System.Drawing.Size(75, 23);
            this.btnConsola.TabIndex = 1;
            this.btnConsola.Text = "A Consola";
            this.btnConsola.UseVisualStyleBackColor = true;
            this.btnConsola.Click += new System.EventHandler(this.btnConsola_Click);
            // 
            // btnPide
            // 
            this.btnPide.Location = new System.Drawing.Point(162, 41);
            this.btnPide.Name = "btnPide";
            this.btnPide.Size = new System.Drawing.Size(75, 23);
            this.btnPide.TabIndex = 2;
            this.btnPide.Text = "Pide";
            this.btnPide.UseVisualStyleBackColor = true;
            this.btnPide.Click += new System.EventHandler(this.btnPide_Click);
            // 
            // lblMensaje
            // 
            this.lblMensaje.AutoSize = true;
            this.lblMensaje.Location = new System.Drawing.Point(9, 78);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(35, 13);
            this.lblMensaje.TabIndex = 3;
            this.lblMensaje.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(249, 117);
            this.Controls.Add(this.lblMensaje);
            this.Controls.Add(this.btnPide);
            this.Controls.Add(this.btnConsola);
            this.Controls.Add(this.txtDato);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDato;
        private System.Windows.Forms.Button btnConsola;
        private System.Windows.Forms.Button btnPide;
        private System.Windows.Forms.Label lblMensaje;
    }
}

