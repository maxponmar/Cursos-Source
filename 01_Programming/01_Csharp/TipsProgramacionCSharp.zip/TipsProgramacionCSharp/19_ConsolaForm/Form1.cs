﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _19_ConsolaForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConsola_Click(object sender, EventArgs e)
        {
            // Imprimimos en la consola
            Console.WriteLine("Desde la forma a la consola");
            Console.WriteLine("El textbox tiene: {0}",txtDato.Text);
        }

        private void btnPide_Click(object sender, EventArgs e)
        {
            this.Hide();
            Console.WriteLine("Escribe un mensaje");
            string msg = Console.ReadLine();
            lblMensaje.Text = msg;
            this.Show();
        }
    }
}
