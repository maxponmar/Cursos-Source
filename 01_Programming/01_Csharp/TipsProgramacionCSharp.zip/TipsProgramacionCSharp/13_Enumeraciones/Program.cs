﻿using System;

namespace _13_Enumeraciones
{
    class Program
    {
        public enum tipoImagen { BMP, JPG, PNG, GIF, TIFF};
        //public enum tipoImagen { BMP=10, JPG, PNG, GIF, TIFF };
        static void Main(string[] args)
        {
            string dato = "";
            double tamanoImg = 0;
            Console.WriteLine("Dame el tamano de la imagen");
            dato = Console.ReadLine();
            tamanoImg = Convert.ToDouble(dato);
            calcularEspacio(tipoImagen.PNG, tamanoImg);
            Console.ReadKey();
        }
        public static void calcularEspacio(tipoImagen pImagen, double tamano)
        {
            double espacio = 0;

            switch (pImagen)
            {
                case tipoImagen.BMP:
                    espacio = tamano * 1.1;
                    break;
                case tipoImagen.JPG:
                    espacio = tamano * 0.8;
                    break;
                case tipoImagen.PNG:
                    espacio = tamano * 0.77;
                    break;
                case tipoImagen.GIF:
                    espacio = tamano * 1.5;
                    break;
                case tipoImagen.TIFF:
                    espacio = tamano * 0.97;
                    break;               
            }
            Console.WriteLine("El tamano final es {0}", espacio);
        }
    }
}
