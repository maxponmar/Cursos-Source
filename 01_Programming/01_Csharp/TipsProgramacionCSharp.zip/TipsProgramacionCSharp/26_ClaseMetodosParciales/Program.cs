﻿using System;

namespace _26_ClaseMetodosParciales
{
    class Program
    {
        static void Main(string[] args)
        {
            // Tipos y metodos parciales
            CEjemplo prueba = new CEjemplo();
            prueba.Costo = 500;
            Console.WriteLine(prueba);
            Console.ReadKey();
        }
    }
}
