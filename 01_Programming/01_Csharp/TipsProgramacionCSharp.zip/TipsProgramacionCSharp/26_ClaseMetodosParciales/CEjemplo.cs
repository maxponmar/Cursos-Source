﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _26_ClaseMetodosParciales
{
    // Creamos una clase parcial
    // En este documento creamos una parte
    partial class CEjemplo
    {
        private double costo;
        private double impuesto;
        private double total;
        // Propiedades
        public double Costo { get => costo; set => costo = value; }
        public double Impuesto { get => impuesto; set => impuesto = value; }
        public double Total { get => total; set => total = value; }
        // Definimos un metodo parcial 
        // Va a trabajar como si fuera un metodo privado
        // no se le puede colocar acceso ni modificadores
        partial void calculaImpuesto(double pImpuesto);

    }
}
