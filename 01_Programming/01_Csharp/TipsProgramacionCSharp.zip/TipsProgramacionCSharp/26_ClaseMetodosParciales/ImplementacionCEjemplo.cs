﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _26_ClaseMetodosParciales
{
    // Creamos una clase parcial
    // En este documento creamos una parte
    partial class CEjemplo
    {
        public override string ToString()
        {
            // Invocamos el metodo parcial
            calculaImpuesto(0.16);
            return string.Format("El costo es {0}, el impuesto {1} y el total {2}", costo, impuesto, total);
        }
        // Implementamos el metodo parcial
        partial void calculaImpuesto(double pImpuesto)
        {
            impuesto = costo * pImpuesto;
            total = costo + impuesto;
        }
    }
}