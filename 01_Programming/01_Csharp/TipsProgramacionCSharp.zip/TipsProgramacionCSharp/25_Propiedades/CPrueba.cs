﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _25_Propiedades
{
    class CPrueba
    {
        private double precioVenta;
        private double precioCompra;
        private double descuento;
        private int garantia;

        // Propiedad calculada
        public double PrecioVenta
        {
            get { return precioCompra * 1.30; }
        }
        public CPrueba(double pPrecioCompra)
        {
            precioCompra = pPrecioCompra;
        }
        // Expression-bodied porperties
        // Propiedades de expresion representadoa
        public double Impuesto => PrecioVenta * 0.16;
        // Version C#7, permite el set
        public double Descuento
        {
            get => precioCompra * (1 - descuento);
            set => descuento = value / 100;
        }
        // Inicializador de propiedades
        public int Inventario { get; set; } = 30;

        // Accesibilidadd 
        public int Garantia
        {
            get { return garantia; }
            private set { garantia = value; }
        }
        public void ponerGarantia(int pPassword, int pGarantia)
        {
            if (pPassword == 12345)
                Garantia = pGarantia;
        }
    }
}
