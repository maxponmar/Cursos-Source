﻿using System;

namespace _04_ConfiguracionConsola
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Texto normal");
            impresiones(5);

            Console.WriteLine("Color de la fuente");
            Console.ForegroundColor = ConsoleColor.Green;
            impresiones(5);

            //Limpiar consola
            Console.Clear();

            Console.WriteLine("Color del fondo");
            Console.BackgroundColor = ConsoleColor.DarkGray;
            impresiones(5);

            Console.Clear();

            Console.WriteLine("Colocamos cuantas columnas");
            Console.BufferWidth = 200;
            impresiones(5);

            Console.WriteLine("Colocamos cuantos renglones");
            Console.BufferHeight = 200;
            impresiones(5);

            Console.Clear();

            Console.WriteLine("Colocamos el ancho de la ventana");
            Console.WindowWidth = 100;
            impresiones(15);

            Console.WriteLine("Colocamos el largo de la ventana");
            Console.WindowWidth = 40;
            impresiones(15);

            Console.Clear();

            Console.WriteLine("Colocamos la ventana en una posicion");
            Console.WindowWidth = 80;
            Console.WindowWidth = 20;
            impresiones(5);
            Console.WindowLeft = 5;
            Console.WindowTop = 2;
        }
        public static void impresiones(int n)
        {
            int x = 0, y = 0;
            for (x = 0; x < n; x++)
            {
                for (y = 0; y < 100; y++)                
                    Console.Write(y % 10);
                Console.WriteLine();
            }
        }
    }
}
