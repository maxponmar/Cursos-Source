﻿using System;

namespace _02_ArgumentosLineaComando
{
    class Program
    {
        static void Main(string[] args)
        {
            // Este programa hace uso de los argumento de linea de comando
            // Obtiene un nombre por linea de comando y lo hace la cantidad de veces indicada
            // Variables 
            string nombre = "";
            int repeticiones = 0;
            int n = 0;
            // Verificamos que se tenga la cantidad de argumentos
            if (args.Length != 2)
            {
                Console.WriteLine("Debe de poner el nombre y las repeticiones");
            }
            else
            {
                // Obtenemos los argumentos
                nombre = args[0];
                repeticiones = Convert.ToInt32(args[1]);
                // Hacemos el saludo
                for (n = 0; n < repeticiones; n++)
                {
                    Console.WriteLine("Hola {0}!",nombre);
                }
            }
            Console.ReadLine();
        }
    }
}
