﻿
using System;

namespace _34__Snippets
{
    class Program
    {
        static void Main(string[] args)
        {
           // Snippets
           // Usar la clave + doble tab

           // ~ (Alt+126) : Destructor
           // class : Crear nueva clase
           // ctor : Constructor
           // cw : WriteLine
           // do : do While
           // for : ciclo for
           // forr : ciclo for regresivo
           // foerach : iterador foreach
           // if : condicional if
           // else : complemento de if
           // switch : crea switch con caso default
           // while : crea bucle while
           // prop : crear una propiedad automatica
           // exception : crea la base para una nueva excepcion
           // interface : crea la base para una interfaz
           // mbox : lo necesario para crear un MessageBox
        }
    }
}
