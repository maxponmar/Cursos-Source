﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _30_ImplementacionVirtualdeInterfaces
{
    class COtra : CPrueba
    {
        public COtra(double pNumero) : base(pNumero)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("En el constructor de COtra");
            calcular(pNumero);
            Console.WriteLine("Saliendo del constructor de COtra");
        }
    }
}
