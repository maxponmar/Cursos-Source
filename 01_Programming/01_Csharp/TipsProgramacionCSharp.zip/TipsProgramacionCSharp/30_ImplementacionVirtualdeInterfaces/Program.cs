﻿using System;

namespace _30_ImplementacionVirtualdeInterfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            // Implementacion virtual de interfaces
            Console.WriteLine("<<< Implementacion virtual >>>");
            CPrueba o1 = new CPrueba(45);
            o1.calcular(12.5);
            Console.WriteLine("-------");

            COtra o2 = new COtra(10);
            Console.WriteLine("-------");

            CTest o3 = new CTest(45);
            o3.calcular(12.5);
            Console.WriteLine("-------");

            // Notar que aqui no tenemos la version polimorfica
            ((CPrueba)o2).calcular(12.5);

            Console.ReadKey();
        }
    }
}
