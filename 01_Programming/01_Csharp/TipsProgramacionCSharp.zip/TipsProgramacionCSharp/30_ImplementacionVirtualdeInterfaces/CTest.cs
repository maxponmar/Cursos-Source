﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _30_ImplementacionVirtualdeInterfaces
{
    // Notar que a diferencia del tip anterior
    // Aqui no indicamos que se implementa interfaz
    class CTest : CPrueba
    {
        double miNumero;
        public CTest(double pNumero) : base(pNumero)
        {
            miNumero = pNumero;
        }
        // Aqui hacemos el override de la implementacion
        public override void calcular(double pValor)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Version de Test {0}", miNumero + pValor);
        }
    }
}
