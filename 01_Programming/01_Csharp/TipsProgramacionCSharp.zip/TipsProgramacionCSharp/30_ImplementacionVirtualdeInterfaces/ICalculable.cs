﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _30_ImplementacionVirtualdeInterfaces
{
    interface ICalculable
    {
        void calcular(double pNumero);
    }
}
