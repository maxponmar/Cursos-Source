﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _30_ImplementacionVirtualdeInterfaces
{
    class CPrueba : ICalculable
    {
        private double n;
        public CPrueba(double pValor)
        {
            n = pValor; 
        }
        // Implementacion de ICalculable
        // Hay que notar que la estamos marcando como virtual
        // Por default las implementaciones son con sealed
        public virtual void calcular(double pNumero)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Estoy en CPrueba {0}", n * pNumero);
        }
    }
}
