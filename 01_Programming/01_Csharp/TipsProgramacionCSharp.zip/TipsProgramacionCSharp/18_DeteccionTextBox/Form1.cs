﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _18_DeteccionTextBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDetecta_Click(object sender, EventArgs e)
        {
            int ri = 0;
            double rd = 0;
            if (txbDato.Text == string.Empty)
                MessageBox.Show("No hay dato");
            else if (int.TryParse(txbDato.Text, out ri))
                MessageBox.Show("Es un numero entero");
            else if (double.TryParse(txbDato.Text, out rd))
                MessageBox.Show("Es un numero flotante");
            else
                MessageBox.Show("Es una cadena");
        }
    }
}
