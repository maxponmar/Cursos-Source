﻿using System;

namespace _05_FormatoWriteWriteLine
{
    class Program
    {
        static void Main(string[] args)
        {
            // Programa que muestra como formato en write o writline
            double miDobule = 123456.7890123;
            int miInt = 637;

            Console.WriteLine("Impresiones normales");
            Console.WriteLine("El entero {0}", miInt);
            Console.WriteLine("El double {0}",miDobule);
            Console.WriteLine("-----");
            Console.WriteLine("Impresiones con formato");
            Console.WriteLine("Moneda {0:C}",miDobule);
            Console.WriteLine("Rellena lugares {0:D5}",miInt);
            Console.WriteLine("Exponente {0:E}",miDobule);
            Console.WriteLine("Lugares decimales {0:F3}",miDobule);
            Console.WriteLine("Exponente con lugares {0:G3}",miDobule);
            Console.WriteLine("Exponente con lugares {0:G5}",miDobule);
            Console.WriteLine("Formato numerico {0:N}",miDobule);
            Console.WriteLine("En HexaDecimal {0:X4}", miInt);
            Console.ReadKey();
        }
    }
}
