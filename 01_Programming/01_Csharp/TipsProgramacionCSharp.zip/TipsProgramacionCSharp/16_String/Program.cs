﻿using System;

namespace _16_String
{
    class Program
    {
        static void Main(string[] args)
        {
            string mensaje = "Hola, saludos a todos!!!!!!!!!!!!!!!";

            // Verificamos si hay subcadena
            bool tiene = mensaje.Contains("saludos");
            Console.WriteLine(tiene);
            Console.WriteLine("---------------------------------------");

            // Verificamos si termina en una subcadena en particular
            bool termina = mensaje.EndsWith("!");
            Console.WriteLine(termina);
            Console.WriteLine("---------------------------------------");

            // Creamos cadena por medio de formato
            int edad = 20;
            string mensaje2 = string.Format("La persona tiene {0} años", edad);
            Console.WriteLine(mensaje2);
            Console.WriteLine("---------------------------------------");

            // Encontramos el lugar donde aparece determinado caracter por primera vez
            int indice = 0;
            indice = mensaje.IndexOf("s");
            Console.WriteLine("La s aparece en el indice {0}", indice);

            // Encontramos el lugar donde aparece una cadena
            indice = mensaje2.IndexOf("tiene");
            Console.WriteLine("La palabra aparece en el indice {0}", indice);

            // Encontramos el lugar donde aparece por ultima vez determinado caracer
            indice = mensaje.LastIndexOf('a');
            Console.WriteLine("La a aparece por ultimo en el indice {0}", indice);
            Console.WriteLine("---------------------------------------");

            // indicamos una longitud y se llena con espacios
            string mensaje3 = "Programando";
            string pad = mensaje3.PadLeft(15);
            Console.WriteLine(pad);
            Console.WriteLine("---------------------------------------");

            // Removemos caracteres
            string remover = mensaje.Remove(7);
            Console.WriteLine(remover);
            Console.WriteLine("---------------------------------------");

            // Reemplazamos caracteres
            string reemplazo = mensaje.Replace('a', 'o');
            Console.WriteLine(reemplazo);

            reemplazo = mensaje.Replace("saludos", "regalos");
            Console.WriteLine(reemplazo);
            Console.WriteLine("---------------------------------------");

            // Dividimos la cadena usando espacios
            string[] palabras = mensaje.Split(new char[] { ' ' });
            foreach (string s in palabras)
            {
                Console.WriteLine(s);
            }
            Console.WriteLine("---------------------------------------");

            // Verificamos si la cadena empieza con una cadena en particular
            bool empieza = mensaje.StartsWith("hola");
            Console.WriteLine(empieza);
            Console.WriteLine("---------------------------------------");

            // Obtenemos una subcadena desde un indice hasta otro
            string subcadena = mensaje.Substring(7, 12);
            Console.WriteLine(subcadena);
            Console.WriteLine("---------------------------------------");

            // Mandamos a minusculas
            string mensaje4 = "ESTE mensaje Tiene Mayusculas";
            string minusculas = mensaje4.ToLower();
            Console.WriteLine(minusculas);

            // Mandamos a mayusculas
            string mayusculas = minusculas.ToUpper();
            Console.WriteLine(mayusculas);
            Console.WriteLine("---------------------------------------");

            // Eliminamos exceso de caracteres TrimEnd, TrimStart
            string limpio = mensaje.Trim(new char[] { '!' });
            Console.WriteLine(limpio);

            Console.ReadKey();
        }
    }
}
