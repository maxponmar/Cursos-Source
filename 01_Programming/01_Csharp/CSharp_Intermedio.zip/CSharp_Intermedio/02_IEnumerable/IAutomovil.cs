﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02_IEnumerable
{
    interface IAutomovil
    {
        // Calcular el impuesto
        void CalculaTenencia(double imp);
        // Mostrar informacion
        void MuestraInformacion();
    }
}
