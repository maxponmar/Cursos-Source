﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02_IEnumerable
{
    class CAuto
    {
        double costo, tenencia;
        string modelo;
        // Constructor
        public CAuto(string pModelo, double pCosto)
        {
            // Inicializamos los datos
            costo = pCosto;
            modelo = pModelo;
        }
        // Metodos interfaz
        public void CalculaTenencia(double pImpuesto)
        {
            // Calculamos el impuesto
            tenencia = 5000 + costo * pImpuesto;
        }
        public void MuestraInformacion()
        {
            // Mostramos la informacion
            Console.WriteLine("Tu automovil {0}", modelo);
            Console.WriteLine("Costo {0}, con una tenencia de {1}", costo, tenencia);
            Console.WriteLine("---------");
        }
    }
}
