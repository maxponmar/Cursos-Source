﻿using System;

namespace _02_IEnumerable
{
    //public interface IEnumerable
    //{
    //    IEnumerator GetEnumerator();
    //}
    //public interface IEnumerator
    //{
    //    bool MoveNext();
    //    object Curret { get; }
    //    void Reset();
    //}
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos la tienda
            CTiendaAutos tienda = new CTiendaAutos();

            // Recorremos cada uno de los elementos de la 
            // estructura que expone
            foreach (CAuto miAuto in tienda)
            {
                miAuto.CalculaTenencia(0.05);
                miAuto.MuestraInformacion();
            }
            Console.ReadKey();
        }
    }
}
