﻿using System;

namespace _03_IEnumerable
{
    class Program
    {
        static void Main(string[] args)
        {
            CContenedora datos = new CContenedora();
            foreach (int valor in datos)
            {
                Console.WriteLine(valor);
            }
            Console.ReadKey();
        }
    }
}
