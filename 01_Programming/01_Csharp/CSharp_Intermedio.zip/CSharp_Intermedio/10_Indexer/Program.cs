﻿using System;

namespace _10_Indexer
{
    class CAuto
    {
        double costo, tenencia;
        string modelo;
        public CAuto(string pModelo, double pCosto)
        {
            costo = pCosto;
            modelo = pModelo;
        }
        public void MuestraInformacion()
        {
            Console.WriteLine("Tu automovil {0}", modelo);
            Console.WriteLine("Costo {0}", costo);
            Console.WriteLine("-------------------");
        }
    }
    class CTienda
    {
        private CAuto[] disponibles;
        public CTienda()
        {
            disponibles = new CAuto[4];
            disponibles[0] = new CAuto("Soul", 220000.5);
            disponibles[1] = new CAuto("Fit", 175600.7);
            disponibles[2] = new CAuto("March", 168900);
            disponibles[3] = new CAuto("Spark", 160400.4);
        }
        // Indexer
        public CAuto this[int indice]
        {
            // Usamos un get para obtener el elemento de ese indice
            get { return disponibles[indice]; }
            // Usamos un set para colocar un elemento en ese indice
            set { disponibles[indice] = value; }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            CTienda miTienda = new CTienda();
            // Obtenemos un auto
            CAuto miAuto= miTienda[1];
            miAuto.MuestraInformacion();
            // Colocamos un auto
            CAuto otroAuto = new CAuto("Vocho", 85000);
            miTienda[1] = otroAuto;
            // Imprimimos la tienda
            for (n = 0; n < 4; n++)
                miTienda[n].MuestraInformacion();            
            Console.ReadKey();
        }
    }
}
