﻿using System;

namespace _18_NombradosOpcionales
{
    class Program
    {
        static void Main(string[] args)
        {
            // Invocamos la funcion de forma normal
            // tres posicionales
            MostrarDatos(3, 5, 7);

            // Invocamos la funcion con primero en normal, los demas en otro orden,
            // un posicional, dos nombrados
            MostrarDatos(3, pC: 11, pB: 15);

            // Invocamos con los datos en otro orden
            // tres nombrados
            MostrarDatos(pB: 10, pC: 15, pA: 4);

            // Un posicional no puede venir despues de un nombrado
            //MostrarDatos(pB: 5, 7, 8);

            Console.WriteLine("Ahora con parametros opcionales");

            // Invocacion normal
            MuestraOpcionales(11, 12, 13);

            // Usamos dos paremtros, c usa el opciona
            MuestraOpcionales(20, 21);

            // Usamos un parametro, b y c usa el opciona
            MuestraOpcionales(31);

            // Usamos todos los parametros opcionales
            MuestraOpcionales();

            Console.WriteLine("Ahora con nombrados y opcionales");

            // Un opcional con dos nombrados
            MuestraOpcionales(pC: 67, pB: 45);

            // Dos opcionales con un nombrado
            MuestraOpcionales(pB: 56);
        }
        public static void MostrarDatos(int pA, int pB, int pC)
        {
            Console.WriteLine("Wl valor de A es {0}", pA);
            Console.WriteLine("Wl valor de B es {0}", pB);
            Console.WriteLine("Wl valor de C es {0}", pC);
            Console.WriteLine("------------------------");
        }
        public static void MuestraOpcionales(int pA=1, int pB=2, int pC=3)
        {
            Console.WriteLine("Wl valor de A es {0}", pA);
            Console.WriteLine("Wl valor de B es {0}", pB);
            Console.WriteLine("Wl valor de C es {0}", pC);
            Console.WriteLine("------------------------");
        }
    }
}
