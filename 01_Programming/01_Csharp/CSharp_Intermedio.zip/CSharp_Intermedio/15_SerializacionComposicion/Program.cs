﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using System.IO;

namespace _15_SerializacionComposicion
{
    [Serializable]
    public class CMotor
    {
        private int cilindros;
        private int hp;
        public int Cilindros { get => cilindros; set => cilindros = value; }
        public int Hp { get => hp; set => hp = value; }
        public CMotor()
        {
            cilindros = 4;
            hp = 200;
        }
        public CMotor(int pCilindros, int pHP)
        {
            cilindros = pCilindros;
            hp = pHP;
        }
        public void MuestraMotor()
        {
            Console.WriteLine("=== Cilindros: {0}, HP: {1}", cilindros, hp);
        }
    }
    [Serializable]  
    public class CAuto
    {
        private double costo;
        private string modelo;
        private CMotor motor;       
        public double Costo { get => costo; set => costo = value; }
        public string Modelo { get => modelo; set => modelo = value; }
        internal CMotor Motor { get => motor; set => motor = value; }
        public CAuto()
        {
            costo = 100000;
            modelo = "Vocho";
            motor = new CMotor();
        }
        public CAuto(string pModelo, double pCosto, int pCilindros, int pHP)
        {
            modelo = pModelo;
            costo = pCosto;
            motor = new CMotor(pCilindros, pHP);
        }
        public void MuestraInformacion()
        {
            Console.WriteLine("Tu Automovil {0}", Modelo);
            Console.WriteLine("Costo {0}", Costo);
            motor.MuestraMotor();
            Console.WriteLine("-----------------------");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            string valor = "";
            Console.WriteLine("1) Crear y serializar auto,  2) Leer auto");
            valor = Console.ReadLine();
            opcion = Convert.ToInt32(valor);
            if (opcion == 1)
            {
                string modelo = "";
                double costo = 0;
                int cilindros = 0;
                int hp = 0;
                Console.WriteLine("Dame el modelo");
                modelo = Console.ReadLine();
                Console.WriteLine("Dame el costo");
                valor = Console.ReadLine();
                Console.WriteLine("Dame los cilindros");
                valor = Console.ReadLine();
                cilindros = Convert.ToInt32(valor);
                Console.WriteLine("Dame los HP");
                valor = Console.ReadLine();
                hp = Convert.ToInt32(valor);
                costo = Convert.ToDouble(valor);

                CAuto miAuto = new CAuto(modelo, costo, cilindros, hp);

                //miMotor.Cilindros = cilindros;
                //miMotor.Hp = hp;

                //miAuto.Modelo = modelo;
                //miAuto.Costo = costo;
                //miAuto.Motor = miMotor;

                Console.WriteLine("Auto a serializar");
                miAuto.MuestraInformacion();
                // Empezamos la serializacion
                Console.WriteLine("----- Serializamos -----");

                //BinaryFormatter formateador = new BinaryFormatter();
                XmlSerializer formateador = new XmlSerializer(typeof(CAuto), new Type[] { typeof(CMotor) });

                Stream miStream = new FileStream("Autos.aut", FileMode.Create, FileAccess.Write, FileShare.None);
                // Serializamos
                formateador.Serialize(miStream, miAuto);
                miStream.Close();
            }
            if (opcion == 2)
            {
                Console.WriteLine("----- Deserializamos -----");
                //BinaryFormatter formateador = new BinaryFormatter();
                XmlSerializer formateador = new XmlSerializer(typeof(CAuto), new Type[] { typeof(CMotor) });
                Stream miStream = new FileStream("Autos.aut", FileMode.Open, FileAccess.Read, FileShare.None);
                // Deserializamos
                CAuto miAuto = (CAuto)formateador.Deserialize(miStream);
                miStream.Close();
                Console.WriteLine("El auto deserializado es:");
                miAuto.MuestraInformacion();
            }
            Console.ReadKey();
        }
    }
}
