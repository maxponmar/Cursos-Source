﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;
namespace _14_SerializacionXML
{
    [Serializable]
    // La clase es publica, es decir, lo que este fuera del namespace tiene acceso a ella
    public class CAuto
    {
        private double costo;
        private string modelo;
        // Para serializar en XML el constructor no debe de recibir parametros
        public CAuto()
        {
            costo = 100000;
            modelo = "Vocho";
        }
        public double Costo { get => costo; set => costo = value; }
        public string Modelo { get => modelo; set => modelo = value; }
        public void MuestraInformacion()
        {
            Console.WriteLine("Tu Automovil {0}", Modelo);
            Console.WriteLine("Costo {0}", Costo);
            Console.WriteLine("-----------------------");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            string valor = "";
            Console.WriteLine("1) Crear y serializar auto,  2) Leer auto");
            valor = Console.ReadLine();
            opcion = Convert.ToInt32(valor);
            if (opcion == 1)
            {
                string modelo = "";
                double costo = 0;
                Console.WriteLine("Dame el modelo");
                modelo = Console.ReadLine();
                Console.WriteLine("Dame el costo");
                valor = Console.ReadLine();
                costo = Convert.ToDouble(valor);
                CAuto miAuto = new CAuto();
                miAuto.Modelo = modelo;
                miAuto.Costo = costo;
                Console.WriteLine("Auto a serializar");
                miAuto.MuestraInformacion();
                // Empezamos la serializacion
                Console.WriteLine("----- Serializamos -----");
                XmlSerializer formateador = new XmlSerializer(typeof(CAuto));
                Stream miStream = new FileStream("Autos.aut", FileMode.Create, FileAccess.Write, FileShare.None);
                // Serializamos
                formateador.Serialize(miStream, miAuto);
                miStream.Close();
            }
            if (opcion == 2)
            {
                Console.WriteLine("----- Deserializamos -----");
                XmlSerializer formateador = new XmlSerializer(typeof(CAuto));
                Stream miStream = new FileStream("Autos.aut", FileMode.Open, FileAccess.Read, FileShare.None);
                // Deserializamos
                CAuto miAuto = (CAuto)formateador.Deserialize(miStream);
                miStream.Close();
                Console.WriteLine("El auto deserializado es:");
                miAuto.MuestraInformacion();
            }
            Console.ReadKey();
        }
    }
}
