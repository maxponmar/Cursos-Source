﻿using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace _12_SerializacionBinaria
{
    [Serializable]
    class CAuto
    {
        private double costo;
        private string modelo;
        public CAuto(string pModelo, double pCosto)
        {
            costo = pCosto;
            modelo = pModelo;
        }
        public void MuestraInformacion()
        {
            Console.WriteLine("Tu Automovil {0}", modelo);
            Console.WriteLine("Costo {0}", costo);
            Console.WriteLine("-----------------------");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            string valor = "";
            Console.WriteLine("1) Crear y serializar auto,  2) Leer auto");
            valor = Console.ReadLine();
            opcion = Convert.ToInt32(valor);
            if (opcion == 1)
            {
                string modelo = "";
                double costo = 0;
                Console.WriteLine("Dame el modelo");
                modelo = Console.ReadLine();
                Console.WriteLine("Dame el costo");
                valor = Console.ReadLine();
                costo = Convert.ToDouble(valor);
                CAuto miAuto = new CAuto(modelo, costo);
                Console.WriteLine("Auto a serializar");
                miAuto.MuestraInformacion();
                // Empezamos la serializacion
                Console.WriteLine("----- Serializamos -----");
                BinaryFormatter formateador = new BinaryFormatter();
                Stream miStream = new FileStream("Autos.aut", FileMode.Create, FileAccess.Write, FileShare.None);
                // Serializamos
                formateador.Serialize(miStream, miAuto);
                miStream.Close();
            }
            if (opcion == 2)
            {
                Console.WriteLine("----- Deserializamos -----");
                BinaryFormatter formateador = new BinaryFormatter();
                Stream miStream = new FileStream("Autos.aut", FileMode.Open, FileAccess.Read, FileShare.None);
                // Deserializamos
                CAuto miAuto = (CAuto)formateador.Deserialize(miStream);
                miStream.Close();
                Console.WriteLine("El auto deserializado es:");
                miAuto.MuestraInformacion();
            }
        }
    }
}
