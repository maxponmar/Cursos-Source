﻿using System;

namespace _19_MisMates
{
    public class MisMates
    {
        public static double Suma(double pA, double pB)
        {
            return pA + pB;
        }
        public static double Resta(double pA, double pB)
        {
            return pA - pB;
        }
        public static double Multi(double pA, double pB)
        {
            return pA * pB;
        }
        public static double Div(double pA, double pB)
        {
            return pA / pB;
        }
    }
}
