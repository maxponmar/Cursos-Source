﻿using System;

namespace _04_ICloneable
{
    interface IAutomovil
    {
        // Calcular el impuesto
        void CalculaTenencia(double imp);
        // Mostrar informacion
        void MuestraInformacion();
    }
    class CAuto : IAutomovil, ICloneable
    {
        private double costo, tenencia;
        private string modelo;
        // Constructor
        public CAuto(string pModelo, double pCosto)
        {
            // Inicializamos los datos
            Costo = pCosto;
            modelo = pModelo;
        }
        public double Costo { get => costo; set => costo = value; }
        public double Tenencia { get => tenencia; set => tenencia = value; }

        // Metodos interfaz
        public void CalculaTenencia(double pImpuesto)
        {
            // Calculamos el impuesto
            Tenencia = 5000 + Costo * pImpuesto;
        }
        public void MuestraInformacion()
        {
            // Mostramos la informacion
            Console.WriteLine("Tu automovil {0}", modelo);
            Console.WriteLine("Costo {0}, con una tenencia de {1}", Costo, Tenencia);
            Console.WriteLine("---------");
        }
        // Metodo para implementar ICloneable
        public object Clone()
        {
            CAuto temp = new CAuto(modelo, costo);
            temp.Tenencia = tenencia;
            return temp;
        }
    }
    class Program
    {        
        static void Main(string[] args)
        {
            CAuto Auto1 = new CAuto("March", 170000);
            // Aqui pensamos que hacemos clonado
            // Pero solo es otra variable referenciada a la misma instancia
            CAuto Auto2 = Auto1;
            Auto1.CalculaTenencia(0.10);
            Auto2.CalculaTenencia(0.10);
            // Imprimirmos
            Auto1.MuestraInformacion();
            Auto2.MuestraInformacion();
            Console.WriteLine("-----------------");

            // Hacemos un cambio, si fuera un clon solo uno cambia
            Auto1.Costo = 60000;
            Auto1.MuestraInformacion();
            Auto2.MuestraInformacion();
            Console.WriteLine("=============");

            // Ahora si hacemos un clon
            CAuto Auto3 = (CAuto)Auto1.Clone();
            Auto1.MuestraInformacion();
            Auto3.MuestraInformacion();
            Console.WriteLine("-----------------");
            Auto1.Costo = 25000;
            Auto1.MuestraInformacion();
            Auto3.MuestraInformacion();
            Console.WriteLine("-----------------");

            Console.ReadKey();
        }
    }
}
