﻿using System;

namespace _05_IComparable
{
    class CRectangulo : IComparable
    {
        private double ancho;
        private double alto;
        private double area;

        public CRectangulo(double pAncho, double pAlto)
        {
            ancho = pAlto;
            alto = pAlto;
            CalculaArea();
        }
        private void CalculaArea()
        {
            area = ancho * alto;
        }
        public override string ToString()
        {
            return string.Format("[{0},{1}]={2}", ancho, alto, area);
        }
        // Implementacion de IComparable
        int IComparable.CompareTo(object obj)
        {
            // Hacemos type caste con el objeto con el cual nos vamos a comparar
            CRectangulo temp = (CRectangulo)obj;
            // Si somos mas grande que el objeto regresamos 1
            if (area > temp.area)
                return 1;
            // Si somos mas pequenos que el objeto regresamos -1
            if (area < temp.area)
                return -1;
            // Si somos iguales al objeto regresamos 0            
            return 0;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CRectangulo[] rects = new CRectangulo[5];
            rects[0] = new CRectangulo(7, 5);
            rects[1] = new CRectangulo(6, 4);
            rects[2] = new CRectangulo(4, 3);
            rects[3] = new CRectangulo(7, 6);
            rects[4] = new CRectangulo(5, 7);
            // Imprimirmos arreglo original
            foreach(CRectangulo r in rects)
                Console.WriteLine(r);
            Console.WriteLine("-------------");
            // Hacemos uso de sort, el cual necesita la implementacion de IComparable
            Array.Sort(rects);
            // Imprimimos arreglo ordenado
            foreach (CRectangulo r in rects)
                Console.WriteLine(r);

            Console.ReadKey();
        }
    }
}
