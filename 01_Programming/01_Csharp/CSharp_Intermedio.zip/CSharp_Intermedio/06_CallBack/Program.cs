﻿using System;
using System.Collections;

namespace _06_CallBack
{
    interface IEventosRefri
    {
        // Aqui definimos los eventos que tendra el refri
        void EReservasBajas(int pKilos);
        // Adicionamos otro evento
        void EDescongelado(int pGrados);
    }
    class CRefriSink : IEventosRefri
    {
        // Esta es la clase sink
        private bool paro = false;
        public bool Paro { get; }
        // Aqui colocamos los handlers de los eventos
        public void EReservasBajas(int pKilos)
        {
            // Aqui se coloca todo el codigo necesario cuando ocurra el evento
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("--> Reservas bajas de alimentos");
            Console.WriteLine("--> Quedan {0} kilos",pKilos);
        }
        public void EDescongelado(int pGrados)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("--> El refri se descongela");
            if (pGrados < 0)
                paro = true;
        }
    }
    class CTiendaSink : IEventosRefri
    {
        public void EReservasBajas(int pKilos)
        {
            // Aqui se coloca todo el codigo necesario cuando ocurra el evento
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("--> Le enviaremos sus alimentos");
            Console.WriteLine("--> Seran {0} kilos", pKilos);
        }
        public void EDescongelado(int pGrados)
        {
            // Handler vacio
        }
    }
    class CRefri
    {
        // Aqui guardamos todos los sinks con los que se comunicara el refri
        private ArrayList listaSinks = new ArrayList();
        private int kilosAlimentos = 0;
        private int grados = 0;
        // Propiedades necesarias
        public int Kilos { get => kilosAlimentos; }
        public int Grados { get => grados; }
        public CRefri(int pKilos, int pGrados)
        {
            // Coloca los valores iniciales del refri
            kilosAlimentos = pKilos;
            grados = pGrados;
        }        
        // Con este metodo adicionamos un sink
        public void AgregarSink(IEventosRefri pSink)
        {
            if (pSink != null)
                listaSinks.Add(pSink);
        }
        // Con este metodo eliminamos un sink
        public void EliminarSink(IEventosRefri pSink)
        {
            if (listaSinks.Contains(pSink))
                listaSinks.Remove(pSink);
        }
        public void Trabajar(int pConsumo)
        {
            // Actualizamos los kilos del refri
            kilosAlimentos -= pConsumo;
            // Subimos la temperatura;
            grados += 1;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("{0} kilos, {1} grados", kilosAlimentos, grados);
            // Hay que verificar si se cumple la condicion para
            // invocar los handlers del evento
            // Esa es la condicion del evento
            if (kilosAlimentos < 10)
            {
                // Invocamos a los handlers de cada sink
                foreach (IEventosRefri handler in listaSinks)
                {
                    handler.EReservasBajas(kilosAlimentos);
                }
            }
            // Esa es la condicion del evento de descongelado
            if (grados >= 0)
            {
                // Invocamos a los handlers de cada sink
                foreach (IEventosRefri handler in listaSinks)
                {
                    handler.EDescongelado(grados);
                }
            }
        }
    }    
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos el refri
            CRefri miRefri = new CRefri(50, -20);
            Random rnd = new Random();
            // Creamos el sink
            // Sink1 tiene el codigo que se ejecutara cuando suceda el evento
            CRefriSink sink1 = new CRefriSink();
            CTiendaSink sink2 = new CTiendaSink();
            // Adicionamos el sink al refri
            miRefri.AgregarSink(sink1);
            miRefri.AgregarSink(sink2);
            // El refri hace su trabajo
            while (miRefri.Kilos > 0 && sink1.Paro == false)
            {
                // El refri trabaja y le sacamos kilos al azar
                miRefri.Trabajar(rnd.Next(1, 5));
            }
            Console.ReadKey();
        }
    }
}
