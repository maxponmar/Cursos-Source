﻿using System;
using System.Text.RegularExpressions;

namespace _20_ExpresionesRegulares
{
    class Program
    {
        static void Main(string[] args)
        {
            // Metodo 1
            // Busqueda de expresion en un texto
            string texto = "La casa del casamentero";
            string exp = "casa";

            MatchCollection encontrado = Regex.Matches(texto, exp);
            foreach (Match e in encontrado)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine("-------------------");

            // Metodo 2
            // Busqueda de una palabra especifica (oojo si esta al final)
            texto = "El estudiante es un casa nova en la escuela";
            exp = " casa ";
            Regex expReg = new Regex(exp);
            encontrado = expReg.Matches(texto);
            foreach (Match e in encontrado)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine("-------------------");
            
            // Uso de . significa cualquier caracter
            // cabal, campeon, academico
            texto = "Saludas al mas cabal";
            exp = " ca. ";
            MatchesExp(texto, exp);

            // Uso de clases de caracteres, se usa [] para contener los caracteres
            // Nico, Necio, Naco
            texto = "Hola Nico";
            exp = "N[ie]c";
            MatchesExp(texto, exp);

            // Un rango
            // Nico, Neco, Noco, Ndco, Nxzco
            texto = "Hola Nico";
            exp = "N[a-u]c";
            MatchesExp(texto, exp);

            // Uso de complemento
            // Noco, Nico
            texto = "Hola Noco";
            exp = "N[^ie]c";
            MatchesExp(texto, exp);

            // Verificamos si tiene la expresion despues de n caracter
            texto = "De Youtube Nicosiored es mi canal favorito";
            exp = "N[ie]c";
            expReg = new Regex(exp);
            if (expReg.IsMatch(texto, 5)) 
                Console.WriteLine("Si tiene");
            else
                Console.WriteLine("No tiene");
            Console.WriteLine("-------------------");

            // Para saber si una cadena finaliza con una expresion
            texto = "De Youtube Nicosiored es mi canal favorito";
            exp = "N[ie]c$";
            MatchesExp(texto, exp);

            // Elemento opcional
            // Nico, Nilo, Nio
            texto = "Hola Nico";
            exp = "N[ie]c?o"; // La c es opcional
            MatchesExp(texto, exp);

            // Cuantificar
            // Busca que existan n de esos elementos
            texto = "Holaa 25 Nico";
            exp = "[0-9]{2}";
            MatchesExp(texto, exp);

            // Alternaciones 
            texto = "Yo se programar en C";
            exp = "(c|java|python)";
            MatchesExp(texto, exp);

            // Split
            texto = "Este es un test de separacion, division";
            exp = ",";
            string[] cadenas = Regex.Split(texto, exp);
            foreach(string c in cadenas)
                Console.WriteLine(c);
            Console.WriteLine("-------------------");

            // Reemplazar
            texto = "Yo hablo ingles y no soy ingles";
            expReg = new Regex("ingles");
            string reemplazo = "Español";
            string resultado = expReg.Replace(texto, reemplazo);
            Console.WriteLine(resultado);
        }
        public static void MatchesExp(string pTexto, string pExp)
        {
            MatchCollection encontrado = Regex.Matches(pTexto, pExp);
            foreach (Match e in encontrado)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine("-------------------");
        }
    }
}
