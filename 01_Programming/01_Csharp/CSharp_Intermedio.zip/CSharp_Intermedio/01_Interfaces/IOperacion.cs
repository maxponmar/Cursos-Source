﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01_Interfaces
{
    interface IOperacion
    {
        void Calcular(double a, double b);
        void Mostrar();
    }
}
