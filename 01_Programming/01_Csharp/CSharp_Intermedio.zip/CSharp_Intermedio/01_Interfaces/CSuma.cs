﻿using System;
using System.Collections;
using System.Text;

namespace _01_Interfaces
{
    class CSuma : IOperacion
    {
        private double r = 0;
        private ArrayList resultados = new ArrayList();
        // Metodos a implementar
        public void Calcular(double a, double b)
        {
            r = a + b;
        }
        public void Mostrar()
        {
            Console.WriteLine("El resultado de la suma es {0}", r);
            resultados.Add(r);
        }
        public void MuestraResultados()
        {
            foreach (double r in resultados)            
                Console.WriteLine(r);            
        }
    }

    class CResta : IOperacion
    {
        private double r = 0;       
        // Metodos a implementar
        public void Calcular(double a, double b)
        {
            r = a - b;
        }
        public void Mostrar()
        {
            Console.WriteLine("El resultado de la resta es {0}", r);            
        }
    }
    class CMulti : IOperacion
    {
        private double r = 0;
        // Metodos a implementar
        public void Calcular(double a, double b)
        {
            r = a * b;
        }
        public void Mostrar()
        {
            Console.WriteLine("El resultado de la multiplicacion es {0}", r);
        }
    }
    class CDiv : IOperacion
    {
        private double r = 0;
        // Metodos a implementar
        public void Calcular(double a, double b)
        {
            r = a / b;
        }
        public void Mostrar()
        {
            Console.WriteLine("El resultado de la division es {0}", r);
        }
    }
}