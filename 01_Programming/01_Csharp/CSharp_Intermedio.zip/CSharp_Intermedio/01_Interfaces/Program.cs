﻿using System;

namespace _01_Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            double vala = 0, valb = 0;
            string valor = "";
            IOperacion operacion = new CSuma();
            while (opcion != 5)
            {
                Console.Clear();
                Console.WriteLine("1.-Suma, 2.-Resta, 3.-Multi, 4.-Div, 5.-Salir");
                Console.WriteLine("Que opcion deseas?");
                valor = Console.ReadLine();
                opcion = Convert.ToInt32(valor);

                Console.WriteLine("Dame el valor de a");
                valor = Console.ReadLine();
                vala = Convert.ToInt32(valor);

                Console.WriteLine("Dame el valor de b");
                valor = Console.ReadLine();
                valb = Convert.ToInt32(valor);

                // Polimorfismo
                if (opcion == 1)
                    operacion = new CSuma();
                if (opcion == 2)
                    operacion = new CResta();
                if (opcion == 3)
                    operacion = new CMulti();
                if (opcion == 4)
                    operacion = new CDiv();

                // Aqui nuestro programa trabaja en terminos
                // del concepto Operacion, en lugar de en
                // terminos de cosas concretas como suma, resta, multi, div
                operacion.Calcular(vala, valb);
                operacion.Mostrar();
            }
        }
    }
}
