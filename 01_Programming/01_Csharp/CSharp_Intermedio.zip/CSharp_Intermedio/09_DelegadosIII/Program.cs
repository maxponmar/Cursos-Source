﻿using System;

namespace _09_DelegadosIII
{
    // Aqui van los delegados
    delegate void DReservasBajas(int pKilos);
    delegate void DDescongelado(int pGrados);
    class CRefri
    {        
        private int kilosAlimentos = 0;
        private int grados = 0;
        // Aqui estan las variables que usaremos para invocar
        private DReservasBajas delReservas;
        private DDescongelado delDescongelado;
        public CRefri(int pKilos, int pGrados)
        {
            // Coloca los valores inciciales del refri
            kilosAlimentos = pKilos;
            grados = pGrados;
        }
        // Estos metodos permiten referenciar las variables
        public void AdicionaMetodoReservas(DReservasBajas pMetodo)
        {
            delReservas += pMetodo;
        }
        public void EliminaMetodoReservas(DReservasBajas pMetodo)
        {
            delReservas -= pMetodo;
        }
        public void AdicionaMetodoDescongelado(DDescongelado pMetodo)
        {
            delDescongelado += pMetodo;
        }
        // Propiedaes necesarias
        public int Kilos { get { return kilosAlimentos; } set { kilosAlimentos = value; } }
        public int Grados { get { return grados; } set { grados = value; } }
        public void Trabajar(int pConsumo)
        {
            // Actualizamos los kilos del refri
            kilosAlimentos -= pConsumo;
            // Subimos la temperatura;
            grados += 1;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("{0} kilos, {1} grados", kilosAlimentos, grados);
            // Hay que verificar si se cumple la condicion para
            // invocar los handlers del evento
            // Esa es la condicion del evento
            if (kilosAlimentos < 10)
            {
                // Invocamos el metodo
                delReservas(kilosAlimentos);
            }
            // Esa es la condicion del evento de descongelado
            if (grados >= 0)
            {
                // Invocamos el metodo
                delDescongelado(grados);
            }
        }
    }
    class CTienda
    {
        public static void MandaViveres(int pKilos)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("--> Vamos a mandar sus viveres, estoy en la tienda");
            Console.WriteLine("--> Seran {0} kilos", pKilos);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos el refri
            CRefri miRefri = new CRefri(70, -20);
            Random rnd = new Random();
            // Variables para el multicasting, necesitamos la instancia para poder adicionar o eliminar
            DReservasBajas kilos1 = new DReservasBajas(InformeKilos);
            DReservasBajas kilos2 = new DReservasBajas(CTienda.MandaViveres);
            DDescongelado desc1 = new DDescongelado(InformeGrados);
            // Adicionamos los handlers
            miRefri.AdicionaMetodoReservas(kilos1);
            miRefri.AdicionaMetodoReservas(kilos2);
            miRefri.AdicionaMetodoDescongelado(desc1);
            // El refri hace su trabajo
            while (miRefri.Kilos > 0)
            {
                // El refri trabaja y le sacamos kilos al azar
                miRefri.Trabajar(rnd.Next(1, 5));
            }
            // Eliminamos un handler
            miRefri.EliminaMetodoReservas(kilos2);
            while (miRefri.Kilos > 0)
            {
                miRefri.Trabajar(rnd.Next(1, 5));
            }
            // Rellenamos el refri
            miRefri.Kilos = 50;
            miRefri.Grados = -15;
            while (miRefri.Kilos > 0)
            {
                miRefri.Trabajar(rnd.Next(1, 5));
            }
            Console.ReadKey();
        }
        public static void InformeKilos(int pKilos)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("--> Reservas bajas de alimentos, estoy a nivel de main");
            Console.WriteLine("--> Quedan {0} kilos", pKilos);
        }
        public static void InformeGrados(int pGrados)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("--> Se descongela el refri!, estoy a nivel de main");
            Console.WriteLine("--> Esta a {0} grados", pGrados);
        }
    }
}