﻿using System;

namespace _11_SobrecargaOperadoresBinarios
{
    class CImaginario : IComparable
    {
        private double real, imaginario;
        public CImaginario(double pReal, double pImaginario)
        {
            real = pReal;
            imaginario = pImaginario;
        }
        public double Real { get; set; }
        public double Imaginario { get; set; }
        public override string ToString()
        {
            if (imaginario < 0)
                return string.Format("({0}{1}i)", real, imaginario);
            else if (imaginario == 0)
                return string.Format("{0}", real);
            else 
                return string.Format("({0}+{1}i)", real, imaginario);
        }
        // Sobrecarga de operadores binarios
        public static CImaginario operator +(CImaginario i1, CImaginario i2)
        {
            double re = 0, ri = 0;
            re = i1.real + i2.real;
            ri = i1.imaginario + i2.imaginario;
            CImaginario resultado = new CImaginario(re, ri);
            return resultado;
        }
        public static CImaginario operator -(CImaginario i1, CImaginario i2)
        {
            double re = 0, ri = 0;
            re = i1.real - i2.real;
            ri = i1.imaginario - i2.imaginario;
            CImaginario resultado = new CImaginario(re, ri);
            return resultado;
        }
        public static CImaginario operator *(CImaginario i1, CImaginario i2)
        {
            double re = 0, ri = 0;
            re = (i1.real * i2.real) - (i1.imaginario * i2.imaginario);
            ri = (i1.real * i2.imaginario) + (i1.imaginario * i2.real);
            CImaginario resultado = new CImaginario(re, ri);
            return resultado;
        }
        public static CImaginario operator /(CImaginario i1, CImaginario i2)
        {
            double re = 0, ri = 0;
            re = ((i1.real * i2.real) + (i1.imaginario * i2.imaginario)) / ((i2.real * i2.real) + (i2.imaginario * i2.imaginario));
            ri = ((i1.imaginario * i2.real) - (i1.real * i2.imaginario)) / ((i2.real * i2.real) + (i2.imaginario * i2.imaginario));
            CImaginario resultado = new CImaginario(re, ri);
            return resultado;
        }
        // Sobrecarga de operadores unuarios e igualdad
        public static CImaginario operator ++(CImaginario i1)
        {
            CImaginario temp = new CImaginario(i1.real + 1, i1.imaginario + 1);
            return temp;
        }
        public static CImaginario operator --(CImaginario i1)
        {
            CImaginario temp = new CImaginario(i1.real - 1, i1.imaginario - 1);
            return temp;
        }
        // Sobre carga de igualdad y desigualdad
        public override bool Equals(object obj)
        {
            // Verificamos que sea el tipo correcto
            if(obj is CImaginario)
            {
                CImaginario temp = (CImaginario)obj;
                // Comparamos por igualdad
                if (imaginario == temp.imaginario && real == temp.real)
                    return true;
            }
            return false;
        }
        public static bool operator ==(CImaginario i1, CImaginario i2)
        {
            return i1.Equals(i2);
        }
        public static bool operator !=(CImaginario i1, CImaginario i2)
        {
            return !(i1.Equals(i2));
        }
        // Sobrecarga de < y > necesitamos IComparable
        public double magnitud()
        {
            double m = 0;
            m = Math.Sqrt((real * real) + (imaginario * imaginario));
            return m;
        }
        public int CompareTo(object obj)
        {
            if(obj is CImaginario)
            {
                CImaginario temp = (CImaginario)obj;
                if (magnitud() > temp.magnitud())
                    return 1;
                if (magnitud() < temp.magnitud())
                    return -1;
            }
            return 0;
        }
        public static bool operator <(CImaginario i1, CImaginario i2)
        {
            if (i1.CompareTo(i2) < 0)
                return true;
            else
                return false;
        }
        public static bool operator >(CImaginario i1, CImaginario i2)
        {
            if (i1.CompareTo(i2) > 0)
                return true;
            else
                return false;
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CImaginario im1 = new CImaginario(1, 2);
            CImaginario im2 = new CImaginario(3, 4);
            // Suma
            CImaginario imr = im1 + im2;
            Console.WriteLine("{0} + {1} = {2}", im1, im2, imr);
            // Resta
            imr = im1 - im2;
            Console.WriteLine("{0} - {1} = {2}", im1, im2, imr);
            // Mulitiplicacion
            imr = im1 * im2;
            Console.WriteLine("{0} * {1} = {2}", im1, im2, imr);
            // Division
            imr = im1 / im2;
            Console.WriteLine("{0} / {1} = {2}", im1, im2, imr);
            // Operadores unuarios
            imr = im1++;
            Console.WriteLine(imr);
            imr = im2--;
            Console.WriteLine(imr);
            imr += im2;
            Console.WriteLine(imr);
            imr -= im2;
            Console.WriteLine(imr);
            // Igualdad y desigualdad
            imr = new CImaginario(1, 2);
            im1 = new CImaginario(3, 4);
            im2 = new CImaginario(1, 2);
            Console.WriteLine("imr == im1: "+(imr == im1));
            Console.WriteLine("imr == im2: " + (imr == im2));
            // Mayor y menor que
            Console.WriteLine("imr < im1: " + (imr < im1));
            Console.WriteLine("imr > im2: " + (imr > im2));
            Console.ReadKey();
        }
    }
}
