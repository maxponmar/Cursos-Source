﻿using System;

namespace _07_DelegadosI
{
    class CRadio
    {
        // Este metodo actuara como delegado
        public static void MetodoRadio(string pMensaje)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Estamos en la clase radio");
            Console.WriteLine("Este es tu mensaje");
            Console.WriteLine("Este es tu mensaje: {0}", pMensaje);
        }
    }
    class CPastel
    {
        // Este metodo actuara como delegado
        public static void MostrarPastel(string pAnuncio)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("El pastel llevara el mensaje de {0}", pAnuncio);
        }
    }
    class Program
    {
        // Definimos el delegado con las caracteristicas que nos interesan
        public delegate void MiDelegado(string m);
        static void Main(string[] args)
        {
            // Creamos un objeto del delegado y lo referenciamos a un metodo
            MiDelegado delegado = new MiDelegado(CRadio.MetodoRadio);
            // Ahora por medio del delegado hacemos uso del metodo
            delegado("Hola a todos");
            // Hacemos que apunte a otro metodo
            delegado = new MiDelegado(CPastel.MostrarPastel);
            // Ahora invocamos el otro metodo
            delegado("Feliz cumpleaños");
            Console.ReadKey();
        }
    }
}
