﻿using System;
using _19_MisMates;

namespace _19_Bibliotecas
{
    class Program
    {
        static void Main(string[] args)
        {
            double r = 0;
            r = MisMates.Suma(5.6, 3.2);
            Console.WriteLine(r);
            r = MisMates.Resta(5.6, 3.2);
            Console.WriteLine(r);
            r = MisMates.Multi(5.6, 3.2);
            Console.WriteLine(r);
            r = MisMates.Div(5.6, 3.2);
            Console.WriteLine(r);
        }
    }
}
