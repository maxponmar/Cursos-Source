﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa01_04 // Métodos privados, #4
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos instancia 
            CCalculadora calcu1 = new CCalculadora();

            // Acedemos a los atributos para colocar informacion
            calcu1.a = 5;
            calcu1.b = 3;

            // Intento invocar método privado
            // No se puede
            //calcu1.Muestra();

            // Invocamos método
            calcu1.Suma();
        }
    }
}
