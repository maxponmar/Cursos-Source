﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa05_02
{
    class CPropietario
    {
        private string nombre;
        private CEdificio propiedad = null;

        public CPropietario(string pNombre)
        {
            nombre = pNombre;
            propiedad = new CEdificio("Av 2 número 32", 7, 4); // Aquí es donde ocurre la composición
        }                                                      // el objeto tipo edificio es creado en al ámbito de propietario por lo que no puede existir fuera de propietario
                                                               // si objeto propietario desaparece tambien lo hará objeto edificio
        public void MostrarPropiedad()
        {
            if (propiedad != null)
            {
                Console.Write("{0} tiene ", nombre);
                propiedad.Muestra();
            }
            else
                Console.WriteLine("{0} aun no tiene propiedades", nombre);
        }

        // Cuidado con esto, rompe el encapsulamiento
        public CEdificio Propiedad { get=>propiedad; set=>propiedad=value; }
        // con get estamos regresando una instancia de CEdificio al exterior, sin que CPropietario sepa que es lo que esta sucediendo
        // No debemos crear propiedades que regresen directamente referencia al objeto que se usa para hacer la composición, para evitar violación a la compisición y encapsulamiento
    }
}
