﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa06_01
{
    class CProductoImportado:CProducto
    {
        protected double impuesto;

        public CProductoImportado(string pDescrpcion, double pPrecioCompra, double pImpuesto)
            : base(pDescrpcion,pPrecioCompra)
        {
            impuesto = pImpuesto;
        }

        // Sealed en una función virutal indica que a partir de ahí ninguna herencia puede hacer override a CalculaPrecio
        public sealed override void CalculaPrecio() // Override permite usar la propia versión de CalculaPrecio, en lugar el de la clase padre CProudcto
        {                                          // Cuando se haga la invocación de CalculaPrecio de un objeto CPimportado se hará con este método
            Console.WriteLine("Calcula precio de importado");
            precioVenta = precioCompra * (1 + impuesto) * 1.30;
        }
    }
}
