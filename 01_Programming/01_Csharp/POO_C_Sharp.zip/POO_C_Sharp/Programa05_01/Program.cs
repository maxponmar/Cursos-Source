﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa05_01 // Agregación, #16
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ejemplo de agregación

            // Creamos al propietario

            CPropietario Juan = new CPropietario("Juan");

            // Creamos la propiedad

            CEdificio edif1 = new CEdificio("Av. 1 num 56", 10, 3);

            // Vemos info del propietario

            Juan.MostrarPropiedad();

            // Le colocamos la propiedad(edificio)

            Juan.AdicionaPropiedad(edif1);
            Juan.MostrarPropiedad();

            // Eliminamos a Juan  -   *Esta es una simulación para destrir a Juan pero no es la forma correcta, es solo para fines académicos
            Juan = null;
            GC.Collect();
            //Juan.MostrarPropiedad();

            Console.WriteLine("-------");

            // Verificamos que el edificio exista independiente de Juan
            edif1.Muestra();
        }
    }
}
