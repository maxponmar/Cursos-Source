﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proograma01_02
{
    class CMiClase
    {
        // Estos datos se pueden ver en cualquier lugar de las claso
        // Pero no fuera de ella, ambito de objeto
        private int b = 10;

        public void Muestra()
        {
            // Creamos una variable locas a Muestra
            // Ambito local
            int m = 5;

            int b = 3; // Variable b de ambito local

            // Podemos usar la variable local
            Console.WriteLine("m={0}",m);

            // Tratamos de mostrar la variable de main
            // No se puede
            //Console.WriteLine("a={0}",a);

            // Tratamos de mostrar el dato de la clase
            Console.WriteLine("Ambito local b={0}",b); // Si hay una variable "b" local, tendrá mayor prioridad
            Console.WriteLine("Ambito objeto this.b ={0}",this .b); // De esta manera puedes usar b de ambito de objeto en lugar de lcoal
        }

        public void Multiplicador()
        {
            // Tratamos de usar el dato de la clase
            b = b * 5;
            // Tratamos de usar la variable local del otro método
            // No se puede
            //m = m * 10;
        }
    }
}
