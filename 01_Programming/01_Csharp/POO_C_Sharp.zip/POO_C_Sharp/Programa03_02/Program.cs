﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa03_02 // Métodos estáticos, #12
{
    class Program
    {
        static void Main(string[] args)
        {
            double r = 0.0;

            // Clase normal
            CCalculadora miCalcu = new CCalculadora(5, 3);
            miCalcu.suma();
            Console.WriteLine("La suma es {0}", miCalcu.R);

            miCalcu.resta();
            Console.WriteLine("La resta es {0}",miCalcu.R);


            //Clase con métodos estáticos

            r = CCalculadoraS.suma(6, 9);
            Console.WriteLine("La suma es {0}",r);

            r = CCalculadoraS.resta(45, 67);
            Console.WriteLine("La resta es {0}", r);

            CCalculadoraS miS = new CCalculadoraS();
            miS.saludo();
            //r = miS.suma(5,3);   // Los métodos estáticos no pueden ser llamados por una instancia, solo por la clase
        }
    }
}
