﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Porgrama01_01 //Declaración de clases, #1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos instancia
            CCalculadora calcu1 = new CCalculadora();

            // Accedemos a los atributos para colocar información 
            calcu1.a = 5;
            calcu1.b = 3;

            // Mostramos los datos
            calcu1.Muestra();

            // Invocamos método
            calcu1.Suma();

            // Mostrmoas nuevamente los datos
            calcu1.Muestra();

            //----------------------------------------------
            Console.WriteLine("--------------------------------");
            //Creamos otro objeto y asignamos valores
            CCalculadora miCalcu = new CCalculadora();
            miCalcu.a = 18;
            miCalcu.b = 53;
            miCalcu.Suma();

            //Comprobamos que cada objeto tiene su propia información

            calcu1.Muestra();
            miCalcu.Muestra();
        }
    }
}
