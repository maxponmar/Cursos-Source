﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa06_02 // Uso de new en métodos, #19
{
    class Program
    {
        static void Main(string[] args)
        {
            // Uso de new en métodos
            // Nos permite poner código propio a métodos no virtuales
            // Pero perdemos polimorfismo

            CProductoImportado miProducto = new CProductoImportado("Motocicleta", 45000, 0.15);

            miProducto.CalculaPrecio();
            miProducto.MuestraVenta();

            Console.WriteLine("--------");

            CProducto p1 = new CProducto("Televisión", 10500);
            p1.CalculaPrecio();
            p1.MuestraVenta();

            Console.WriteLine("---------");

            // Esto es polimorfismo, uso de polimorfismo para p3
            CProducto p3 = new CProductoImportado("Bicicleta", 2200, 0.2);
            p3.CalculaPrecio(); // Aquí se hace CalculaPrecio de CProductoImportado debido al override y virtual
            p3.MuestraVenta(); // Se ejectua MuestraVenta de CProducto, no de CProductoImportado
        }
    }
}
