﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa06_02
{
    class CProductoImportado:CProducto
    {
        protected double impuesto;

        public CProductoImportado(string pDescrpcion, double pPrecioCompra, double pImpuesto)
            : base(pDescrpcion, pPrecioCompra)
        {
            impuesto = pImpuesto;
        }

       
        public override void CalculaPrecio() 
        {                                          
            Console.WriteLine("Calcula precio de importado");
            precioVenta = precioCompra * (1 + impuesto) * 1.30;
        }

        public new void MuestraVenta() //Importado ahora utiliza su propia versión de MuestraVenta pero rompe con el polimorfismo
        {
            Console.WriteLine("El gran producto {0} se vente en ${1}!!!!!", descripcion,precioVenta);
        }
    }
}
