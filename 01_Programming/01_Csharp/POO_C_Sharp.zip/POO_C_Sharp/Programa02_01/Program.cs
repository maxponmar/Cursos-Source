﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa02_01 // Sobrecarga de métodos/overloading, #8
{
    class Program
    {
        static void Main(string[] args)
        {
            int rInt = 0;
            double rDoub = 0.0;

            CCalculadora calcu = new CCalculadora();

            rInt = calcu.Suma(5, 3);
            Console.WriteLine("El resultado es {0}", rInt);

            rDoub = calcu.Suma(10.58, 23.17); //Se invoca el mismo método pero el compilador decida cual ejecutar
            Console.WriteLine("El resultado es {0}", rDoub);

            rInt = calcu.Suma(5, 3, 2);
            Console.WriteLine("El resultado es {0}", rInt);
        }
    }
}
