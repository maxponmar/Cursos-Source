﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa02_01
{
    // Esta clase es definida por nosotros
    class CCalculadora
    {
        // Declaramos los métodos
        public int Suma(int a, int b)
        {
            int r = 0;
            r = a + b;
            return r;
        }

        public double Suma(double a, double b) //Sobrecarga de un método
        {
            double r = 0.0;
            r = a + b;
            return r;
        }

        public int Suma(int a, int b, int c)
        {
            int r = 0;
            r = a + b + c;
            return r;
        }
    }
}
