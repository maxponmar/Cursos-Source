﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa02_02
{
    class CPersona
    {
        private string nombre;
        private int edad;

        public CPersona(string pNombre, int pEdad) // Este es el constructor
        {
            // Constructor 1
            //Console.WriteLine("Estamos en el constructor");
            //nombre = "";
            //edad = 0;

            // Constructor 2
            //string tempEdad = "";

            //Console.WriteLine("Estamos en el constructor");
            //Console.WriteLine("Dame el nombre");
            //nombre = Console.ReadLine();
            //Console.WriteLine("Dame la edad");
            //tempEdad = Console.ReadLine();
            //edad = Convert.ToInt32(tempEdad);

            // Constructor 3  es necesario incluir string pNombre, int pEdad coomo parametros de constructor
            Console.WriteLine("Estamos en el constructor");
            nombre = pNombre;
            edad = pEdad;

        }

        public string Nombre
        {
            set { nombre = value; }
        }

        public int Edad
        {
            set { edad = value; }
        }

        public void muestra()
        {
            Console.WriteLine("Nombre: {0}, edad: {1}",nombre, edad);
        }
    }
}
