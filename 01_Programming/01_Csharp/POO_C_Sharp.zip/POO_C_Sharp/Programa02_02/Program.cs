﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa02_02 // El constructor, #9
{
    class Program
    {
        static void Main(string[] args)
        {
            CPersona p1 = new CPersona("Max",20);// Para constructor 3 se necesita dar los parametros, nombrey edad

            // Para constructor 1 
            //p1.Nombre = "Juan";
            //p1.Edad = 20;

            p1.muestra();
        }
    }
}
