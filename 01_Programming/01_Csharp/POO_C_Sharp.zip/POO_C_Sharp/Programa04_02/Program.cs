﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa04_02 // Uso del constructor en herencia, #14
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos objeto de la clase persona
            CPersona uno = new CPersona("Maria",27);

            uno.Muestra();
            Console.WriteLine("--------");

            //Creamos un objeto de la clase Empleado
            CEmpleado dos = new CEmpleado("Juan",30,"Contador",10500.50);

            // Colocamos la informacion usando las propiedades de su clase base

            // Usamos el muestra de empleado
            dos.EmpleadoMuestra();

            Console.WriteLine("------------");

            //Creamos otro empleado
            CEmpleado tres = new CEmpleado("Susana", 25, "Programadora", 150000.30);
            tres.EmpleadoMuestra();
            Console.WriteLine("------");
            tres.ponerDatos("Susana", 23, "Programadora Senior", 180000.70);

            tres.EmpleadoMuestra();

        }
    }
}
