﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa06_05 // Polimorfismo, #22
{
    class Program
    {
        static void Main(string[] args) // Si no trabajas de forma polimorfica estas trabajando de forma concreta
        {
            string valor;
            int opcion;

            // Sin polimorfismo, queda concreto a la clase

            Console.WriteLine("Que mascota quieres? 1.-Gato. 2.- Reptil");
            valor = Console.ReadLine();
            opcion = Convert.ToInt32(valor);

            if (opcion==1)
            {
                CGato migato = new CGato();
                migato.Nombre = "Fuzzy";
                migato.Moverse();
            }
            if (opcion==2)
            {
                CReptil mireptil = new CReptil();
                mireptil.Nombre = "Lizardo";
                mireptil.Moverse();
            }

            Console.WriteLine("--------------");

            // Con polimorfismo, el código se concentra en el concepto no en la clase

            Console.WriteLine("Que mascota quieres? 1.-Perro, 2.-Pez, 3.-Ave");
            valor = Console.ReadLine();
            opcion = Convert.ToInt32(valor);

            // Creamos la variable que tendrá polimorfismo
            CAnimal miMascota = new CAnimal();

            // Basado en la selección le damos el comportamiento seleccionado
            switch (opcion)
            {
                case 1:
                    miMascota = new CPerro();
                    break;
                case 2:
                    miMascota = new CPez();
                    break;
                case 3:
                    miMascota = new CAve();
                    break;             
            }

            // Ahora trabajamos en terminos del concepto Animal y no en terminos de clases específicas
            Console.WriteLine("Dame el nombre");
            miMascota.Nombre = Console.ReadLine();

            miMascota.Moverse();
        }
    }
}
