﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa06_04 // Casting, #21
{
    class Program
    {
        static void Main(string[] args)
        {
            // Casting   permite que una clase trabaje como si fuera otra

            // Podemos hacer casting de una clase en la cadena de herencia
            // CproductoImportado es un CProducto

            CProducto p1 = new CProductoImportado("Tele", 2500, 0.15); // Se guardo un CProductoImportado dentro de un CProducto

            p1.CalculaPrecio();
            Console.WriteLine(p1);

            // No puede invocar lo que no es común
            //p1.Mensaje();

            ((CProductoImportado)p1).Mensaje();  // Typecast, tiene que estar en la cadena de herencia
                                                 // considera a p1 como CProductoImportado
            Console.WriteLine("-----");

            // CProducto es un object

            object p2 = new CProducto("Radio", 300);
            ((CProducto)p2).CalculaPrecio();
            Console.WriteLine(((CProducto)p2));

            Console.WriteLine("--------");

            //Object no es un CProducto
            //CProducto p3 = new Object();

            Console.WriteLine("----- Detecta -----");
            CProducto p4 = new CProducto("Balón", 250.50);

            Detecta(p1);
            Detecta((CProducto)p2);
            Detecta(p4);

            Console.WriteLine("------");
            // Casing númericos

            int a = 57;
            float b = 5.67f;
            double c = 123.456;
            byte x = 5;


            // De un tipo menor a uno mayor no hace falta poner explicitamente el casting
            a = x;
            Console.WriteLine(a);

            double y = b;
            Console.WriteLine(y);

            // De un tipo mayor a uno menor
            //b=c;
            b = (float)c;
            Console.WriteLine(b);

        }

        public static void Detecta(CProducto pProducto)
        {
            if (pProducto is CProducto)
            {
                Console.WriteLine("== Es CProducto");
                pProducto.CalculaPrecio();
                Console.WriteLine(pProducto);
            }
            if (pProducto is CProductoImportado)
            {
                Console.WriteLine("== Es CProductoImportado");
                pProducto.CalculaPrecio();
                Console.WriteLine(pProducto);
            }
        }
    }
}
