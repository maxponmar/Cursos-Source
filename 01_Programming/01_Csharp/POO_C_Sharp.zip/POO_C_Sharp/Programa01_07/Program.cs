﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa01_07 // Las propiedades, get, set, value, #7
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creamos objetos
            CEmpleado Juan = new CEmpleado();

            Juan.Sueldo = 15000;
            Juan.CalculaImpuesto();

            Console.WriteLine("El impuesto de Juan es {0}",Juan.Impuesto);
            Juan.Muestra();
        }
    }
}
