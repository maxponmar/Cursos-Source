﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa01_03 // Acceso público y privado, #3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos instancia 
            CCalculadora calcu1 = new CCalculadora();

            // Acedemos a los atributos para colocar informacion
            calcu1.a = 5;
            calcu1.b = 3;

            // Intento acceder al dato privado
            // No se puede
            //Console.WriteLine(calcu1.r);

            // Mostramos los datos
            calcu1.Muestra();

            // Invocamos método
            calcu1.Suma();

            // Mostramos nuevamente los datos
            calcu1.Muestra();
        }
    }
}
