﻿using System;

namespace HashSeparate
{
    class Program
    {
        // Cantidad de celdas en la tabla
        private static int tamano = 10;
        private static CListaLigada[] tabla;
        static void Main(string[] args)
        {
            int n = 0;
            // Necesitamos un arreglo de listas ligadas para crear la tabla
            tabla = new CListaLigada[tamano];
            // Iniciamos la tabla
            for (n = 0; n < tamano; n++)
                tabla[n] = new CListaLigada();
            Mostrar();
            Insertar(57, "Hola");
            Insertar(45, "Manzana");
            Insertar(42, "Pera");
            Insertar(83, "Azul");
            Insertar(30, "Rojo");
            Insertar(94, "C#");
            Insertar(73, "C++");
            Insertar(97, "Saludos");
            Console.WriteLine("---");

            Mostrar();

            Console.ReadKey();
        }
        public static void Mostrar()
        {
            int n = 0;
            for (n = 0; n < tamano; n++)
            {
                Console.Write("({0})", n);
                tabla[n].Transversa();
                Console.WriteLine();
            }
        }
        public static int HashF(int pLlave)
        {
            int indice = 0;
            // Funcion muy sencilla, no usar en el mundo real
            indice = pLlave % tamano;
            return indice;
        }
        public static void Insertar(int pLlave, string pValor)
        {
            int indice = HashF(pLlave);
            tabla[indice].Adicionar(pLlave, pValor);
        }
    }
}
