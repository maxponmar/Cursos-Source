﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HashSeparate
{
    class CNodo
    {
        // Aqui colocamos el dato o datos que guarda el nodo
        private int llave;
        private string valor;
        // Esta variable de referencia es usada para apuntar al nodo
        private CNodo siguiente = null;
        //Propiedades que usaremos
        public int Llave { get => llave; set => llave = value; }
        public string Valor { get => valor; set => valor = value; }
        internal CNodo Siguiente { get => siguiente; set => siguiente = value; }
        // Para su facil impresion
        public override string ToString()
        {
            return string.Format("[{0}, {1}]", llave, valor);
        }
    }
}
