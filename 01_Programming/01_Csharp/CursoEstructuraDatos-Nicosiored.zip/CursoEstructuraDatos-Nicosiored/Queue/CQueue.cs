﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Queue
{
    class CQueue
    {
        // Implementacion basada en lista ligada
        // Ancla o encabezado de la cola
        private CNodo ancla;
        // Esta variable de referencia nos ayuda a trabajar con la cola
        private CNodo trabajo;
        public CQueue()
        {
            // Instanciamos el ancla
            ancla = new CNodo();
            // Como es una cola vacia si siguiente es null
            ancla.Siguiente = null;
        }
        // Recorre toda la lista
        public void Transversa()
        {
            // Trabajo al inicio
            trabajo = ancla;
            // Recorremos hasta encontrar el final
            while (trabajo.Siguiente != null)
            {
                // Avanzamos trabajo
                trabajo = trabajo.Siguiente;
                // Obtenemos el dato y lo mostramos
                int d = trabajo.Dato;
                Console.Write("<-- {0} , ", d);
            }
            // Bajamos la linea
            Console.WriteLine();
        }
        public void Enqueue(int pDato)
        {
            // Trabajo al inicio
            trabajo = ancla;
            // Recorremos hasta encontrar el final
            while (trabajo.Siguiente != null)
            {
                // Avanzamos trabajo
                trabajo = trabajo.Siguiente;
            }
            // Creamos el nuevo nodo
            CNodo temp = new CNodo();
            // Insertamos el dato
            temp.Dato = pDato;
            // Finalizamos correctamente
            temp.Siguiente = null;
            // Ligamos el ultimo nodo encontrado con el recien creado
            trabajo.Siguiente = temp;
        }
        public int Dequeue()
        {
            // Esta version no contiene codigo de seguridad
            // Colocar una excepcion cuando se intente hacer Dequeue cuando el queue este vacio
            int valor = 0;
            // Llevamos a cabo el trabajo solo si hay elementos en el queue
            if (ancla.Siguiente != null)
            {
                // Obtenemos el dato correspondiente
                trabajo = ancla.Siguiente;
                valor = trabajo.Dato;
                // Lo sacamos del queue
                ancla.Siguiente = trabajo.Siguiente;
                trabajo.Siguiente = null;
            }
            return valor;
        }
        // Peek
        public int Peek()
        {
            // Esta version no contiene codigo de seguridad
            // Colocar una excepcion cuando se intente hacer Dequeue cuando el queue este vacio
            int valor = 0;
            // Llevamos a cabo el trabajo solo si hay elementos en el queue
            if (ancla.Siguiente != null)
            {
                // Obtenemos el dato correspondiente
                trabajo = ancla.Siguiente;
                valor = trabajo.Dato;
            }
            return valor;
        }
    }
}
