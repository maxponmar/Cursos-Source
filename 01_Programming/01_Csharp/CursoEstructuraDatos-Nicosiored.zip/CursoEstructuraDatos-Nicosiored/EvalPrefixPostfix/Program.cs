﻿using System;

namespace EvalPrefixPostfix
{
    class Program
    {
        static void Main(string[] args)
        {
            // Evaluamos postfix
            // CSTACK NECESITA DATO TIPO INT
            //CStack miStack = new CStack();
            //int n = 0, a = 0, b = 0, r = 0;
            //// -+3*52*73+
            //// 352*+73*-
            //string expresion = "352*+73*-";
            //char caracter = ' ';
            ////for (n = expresion.Length-1; n >= 0; n--)//Prefix
            //for (n = 0; n < expresion.Length; n++)//Postfix
            //{
            //    // Obtenemos el caracter
            //    caracter = expresion[n];
            //    // Verificamos si es numero
            //    if (caracter >= '0' && caracter <= '9') 
            //    {
            //        // Lo colocamos en el stack
            //        miStack.Push(Convert.ToInt32(caracter.ToString()));
            //    }
            //    else // Es operador
            //    {
            //        // Hacemos dos pop
            //        // postfix b->a
            //        // prefix a->b
            //        b = miStack.Pop();
            //        a = miStack.Pop();
            //        // Verificamos que operador es y aplicamos la opracion
            //        if (caracter == '+')
            //        {
            //            r = a + b;
            //            miStack.Push(r);
            //        }
            //        if (caracter == '-')
            //        {
            //            r = a - b;
            //            miStack.Push(r);
            //        }
            //        if (caracter == '/')
            //        {
            //            r = a / b;
            //            miStack.Push(r);
            //        }
            //        if (caracter == '*')
            //        {
            //            r = a * b;
            //            miStack.Push(r);
            //        }
            //    }                
            //}
            //miStack.Transversa();

            // Infix a postfix
            // CSTACK NECESITA DATO TIPO CHAR
            // Equivale a 567*+89*-
            string exp = "567*+89*-"; // Necesita expresiones validas de infix
            // Stack
            // res

            string res = "";
            int n = 0;
            CStack s = new CStack();
            // Recorremos caracter por caracter
            for (n = 0; n < exp.Length; n++)
            {
                // Verificamos que sea un operando
                if (exp[n] >= '0' && exp[n] <= '9')
                {
                    // Lo adicionamos al resultado
                    res += exp[n];
                }
                else // Encontes es un operador
                {
                    while (!s.EstaVacio() && MayorPrecedencia(s.Peek(), exp[n]))
                    {
                        // resp += s.Peek()
                        // s.Pop();
                        res += s.Pop();
                    }
                    s.Push(exp[n]);
                }
            }
            while (!s.EstaVacio())
            {
                // resp += s.Peek()
                // s.Pop();
                res += s.Pop();
            }
            Console.WriteLine("{0} en postifx es {1}", exp, res);
            Console.ReadKey();
        }
        // Ojo es para demostrar como actuar ante diferentes precedencias
        // pero algunos de estos operadores tienen la misma precedencia */+-
        public static bool MayorPrecedencia(char a, char b)
        {
            bool resultado = false;
            // es *
            if (a == '*')
                resultado = true;
            if (a == '/')
            {
                if (b == '*')
                    resultado = false;
                else
                    resultado = true;
            }
            // es +
            if (a == '+')
            {
                if (b == '*' || b == '/')
                    resultado = false;
                else
                    resultado = true;
            }
            // es -
            if (a == '-')
                resultado = false;
            return resultado;
        }
    }
}
