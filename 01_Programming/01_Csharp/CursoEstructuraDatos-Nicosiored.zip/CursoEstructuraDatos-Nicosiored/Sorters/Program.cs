﻿using System;

namespace Sorters
{
    class Program
    {
        private static CListaLigada miLista = new CListaLigada();
        static void Main(string[] args)
        {
            miLista.Adicionar(3);
            miLista.Adicionar(15);
            miLista.Adicionar(7);
            miLista.Adicionar(19);
            miLista.Adicionar(11);
            miLista.Adicionar(1);

            miLista.Transversa();

            //miLista = MergeSort(miLista);
            QuickSort(ref miLista, 0, miLista.Cantidad() - 1);
            miLista.Transversa();

            Console.ReadKey();
        }
        // Metodos de apoyo
        private static CListaLigada Swap(CListaLigada pLista, int i1, int i2)
        {
            int temp = pLista[i1];
            pLista[i1] = pLista[i2];
            pLista[i2] = temp;
            return pLista;
        }
        public static CListaLigada Merge(CListaLigada listIzq, CListaLigada listDer)
        {
            // Recordar que para que Merge funcione las listas Izq y Der ya deben estar ordenadas
            // Lista donde se unen
            CListaLigada unida = new CListaLigada();
            // Indices donde se unen
            int indiceI = 0;
            int indiceD = 0;
            // Cantidad de elementos en cada lista
            int canI = listIzq.Cantidad();
            int canD = listDer.Cantidad();
            // Recorremos mientras las dos listas tengan elemento sin procesar
            while (indiceI < canI && indiceD < canD)
            {
                // Si el de la izquierda es menor o igual adicionamos el de la izquierda
                if (listIzq[indiceI] <= listDer[indiceD])
                {
                    unida.Adicionar(listIzq[indiceI]);
                    // Avanzamos el indice izquierdo
                    indiceI++;
                }
                else // Si el de la derecha es menor adicionamos el de la Derecha
                {
                    unida.Adicionar(listDer[indiceD]);
                    // Avanzamos el indice derecho
                    indiceD++;
                }
            }
            // Si sobraron elementos en la lista izquierda los ponemos todos
            while (indiceI < canI)
            {
                unida.Adicionar(listIzq[indiceI]);
                indiceI++;
            }
            // Si sobraron elementos en la lista derecha los ponemos todos
            while (indiceD < canD)
            {
                unida.Adicionar(listDer[indiceD]);
                indiceD++;
            }
            // Regresamos la lista unida
            return unida;
        }
        public static int Particion(ref CListaLigada pLista, int pInicio, int pFin)
        {
            int pivote = 0;
            int iPivote = 0;
            int n = 0;
            // Seleccionamos el ultimo como pivote
            pivote = miLista[pFin];
            // Ponemos el indice de pivote con el indice del inicio
            iPivote = pInicio;
            // Recorremos la lista en el fragmento indicado
            for (n = pInicio; n < pFin; n++)
            {
                // Si el elemento en el indice n es menor o igual al pivote
                if (miLista[n] <= pivote)
                {
                    pLista = Swap(pLista, n, iPivote);
                    // Incrementamos el indice del pivote
                    iPivote++;
                }
            }
            // Haceos el swap final para colocar el pivote donde corresponde
            pLista = Swap(pLista, iPivote, pFin);
            // Regresamos el indice del pivote
            return iPivote;
        }
        public static void QuickSort(ref CListaLigada pLista, int pInicio, int pFin)
        {
            int iPivote = 0;
            // Caso base, un elemento o fragmento invalido
            if (pInicio >= pFin)
                return;
            // Obtenemos el indice del pivote para el fragmento con el que trabajamos
            iPivote = Particion(ref pLista, pInicio, pFin);
            // Casos inductivos
            QuickSort(ref pLista, pInicio, iPivote - 1); // Fragmento a la izquierda del pivote
            QuickSort(ref pLista, iPivote + 1, pFin); // Fragmento a la derecha del pivote
        }
        // Sorters
        //public static void MergeSort(ref CListaLigada pLista)
        //{
        //    // Cantidad de elementos en la lista
        //    int cantidad = pLista.Cantidad();
        //    int n = 0;
        //    // Caso base, una lista de un solo elemento ya esta ordenada
        //    if (cantidad < 2)
        //        return pLista;
        //    // Obtenemos el punto medio de la lista
        //    int mitad = cantidad / 2;
        //    CListaLigada izquierda = new CListaLigada();
        //    CListaLigada derecha = new CListaLigada();
        //    // Adicionamos a la izquierda desde el inicio hasta antes de la mitad
        //    for (n = 0; n < mitad; n++)
        //        izquierda.Adicionar(pLista[n]);
        //    // Adicionamos a la derecha desde la mitad hasta el finalde la lista
        //    for (n = mitad; n < cantidad; n++)
        //        derecha.Adicionar(pLista[n]);
        //    // Casos inductivos
        //    // Hacemos el MergSort de las listas Izquierda y Derecha
        //    CListaLigada tempI = MergeSort(izquierda);
        //    CListaLigada tempD = MergeSort(derecha);
        //    // Hacemos el Merge de lo que nos regresa el caso inductivo
        //    CListaLigada ordenada = Merge(tempI, tempD);
        //    // Regresamos la lista ordenada
        //    return ordenada;
        //}
        public static CListaLigada SelectionSort(CListaLigada pLista)
        {
            int i = 0;
            int j = 0;
            int iMin = 0;
            int n = pLista.Cantidad();

            // Recorremos los elementos
            for (i = 0; i < n - 1; i++)
            {
                // El indice menor es la posicion actual
                iMin = i;

                // Encontramos el nuevo indice del menor
                for (j = i + 1; j < n; j++)
                {
                    if (pLista[j] < pLista[iMin])
                        iMin = j;
                }
                // Intercambiamos la posicion actual con el menor
                pLista = Swap(pLista, i, iMin);
            }
            return pLista;
        }
        public static CListaLigada InsertionSort2(CListaLigada pLista)
        {
            int cantidad = miLista.Cantidad();
            int i = 0, posAgujero = 0;
            for (i = 1; i < cantidad; i++)
            {
                posAgujero = i;
                while (posAgujero > 0 && pLista[posAgujero] < pLista[posAgujero - 1])
                {
                    pLista = Swap(pLista, posAgujero, posAgujero - 1);
                    posAgujero = posAgujero - 1;
                }
            }
            return pLista;
        }
        public static CListaLigada InsertionSort1(CListaLigada pLista)
        {
            int cantidad = pLista.Cantidad();
            int i = 0, posAgujero = 0;
            int dato = 0;
            // Recorremos los elementos
            for (i = 0; i < cantidad; i++)
            {
                // Obtenemos el dato
                dato = pLista[i];
                // Indicamos la posicion del agujero
                posAgujero = i;
                // Recorremos los elementos hacia el agujero
                while (posAgujero > 0 && pLista[posAgujero - 1] > dato)
                {
                    pLista[posAgujero] = pLista[posAgujero - 1];
                    posAgujero = posAgujero - 1;
                }
                // Le colocamos al agujero el dato correspondiente
                pLista[posAgujero] = dato;
            }
            return pLista;
        }
        public static CListaLigada BubbleSort(CListaLigada pLista)
        {
            int m = 0, n = 0;
            int cantidad = pLista.Cantidad();
            //Console.WriteLine("Son {0} elementos", cantidad);
            // Hacemos los pases correspondientes
            for (m = 1; m < cantidad; m++)
            {
                // Recorremos la lista verificando si hay que hacer Swap
                // Los elementos hasta la derecha ya van quedando ordenados
                for (n = 0; n < cantidad - m; n++)
                {
                    if (pLista[n] > pLista[n + 1])
                        pLista = Swap(pLista, n, n + 1);
                }
            }
            return pLista;
        }
    }
}
