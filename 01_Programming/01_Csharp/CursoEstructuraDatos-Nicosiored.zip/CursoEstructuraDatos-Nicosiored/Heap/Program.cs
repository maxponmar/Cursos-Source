﻿using System;

namespace Heap
{
    class Program
    {
        static void Main(string[] args)
        {
            CHeap miHeap = new CHeap(13);

            miHeap.Insertar(1);
            miHeap.Insertar(2);
            miHeap.Insertar(3);
            miHeap.Insertar(4);
            miHeap.Insertar(5);
            miHeap.Insertar(6);
            miHeap.Insertar(7);
            miHeap.Transversa();
            Console.WriteLine("Minimo {0}",miHeap.BorrarMin());
            miHeap.Transversa();

            Console.WriteLine("Minimo {0}", miHeap.BorrarMin());
            miHeap.Transversa();
            Console.WriteLine("Minimo {0}", miHeap.BorrarMin());
            miHeap.Transversa();
            Console.WriteLine("Minimo {0}", miHeap.BorrarMin());
            miHeap.Transversa();
            Console.WriteLine("Minimo {0}", miHeap.BorrarMin());
            miHeap.Transversa();
            Console.WriteLine("Minimo {0}", miHeap.BorrarMin());
            miHeap.Transversa();
            Console.WriteLine("Minimo {0}", miHeap.BorrarMin());
            miHeap.Transversa();

            Console.ReadKey();
        }
    }
}
