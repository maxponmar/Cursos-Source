﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stack
{
    // Hacemos una implementacion basada en lista ligada
    class CStack
    {
        // Es el ancla o encabezado del stack
        private CNodo ancla;
        // Esta variable de referencia nos ayuda a trabajar con el stack
        private CNodo trabajo;
        public CStack()
        {
            // Instanciamos el ancla
            ancla = new CNodo();
            // Como es un stack vacio su siguiente es null
            ancla.Siguiente = null;
        }
        // Push
        public void Push(char pDato)
        {
            // Creamos el nodo temporal
            CNodo temp = new CNodo();
            temp.Dato = pDato;
            // Conectamos el temporal a la lista
            temp.Siguiente = ancla.Siguiente;
            // Conectamos el ancla al temporal
            ancla.Siguiente = temp;
        }
        // Pop
        public char Pop() // PONER CODIGO DE SEGURIDAD PARA STACKS VACIOS
        {
            // Esta version no contiene el codigo de seguridad
            // Colpcar una excepcion cuando se intente hacer un pop a un stack vacio
            char valor = ' ';
            // Llevamos a cabo el trabajo solo si hay elementos en el stack
            if (ancla.Siguiente != null)
            {
                // Obtenemos el dato correspondiente
                trabajo = ancla.Siguiente;
                valor = trabajo.Dato;
                // Lo sacamos del stack
                ancla.Siguiente = trabajo.Siguiente;
                trabajo.Siguiente = null;
            }
            return valor;
        }
        // Peek
        public char Peek()
        {
            // Esta version no contiene el codigo de seguridad
            // Colpcar una excepcion cuando se intente hacer un pop a un stack vacio
            char valor = ' ';
            // Llevamos a cabo el trabajo solo si hay elementos en el stack
            if (ancla.Siguiente != null)
            {
                // Obtenemos el dato correspondiente
                trabajo = ancla.Siguiente;
                valor = trabajo.Dato;
            }
            return valor;
        }
        // Transversa
        public void Transversa()
        {
            // Trabajo al inicio
            trabajo = ancla;
            // Recorremos hasta encontrar el final
            while (trabajo.Siguiente != null)
            {
                // Avanzamos trabajo
                trabajo = trabajo.Siguiente;
                // Obtenemos el dato y lo mostramos
                int d = trabajo.Dato;
                Console.WriteLine("[{0}]", d);
            }
        }
        // Adicionamos este metodo para saber si esta vacio el stack
        public bool StackVacio()
        {
            if (ancla.Siguiente == null)
                return true;
            else
                return false;
        }
    }
}
