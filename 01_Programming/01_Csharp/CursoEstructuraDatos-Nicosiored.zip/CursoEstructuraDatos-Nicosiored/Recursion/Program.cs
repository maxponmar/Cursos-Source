﻿using System;

namespace Recursion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Factorial y fibonacci");
            int f = Factorial(5);
            Console.WriteLine("Factorial de 5: " + f);
            f = Fibonacci(6);
            Console.WriteLine("Numero 6 de serie de Fibonacci: " + f);
            Console.ReadKey();
        }

        public static int Factorial(int n)
        {
            int r = 0;

            if (n > 1)
            {
                r = n * Factorial(n - 1);
            }

            if (n == 1)
            {
                r = 1;
            }

            return r;
        }

        public static int Fibonacci(int n)
        {
            int r = 0;

            if (n > 1)
            {
                r = Fibonacci(n - 1) + Fibonacci(n - 2);
            }

            if (n <= 1)
            {
                r = 1;
            }

            return r;
        }
    }
}
