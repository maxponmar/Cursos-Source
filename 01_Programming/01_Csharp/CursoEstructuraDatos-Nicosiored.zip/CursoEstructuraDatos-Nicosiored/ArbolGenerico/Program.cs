﻿using System;

namespace ArbolGenerico
{
    class Program
    {
        static void Main(string[] args)
        {
            CArbol arbol = new CArbol();
            CNodo raiz = arbol.Insertar("a", null);
            arbol.Insertar("b", raiz);
            arbol.Insertar("c", raiz);

            //arbol.TransversaPreO(raiz);

            CNodo n = arbol.Insertar("d", raiz);
            arbol.Insertar("h", n);

            n = arbol.Insertar("e", raiz);
            arbol.Insertar("i", n);
            n = arbol.Insertar("j", n);
            arbol.Insertar("p", n);
            arbol.Insertar("q", n);

            //arbol.TransversaPreO(raiz);
            n = arbol.Insertar("f", raiz);
            arbol.Insertar("k", n);
            arbol.Insertar("l", n);
            arbol.Insertar("m", n);

            n = arbol.Insertar("g", raiz);
            arbol.Insertar("n", n);

            arbol.TransversaPreO(raiz);
            //arbol.TransversaPostO(raiz);
            Console.WriteLine("-----");
            CNodo encontrado = arbol.Buscar("k", raiz);
            if (encontrado != null)
                Console.WriteLine(encontrado.Dato);
            else
                Console.WriteLine("No lo encontre");
            Console.WriteLine("-----");

            string donde = "";
            string que = "";
            Console.WriteLine("En donde desas insertar");
            donde = Console.ReadLine();
            Console.WriteLine("Que deseas insertar");
            que = Console.ReadLine();

            encontrado = arbol.Buscar(donde, raiz);
            arbol.Insertar(que, encontrado);
            arbol.TransversaPreO(raiz);

            Console.ReadKey();
        }
    }
}
