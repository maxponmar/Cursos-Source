﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ArbolBinario
{
    class CArbolBB
    {
        private CNodo raiz;
        private CNodo trabajo;

        private int i = 0;

        public CArbolBB()
        {
            Raiz = null;
        }

        internal CNodo Raiz { get => raiz; set => raiz = value; }
        // Insertar
        public CNodo Insertar(int pDato, CNodo pNodo)
        {
            CNodo temp = null;
            // Si no hay a quien insertar entonces creamos el nodo
            if (pNodo == null)
            {
                temp = new CNodo();
                temp.Dato = pDato;
                return temp;
            }
            if (pDato < pNodo.Dato)
            {
                pNodo.Izq = Insertar(pDato, pNodo.Izq);
            }
            if (pDato > pNodo.Dato)
            {
                pNodo.Der = Insertar(pDato, pNodo.Der);
            }
            return pNodo;
        }
        // Transversa
        public void Transversa(CNodo pNodo)
        {
            if (pNodo == null)
                return;
            // Me proceso primero a mi
            for (int n = 0; n < i; n++)
                Console.Write(" ");
            Console.WriteLine(pNodo.Dato);
            // Si tengo derecha, proceso a la derecha
            if (pNodo.Izq != null)
            {
                i++;
                Console.WriteLine("I ");
                Transversa(pNodo.Izq);
                i--;
            }
            if (pNodo.Der != null)
            {
                i++;
                Console.WriteLine("D ");
                Transversa(pNodo.Der);
                i--;
            }
        }
        public int EncuentraMinimo(CNodo pNodo)
        {
            if (pNodo == null)
                return 0;
            trabajo = pNodo;
            int minimo = trabajo.Dato;
            while (trabajo.Izq != null)
            {
                trabajo = trabajo.Izq;
                minimo = trabajo.Dato;
            }
            return minimo;
        }
        public int EncuentraMaximo(CNodo pNodo)
        {
            if (pNodo == null)
                return 0;
            trabajo = pNodo;
            int maximo = trabajo.Dato;
            while (trabajo.Der != null)
            {
                trabajo = trabajo.Der;
                maximo = trabajo.Dato;
            }
            return maximo;
        }
        public CNodo EncuentraNodoMinimo(CNodo pNodo)
        {
            if (pNodo == null)
                return null;
            trabajo = pNodo;
            while (trabajo.Izq != null)
            {
                trabajo = trabajo.Izq;
            }
            return trabajo;
        }
        public CNodo EncuentraNodoMaximo(CNodo pNodo)
        {
            if (pNodo == null)
                return null;
            trabajo = pNodo;
            while (trabajo.Der != null)
            {
                trabajo = trabajo.Der;
            }
            return trabajo;
        }
        public void TransversaOrdenada(CNodo pNodo)
        {
            if (pNodo == null)
                return;
            // Si tengo izquierda, proceso la izquierda
            if (pNodo.Izq != null)
            {
                i++;
                TransversaOrdenada(pNodo.Izq);
                i--;
            }
            Console.Write("{0}, ", pNodo.Dato);
            // Si tengo derecha, proceso la derecha
            if (pNodo.Der != null)
            {
                i++;
                TransversaOrdenada(pNodo.Der);
                i--;
            }
        }
        public CNodo BuscarPadre(int pDato, CNodo pNodo)
        {
            CNodo temp = null;
            if (pNodo == null)
                return null;
            // Verifico si soy el padre
            if (pNodo.Izq != null)
                if (pNodo.Izq.Dato == pDato)
                    return pNodo;
            if (pNodo.Der != null)
                if (pNodo.Der.Dato == pDato)
                    return pNodo;
            // Si tengo izquierda, proceso a la izquierda
            if (pNodo.Izq != null && pDato < pNodo.Dato)
            {
                temp = BuscarPadre(pDato, pNodo.Izq);
            }
            // Si tengo derecha, proceso a la derecha
            if (pNodo.Der != null && pDato > pNodo.Dato)
            {
                temp = BuscarPadre(pDato, pNodo.Der);
            }
            return temp;
        }
        public CNodo Borrar(CNodo pNodo, int pDato)
        {
            if (pNodo == null)
                return pNodo;
            if (pDato < pNodo.Dato)
                pNodo.Izq = Borrar(pNodo.Izq, pDato);
            if (pDato > pNodo.Dato)
                pNodo.Der = Borrar(pNodo.Der, pDato);
            // Casos sin hijos
            if (pNodo.Izq == null && pNodo.Der == null)
                return null;
            // Caso un hijo, hacer el caso espejo
            if (pNodo.Izq == null)
            {
                CNodo padre = EncuentraNodoMaximo(pNodo);
                padre.Der = pNodo.Der;
                return pNodo;
            }
            else
            {
                // Caso con dos hijos
                CNodo minimo = EncuentraNodoMinimo(pNodo.Der);
                pNodo.Dato = minimo.Dato;
                pNodo.Der = Borrar(pNodo.Der, minimo.Dato);
            }
            return pNodo;
        }
    }
}
